// pages/public/questionnaire/questionnaire.js
const cgi = require('../../../constant/cgi.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    arrow_icon: ['arrow-down', 'arrow-down'],
    show: [false, false],
    userName: '', //用户姓名
    type:'',//用户类型
    id: '', //问卷id
    approveInfo:'',
    readonly: 1,
    info:{} 
  },
  handleTap(e) {//切换隐藏
    console.log(e)
    let inx = e.currentTarget.dataset.inx
    let show = this.data.show;
    let arrow_icon = this.data.arrow_icon
    arrow_icon[inx] = 'arrow-up';
    if (show[inx] == false) {

      show[inx] = true
      this.setData({
        show,
        arrow_icon
      })
    } else {
      arrow_icon[inx] = 'arrow-down',
        show[inx] = false
      this.setData({
        show,
        arrow_icon
      })
    }
  },
  delsf(val){
    if (val&&val!=''){
      val = val.replace(/#/g,'-')
    }
    return val;
  },
  delTime(t){
    if(t==null||t=='null'){
      return '';
    }
    if(t&&t.length>11){
      t = t.replace('00:00:00','');
    }
    return t;
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log(options);
    // 从跳转参数获取用户姓名、问卷id、是否显示审核按钮
    this.setData({
      userName: options.userName,
      id:options.id,
      readonly:options.readonly,
      type:options.type
    })
  },

  //输入框
  handleChange(e) {
    this.setData({
      [`${e.target.id}`]: e.detail.value,
    })

  },
  // 获取问卷详情
  getInfo(){
    wx.showLoading({
      title: '数据加载中',
    });
    var that = this;
    wx.request({
      method: 'POST',
      url: cgi.getQuestionaryById,
      data: {
        id: that.data.id,
      },
      header: {
        'Content-Type': 'application/json',
        'token': wx.getStorageSync("token") //从缓存获取token
      },
      success: function (res) {
        console.log(res,"question")
        if (res.data.code == 200) {
          console.log(res.data.data)
          if(res.data.data){
            var info = res.data.data;
            info.receivedHubeiTime = that.delTime(info.receivedHubeiTime);
            info.goOutTime = that.delTime(info.goOutTime);
            info.goBackTime = that.delTime(info.goBackTime);
            info.todayGoOutTime = that.delTime(info.todayGoOutTime);
            info.todayGoBackTime = that.delTime(info.todayGoBackTime);
            info.visitorComeTime = that.delTime(info.visitorComeTime);
            console.log(info.receivedHubeiProvince)
            console.log(that.delsf(info.receivedHubeiProvince))
            info.receivedHubeiProvince = that.delsf(info.receivedHubeiProvince);
            info.todayPhysicalConditions = that.delsf(info.todayPhysicalConditions);
            that.setData({
              info: info
            })
          }else{
            wx.showToast({
              icon: 'none',
              title: '获取数据失败',
            })
          }
          
        } else {
          wx.showToast({
            icon: 'none',
            title: res.data.message,
          })
        }
        wx.hideLoading();
      }
    })

  },

  // 审核 0-驳回 ; 2-通过
  verify(event) {
    var that = this;
    var type = event.currentTarget.dataset.type
    var req = {
      operateType:'',
      ids:[],
      approveInfo: that.data.approveInfo,
    }
    req.ids.push(that.data.id)
    //根据链接参数选择用户审核类型
    if(that.data.type=="S"){ //学生
      req.operateType ='auditStudent'
    } else if (that.data.type == "T"){ //教师
      req.operateType = 'auditTeacher'
    }
    if (type == "agree") { //通过
      req.status = 2;
    } else if (type == "refuse") { //驳回
      req.status = 0;
    }
    wx.showModal({
      title: '提示',
      content: type == "agree" ? '确定通过' + that.data.info.informantName + '今天的问卷吗？' : '确定驳回' + that.data.info.informantName + '今天的问卷吗？',
      success: function (res) {
        if (res.confirm) {
          console.log(req);

          wx.request({
            method: 'POST',
            url: cgi.updateStudentListType,
            data: req,
            header: {
              'content-type': 'application/json', // 默认值
              'token': wx.getStorageSync('token')
            },

            success(res) {
              if (res.data.code == 200) {
                wx.showToast({
                  icon: 'none',
                  title: '操作成功',
                  duration: 2000,
                  success: function () {
                    setTimeout(function () {
                      wx.navigateBack({
                        delta: 1
                      })
                    }, 2001);
                  }
                })
              } else {
                wx.showToast({
                  title: res.data.message,
                  icon: "none"
                })
              }
            }
          })
        }
      },
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.getInfo();
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})