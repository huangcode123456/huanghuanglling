// pages/public/questionnaireByGenerated/questionnaireByGenerated.js
const cgi = require('../../../constant/cgi.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    arrow_icon: ['arrow-down', 'arrow-down'],
    show: [false, false],
    id: '', //问卷id
    type:'',
    info: {} 
  },

  handleTap(e) {//切换隐藏
    console.log(e)
    let inx = e.currentTarget.dataset.inx
    let show = this.data.show;
    let arrow_icon = this.data.arrow_icon
    arrow_icon[inx] = 'arrow-up';
    if (show[inx] == false) {

      show[inx] = true
      this.setData({
        show,
        arrow_icon
      })
    } else {
      arrow_icon[inx] = 'arrow-down',
        show[inx] = false
      this.setData({
        show,
        arrow_icon
      })
    }
  },
  delsf(val) {
    if (val && val != '') {
      val = val.replace(/#/g, '-')
    }
    return val;
  },
  delTime(t) {
    if (t == null || t == 'null') {
      return '';
    }
    if (t && t.length > 11) {
      t = t.replace('00:00:00', '');
    }
    return t;
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log(options);
    // 从跳转参数获取问卷id
    this.setData({
      id: options.id,
      type:options.type
    })
    this.getInfo();
  },

  // 获取问卷详情
  getInfo() {
    wx.showLoading({
      title: '数据加载中',
    });
    var that = this;
    wx.request({
      method: 'POST',
      url: cgi.getQuestMessge,
      data: {
        id: that.data.id,
      },
      header: {
        'Content-Type': 'application/json',
        'token': wx.getStorageSync("token") //从缓存获取token
      },
      success: function (res) {
        console.log(res, "question")
        if (res.data.code == 200) {
          console.log(res.data.data)
          if (res.data.data) {
            var info = res.data.data;
            info.receivedHubeiTime = that.delTime(info.receivedHubeiTime);
            info.goOutTime = that.delTime(info.goOutTime);
            info.goBackTime = that.delTime(info.goBackTime);
            info.todayGoOutTime = that.delTime(info.todayGoOutTime);
            info.todayGoBackTime = that.delTime(info.todayGoBackTime);
            info.visitorComeTime = that.delTime(info.visitorComeTime);
            console.log(info.receivedHubeiProvince)
            console.log(that.delsf(info.receivedHubeiProvince))
            info.receivedHubeiProvince = that.delsf(info.receivedHubeiProvince);
            info.todayPhysicalConditions = that.delsf(info.todayPhysicalConditions);
            that.setData({
              info: info
            })
          } else {
            wx.showToast({
              icon: 'none',
              title: '获取数据失败',
            })
          }

        } else {
          wx.showToast({
            icon: 'none',
            title: res.data.message,
          })
        }
        wx.hideLoading();
      }
    })

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})