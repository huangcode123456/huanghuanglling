// pages/class/teacher/details/details.js
var app = getApp()
const cgi = require('../../../../constant/cgi.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    id:'',
    type:'',
    show:false,
    info:[],
    orgid:'',
    readonly:'',
  },

  
  // 删除副班主任
  goToInvite(){
    var that = this
    wx.showModal({
      title: '提示',
      content: '是否确认删除',
      success(res) { 
        if (res.confirm) {
          console.log(res.confirm)
          console.log('用户点击确定')
          wx.request({
            method: 'POST',
            url: cgi.delFbzr,
            data: {
              "userid": that.data.id
            },
            header: {
              'Content-Type': 'application/json',
              'token': wx.getStorageSync('token')
            },
            success: function (res) {
              console.log(res)
              console.log(that.data.userid, '用户id')
              console.log(that.data.id, '机构id')
              if (res.data.code == 200) {
                wx.showToast({
                  title: '删除成功',
                  success() {
                    // 返回上一页
                    wx.navigateBack({
                      delta: 1
                    })
                    // wx.navigateTo({
                    //   url: '/pages/school/admin/list/list',
                    // })
                  }
                })

              } else {
                wx.showToast({
                  title: '删除失败',
                  icon: "none"
                })
              }
            }
          })
        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })



    
  },
  
  // 获取详情
  getInfo() {
    var that = this;
    console.log(wx.getStorageSync('token'),'*******************token')
    console.log(wx.getStorageSync('userInfo').orgid, '****************orgid')
    console.log(that.data.id,'****************userid')
    var condition = {
      userid: that.data.id,
      type:that.data.type,
      orgid: wx.getStorageSync('userInfo').orgid
    }
    wx.request({
      method: 'POST',
      url: cgi.getTeacherMessgeById,
      data: condition,
      header: {
        'content-type': 'application/json', // 默认值
        'token': wx.getStorageSync('token')
      },
      success(res) {
        console.log(res)
        if (res.code = 200) {
          that.setData({
            info: res.data.data
          })
          console.log(that.data.info)
        } else {
          wx.showToast({
            icon: "none",
            title: '查询失败，请重试！',
          })
        }
      }
    })
  },
  
  // 设置副班主任
  goSetInvite() {
    var that = this
    wx.showModal({
      title: '提示',
      content: '是否确认设为副班主任',
      success(res) {
        if (res.confirm) {
          console.log(res.confirm)
          console.log('用户点击确定')
          wx.request({
            method: 'POST',
            url: cgi.setFbzr,
            data: {
              "classId": wx.getStorageSync('userInfo').classId,
              "gradeId": wx.getStorageSync('userInfo').gradeId,
              "userid": that.data.id
            },
            header: {
              'Content-Type': 'application/json',
              'token': wx.getStorageSync('token')
            },
            success: function (res) {
              console.log(res)
              console.log(that.data.userid, '用户id')
              console.log(that.data.id, '机构id')
              if (res.data.code == 200) {
                wx.showToast({
                  title: '设置成功',
                  success() {
                    // 返回上一页
                    wx.navigateBack({
                      delta: 2
                    })
                    // wx.navigateTo({
                    //   url: '/pages/school/admin/list/list',
                    // })
                  }
                })

              } else {
                wx.showToast({
                  title: '设置失败',
                  icon: "none"
                })
              }
            }
          })
        } 
      }
    })
  },

  
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this
    console.log(options);
    wx.getStorage({
      key: 'token',
      success: function(res) {
        that.setData({
          token:res.data
        })
      },
    })
    wx.getStorage({
      key: 'userInfo',
      success: function(res) {
        console.log(res.data.orgid)
        that.setData({
          orgid:res.data.orgid
        })
      },
    })
    this.setData({
      id:options.userid,
      readonly: options.readonly,
      type:options.type
    })
    console.log(this.data.id)
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.getInfo();
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})