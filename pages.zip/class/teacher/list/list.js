// pages/class/teacher/list/list.js
var app = getApp()
const cgi = require('../../../../constant/cgi.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    list:[],
    noData:true,
  },
  // 获取副班主任列表
  getList(){
    var that =this;
    var req ={
      orgid:wx.getStorageSync('userInfo').clssId,
      user_name:''
    }
    wx.request({
      method: 'POST',
      url: cgi.getTeacherByClassIdType,
      data: req,
      header: {
        'Content-Type': 'application/json',
        'token': wx.getStorageSync("token")
      },
      success: function (res) {
        console.log(res)
      }
    })
  },


  // 邀请管理员跳转
  addHeadmaster() {
    wx.navigateTo({
      url: '/pages/class/teacher/add/add',
    })
  },


  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.getList();
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})