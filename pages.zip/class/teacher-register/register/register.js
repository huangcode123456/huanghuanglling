// pages/class/teacher-register/register/register.js
const cgi=require('../../../../constant/cgi.js')
Page({
  data: {
    zhuce:true,
    isShow:false,
    isThr:false,
    orgid:'',
    token:'',
    texts: "学校教师注册",
    openid:'',
    formData: {
      // userNumber:'',
      name: '',
      phone:'',
      isHeadmaster: '',
      // classInfo: [],
      idCard:'',
      password: '123456',
      passwordConfirm: '123456',
      address:'',
      origin:'',
      sex:'',
      classInfo:'',
      selectorA:'',
      selectorB:'',
      selectorC:'',
      // nj_bj:''
    },
    rules: {
      selectorC:[
        { type: 'required', message: '所属部门不能为空' }
      ],
      // userNumber:[
      //   { type: 'required', message: '工号不能为空' }
      // ],
      name: [
        { type: 'required', message: '姓名不能为空' }
      ],
      phone: [
        { type: 'required', message: '手机号不能为空' },
        { type: 'customPhone', message: '请填写正确的手机号' },
      ],
      // isHeadmaster: [
      //   { type: 'required', message: '用户类别不能为空' }
      // ],
      // classInfo: [
      //   { type: 'required', message: '请选择所在班级' }
      // ],
      // idCard: [
      //   { type: 'required', message: '身份证号码不能为空' },
      //   { type: 'customIdcard', message: '请填写正确的身份证号码' }
      // ],
      // password: [
      //   { type: 'required', message: '密码不能为空' }
      // ],
      // passwordConfirm: [
      //   { type: 'required', message: '确认密码不能为空' }
      // ],
      address:[
        { type: 'required', message: '居住地址不能为空' }
      ],
      age:[
        { type: 'required', message: '年龄不能为空' },
        { type: 'customAge', message: '请填写正确的年龄' }
      ],
      // origin:[
      //   { type: 'required', message: '籍贯不能为空' }
      // ],
      sex:[
        { type: 'required', message: '性别不能为空' }
      ]
    },
    validateType: {
      customIdcard(value, formData) {
        return /^[1-9]\d{7}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}$|^[1-9]\d{5}[1-9]\d{3}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}([0-9]|X)$/.test(value)
      },
      customPhone(value, formData) {
        return /^1[3456789]\d{9}$/.test(value)
      },
      customPwd(value, formData) {
        return value.length >= 6 && value.length <= 12
      },
      customAge(value, formData) {
        return /^(?:[1-9][0-9]?|1[01][0-9]|120)$/.test(value)
      },
      // passwordConfirm(value, formData) {
      //   return value == formData.password
      // },
    },
    // selectorRange: [
    //   { name: '中华人民共和国', value: 'cn', displayName: '中国' },
    //   { name: '美利坚合众国', value: 'us', displayName: '美国' }
    // ],
    isHeadmasterRange: [
      { name: '班主任', value: 'MAS', displayName: '班主任' },
      // { name: '副班主任', value: 'DEY', displayName: '副班主任' },
      { name: '普通教师', value: 'THR', displayName: '普通教师' }
    ],
    sex: [
      { name: '男', value: 'M', displayName: '男' },
      { name: '女', value: 'F', displayName: '女' }
    ],
    
    classInfoRange: [
      // [
      //   { name: '一年级', value: '一年级' },
      //   { name: '二年级', value: '二年级' }
      // ],
      // [
      //   { name: '1班', value: '1班' },
      //   { name: '2班', value: '2班' },
      // ]
    ],
  },

  //获取openid
  getOpenid() {//获取openid
    let that = this;
    wx.login({
      success(res) {
        const code = res.code;
        console.log(code, "code");
        wx.request({
          url: cgi.loginTask.code2openid,
          data: { "code": code },
          success(res) {
            console.log(res.data.data.openid);
            that.setData({
              openid: res.data.data.openid
            })
          }
        })
      }
    })
  },

  //获取职能部门
  getDeptList(){
    let that=this;
    wx.request({
      method:"post",
      url: cgi.gradeSet.getDeptList,
      data:{
        // orgid: this.data.orgid,
        parentId: that.data.orgid,//'a183abae-459b-11ea-ac7d-52540005d2d2',
      },
      header: {
        'content-type': 'application/json', // 默认值
        'token': this.data.token
      },
      success(res) {
        console.log(res.data.data)
        let znbm = []
        for (let i = 0; i < res.data.data.length;i++){
          let str = {};
          str.name = res.data.data[i].orgName
          str.value = res.data.data[i].orgid
          znbm.push(str)
        }
        that.setData({
          selectorRange2: znbm
        })
      } 
    })
  },

  //获取年级班级
  getOrgListByParentId(){
    let that=this;
    wx.request({
      method:'post',
      url: cgi.gradeSet.getOrgList,
      data:{
        // parentId:this.data.orgid
        parentId:that.data.orgid,//'a183abae-459b-11ea-ac7d-52540005d2d2'
      },
      header: {
        'content-type': 'application/json', // 默认值
        'token': this.data.token
      },
      success(res) {
        console.log(res.data.data)
        that.setData({
          nj_bj:res.data.data
        })
        let classInfoRange=[]
        let nianji=[]
        let banji=[]
        for(let i=0;i<res.data.data.length;i++){
          let str={};
          let str1={}
          str.name = res.data.data[i].orgName
          str.value = res.data.data[i].orgid
          nianji.push(str)

          str1.name
        }
        classInfoRange = nianji;
        that.setData({
          selectorRange:classInfoRange
        })
        console.log(that.data.classInfoRange)
      }
    })
  },
  onLoad: function (options) {
    console.log(options)
    this.setData({
      orgid: options.orgid,
      token: options.token
    })
    this.getOpenid()
    this.getOrgListByParentId()
    this.getDeptList()
  },
  // 输入
  handleChange(e) {
    console.log(e)
    if(e.currentTarget.id == "selectorA"){
      console.log(1)
      this.setData({
        [`formData.selectorB`]:''
      })
      if(e.detail.value!==this.data.formData.selectorA)
      console.log(this.data.nj_bj)
      for (let i = 0; i < this.data.nj_bj.length;i++){
        console.log(this.data.nj_bj[i])
        if (this.data.nj_bj[i].orgid==e.detail.value){
          console.log(this.data.nj_bj[i].subList)
          let arr=[]
          for (let t = 0; t < this.data.nj_bj[i].subList.length;t++){
            let str={}
            str.name = this.data.nj_bj[i].subList[t].orgName;
            str.value = this.data.nj_bj[i].subList[t].orgid;
            arr.push(str)
          }
          console.log(arr)
          this.setData({
            selectorRange1:arr
          })
        }
      }
    }
    if (e.currentTarget.id == "isHeadmaster"){
      if (e.detail.value !=='THR'){
        this.setData({
          [`rules.selectorA`]: [
            { type: 'required', message: '年级不能为空' }
          ],
          [`rules.selectorB`]: [
            { type: 'required', message: '班级不能为空' }
          ],
        })
        console.log('是班主任')
        this.setData({
          isShow:true
        })
      }else{
        let rules=this.data.rules;
        delete rules.selectorA
        delete rules.selectorB
        this.setData({
          rules,
          isShow: false,
          [`formData.selectorA`]:'',
          [`formData.selectorB`]:''
        })
      }
    }
    this.setData({
      [`formData.${e.target.id}`]: e.detail.value.replace(/\s/g, '')
    })
  },
  handleDeptChange(e) {
    console.log(e,'dept')
    var value = e.detail.value;
    var name = "";
    var deptRange = this.data.selectorRange2;
    console.log(deptRange,"deptRange")
    for (var i = 0; deptRange.length;i++){
      if (deptRange[i].value == value){
        name = deptRange[i].name;
        break;
      }
    }
    console.log(name,"ft")
    let rules = this.data.rules;
    if (name=="在职教师"){
      rules.isHeadmaster=[
        { type: 'required', message: '用户类别不能为空' }
      ];
      this.setData({
        rules,
        isThr: true,
        isShow: false,
        [`formData.selectorC`]: value,
        [`formData.isHeadmaster`]: '',
        [`formData.selectorA`]: '',
        [`formData.selectorB`]: ''
      });
    }else{
      delete rules.isHeadmaster
      this.setData({
        rules,
        isThr: false,
        isShow: false,
        [`formData.selectorC`]: value,
        [`formData.isHeadmaster`]: 'THR',
        [`formData.selectorA`]: '',
        [`formData.selectorB`]: ''
      });
    }
    // if (e.detail.value !== 'THR') {
    //   console.log(1)
    //   this.setData({
    //     [`formData.selectorB`]: ''
    //   })
    // }
  },
  idcardChange(e) {
    let idcard = e.detail.value;
    let sex = this.data.formData.sex;
    let age = this.data.formData.age;
    if (this.data.validateType.customIdcard(idcard)) {
      if (parseInt(idcard.substr(16, 1)) % 2 == 1) {
        sex = 'M';
      } else {
        sex = 'F';
      }
      var curDate = new Date();
      age = curDate.getFullYear() - parseInt(idcard.substr(6, 4));
    }
    this.setData({
      'formData.idCard': idcard,
      'formData.sex': sex,
      'formData.age': age
    })
  },
  // 选择班级
  handleClassInfoChange(e) {
    console.log(e.detail.value)
    this.setData({
      [`formData.${e.target.id}`]: e.detail.value
    })
  },

  // 注册
  handleFormSubmit(e) {
    let that=this;
    if (e.detail.validStatus){
      if(that.data.zhuce){
        that.setData({
          zhuce: false
        })
        wx.setStorage({
          key: 'thrRole',
          data: that.data.formData.isHeadmaster,
        })
        if (that.data.formData.isHeadmaster=='MAS'){
          console.log('发起请求')
          wx.request({
            method: 'post',
            url: cgi.teacherRegist,
            data: {
              address: that.data.formData.address,
              age: that.data.formData.age,
              deptId: that.data.formData.selectorC,
              openid: that.data.openid,
              orgid: that.data.orgid,
              origin: that.data.formData.origin,
              phone: that.data.formData.phone,
              sex: that.data.formData.sex,
              type: that.data.formData.isHeadmaster,
              userName: that.data.formData.name,
              userPwd: that.data.formData.password,
              classId: that.data.formData.selectorB,
              gradeId: that.data.formData.selectorA,
            },
            header: {
              'content-type': 'application/json', // 默认值
              'token': this.data.token
            },
            success(res) {
              that.setData({
                zhuce: true
              })
              if (res.data.code == 200) {
                wx.showToast({
                  icon: 'none',
                  title: '注册成功',
                })
                wx.redirectTo({
                  url: '/pages/class/teacher-register/status/status?status=' + 1 + '&orgid=' + that.data.orgid,
                })
              } else {
                wx.showToast({
                  icon: 'none',
                  title: res.data.message,
                })
              }
            }
          })
        } else if (that.data.formData.isHeadmaster == 'THR'){
          wx.request({
            method: 'post',
            url: cgi.teacherRegist,
            data: {
              address: that.data.formData.address,
              age: that.data.formData.age,
              deptId: that.data.formData.selectorC,
              openid: that.data.openid,
              orgid: that.data.orgid,
              origin: that.data.formData.origin,
              phone: that.data.formData.phone,
              sex: that.data.formData.sex,
              type: that.data.formData.isHeadmaster,
              userName: that.data.formData.name,
              userPwd: that.data.formData.password,
              // classId: that.data.formData.selectorB,
              // gradeId: that.data.formData.selectorA,
            },
            header: {
              'content-type': 'application/json', // 默认值
              'token': this.data.token
            },
            success(res) {
              that.setData({
                zhuce: true
              })
              if (res.data.code == 200) {
                wx.showToast({
                  icon: 'none',
                  title: '注册成功',
                })
                wx.redirectTo({
                  url: '/pages/class/teacher-register/status/status?status=' + 1 + '&orgid=' + that.data.orgid,
                })
              } else {
                wx.showToast({
                  icon: 'none',
                  title: res.data.message,
                })
              }
            }
          })
        }
      }else{
        wx.showToast({
          icon:'none',
          title: '请勿重复点击',
        })
      }
    }
    
    // const { validStatus, value: { name, phone, isHeadmasterRange, classInfoRange, idCard, password, passwordConfirm } } = e.detail
    // console.log(e.detail)

    // if (validStatus) {
    //   console.log('注册成功，等待审核...')
    //   // 跳转至审核状态界面
    //   wx.redirectTo({
    //     url: '/pages/class/teacher-register/status/status',
    //   })
    // }
  },

})
