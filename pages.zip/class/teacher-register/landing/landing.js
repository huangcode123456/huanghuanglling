// pages/class/teacher-register/landing/landing.js
const cgi = require('../../../../constant/cgi.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    isShow: false,
    disabled:true,
    orgid:'',
    token:'',
    userName:'',
    orgName:''
  },

  // 跳转至注册
  goToRegister() {
    wx.navigateTo({
      url: '/pages/class/teacher-register/register/register?orgid='+this.data.orgid+'&token='+this.data.token,
    })
  },

  //根据openid获取用户信息
  getOpenid() {//获取openid
    let that = this;
    wx.showLoading({
      title: '加载中',
    })
    wx.login({
      success(res) {
        const code = res.code;
        wx.request({
          url: cgi.loginTask.code2openid,
          data: { "code": code },
          success(res) {
            that.setData({
              openid: res.data.data.openid
            })
            wx.request({
              method: 'POST',
              url: cgi.loginTask.openidlogin,
              data: {
                openid: res.data.data.openid
              },
              header: {
                'content-type': 'application/json', // 默认值
                'token': that.data.token
              },
              success(res) {
                console.log(res, "teacher user info")
                if (res.data.code==404){
                  that.setData({
                    isShow: true,
                    disabled: false
                  })
                  wx.hideLoading();
                } else if (res.data.code == 200 && res.data.data.userInfo.type != 'MAS' && res.data.data.userInfo.type != 'DEY' && res.data.data.userInfo.type != 'THR') {
                  that.setData({
                    isShow: true,
                    disabled: false
                  })
                  wx.hideLoading()
                }else if(res.data.code==666){
                  var users = res.data.data.multiBindUserList;
                  var i = 0;
                  for(;i<users.length;i++){
                    if (users[i].type == 'MAS' || users[i].type == 'DEY' || users[i].type =='THR'){
                      wx.setStorage({
                        key: 'thrRole',
                        data: users[i].type,
                      })
                      let urlInfo = '/pages/class/teacher-register/status/status?status=' + users[i].status + '&name=' + that.data.userName + '&orgid=' + that.data.orgid + '&orgName=' + that.data.orgName;
                      wx.reLaunch({
                        url: urlInfo,
                      })
                    }
                  }
                  if (i == users.length) {
                    that.setData({
                      disabled: false,
                      isShow: true
                    })
                    wx.hideLoading()
                  }
                } else {
                  if (res.data.data.status == 2) {
                    that.goToLogin();
                    wx.hideLoading();
                  } else if (res.data.data.status == 0) {
                    wx.reLaunch({
                      url: '/pages/class/teacher-register/status/status?status=' + 0 + '&name=' + that.data.userName + '&orgid=' + that.data.orgid + '&orgName=' + that.data.orgName,
                    })
                    wx.hideLoading();
                  } else if (res.data.data.status == 1) {
                    wx.reLaunch({
                      url: '/pages/class/teacher-register/status/status?status=' + 1 + '&name=' + that.data.userName + '&orgid=' + that.data.orgid + '&orgName=' + that.data.orgName,
                    })
                  }
                  wx.hideLoading()
                }
              }
            })
          }
        })
      }
    })
  },

  // 已有账号跳转登录
  goToLogin() {
    wx.reLaunch({
      url: '/pages/school/admin-login/index',
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      orgid: options.orgid,//'a464f94a-459b-11ea-ac7d-52540005d2d2',//
      token:options.token,
      userName: options.userName,//'张三',//
      orgName: options.orgName //'北京市昌平区马池口中心白浮小学',//
    })
    // this.setData({
    //   orgid: 'c98dbd61-459b-11ea-ac7d-52540005d2d2',//
    //   token:options.token,
    //   userName: '张三',//
    //   orgName: '北京市昌平区新龙学校',//
    // })
    
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.getOpenid()
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})