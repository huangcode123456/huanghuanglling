// pages/school/admin/list/list.js
var app = getApp();
const cgi = require('../../../../constant/cgi.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    schoolName:'',
    showInvite:false,
  },
  

  
  // 邀请管理员跳转
  goToInvite() {
    console.log(this.data.list)
    let name=wx.getStorageSync('userInfo').userName;
    
    wx.navigateTo({
      url: '/pages/school/admin/invite/invite?orgname=' + this.data.schoolName+'&name='+name,
    })
  },

  //获取管理员列表
  getList(){
    var that = this
    wx.request({
      method: 'POST',
      url: cgi.adminSet.getTeacher,
      data: {
        pageNumber: 1,
        pageSize: 100,
        type: 'SCM'
      },
      header: {
        'Content-Type': 'application/json',
        'token': wx.getStorageSync('token')
      },
      success: function (res) {
        console.log(res)
        if(res.data.code==200){
          if (res.data.data.records && res.data.data.records.length > 0) {
            console.log(res.data.data.records)
            that.setData({
              list: res.data.data.records,
             
            })
          } 
        }else{
          wx.showToast({
            icon: "none",
            title: res.data.message,
          })
        }
        
      }
    })
  },
 
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    // 根据缓存判断当前用户是否是超级管理员
    this.setData({
      schoolName: options.schoolName
    })
    if(wx.getStorageSync('userInfo').type=='SCHM'){
      this.setData({
        showInvite:true
      })
    }
    console.log(this.data.schoolName)
    
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.getList()
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    if(this.data.length>9){
      var pageNumber = this.data.pageNumber+1
      var list = this.data.list1
      var th = this
      wx.getStorage({
        key: 'token',
        success: function (res) {
          app.globalData.token = res.data
          console.log('--------------获取管理员信息')
          wx.request({
            method: 'POST',
            url: cgi.adminSet.getTeacher,
            data: {
              'pageNumber': th.data.pageNumber,
              'pageSize': 9,
              'startRow': 0,
              'type': 'SCM'
            },
            header: {
              'Content-Type': 'application/json',
              'token': res.data
            },
            success: function (res) {
              console.log(res)
              var list1 = list+res.data.data.records
              for (let i = 0; i < res.data.data.records.length; i++) {
                if (res.data.data.records[i].type == "SCHM") {
                  list1[0] = res.data.data.records[i]
                  th.setData({
                    list1: list1
                  })
                }
              }
              // th.setData({
              //   list1:res.data.data.records
              // })
              console.log(res.data.data.records)
              app.globalData.type = res.data.data.records.type
            }
          })
        }
      })
    }
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})