// pages/school/admin/invite/invite.js
Page({
  data: {
    token:'',
    userInfo:'',
    title: "邀请学校管理员",
    text: "点击下方按钮分享给微信好友",
  },
  onLoad: function (options) {
    console.log(options.name)
    let that=this;
    wx.getStorage({//token
      key: 'token',
      success: function(res) {
        that.setData({
          token:res.data
        })
      },
    })
    wx.getStorage({//userInfo
      key: 'userInfo',
      success: function(res) {
        that.setData({
          userInfo:res.data
        })
      },
    })
    this.setData({
      orgname:options.orgname,
      name:options.name
    })
  },
  // 分享设置相关
  
  onShareAppMessage: function () {
    wx.getStorage({
      key: 'userInfo',
      success: function(res) {
        console.log(res.data)
      },
      fail: function(res) {},
      complete: function(res) {},
    })
    return {
      title: '邀请你成为'+this.data.orgname+'管理员',
      path: '/pages/school/admin-register/landing/landing?token=' + this.data.token + '&orgid=' + this.data.userInfo.orgid + '&orgname=' + this.data.orgname+'&name='+this.data.name// 路径，传递参数到指定页面。
    }

  }
  

})
