// pages/school/analysis/setting/setting.js
const cgi = require('../../../../constant/cgi.js');
const analysis = require('../../../../constant/analysis.js');
Page({
  data: {
    userid: '',
    username: '',
    school:'',
    id:'',
    formData: {
      name: '',
      range:[],
      lists: [],
      summarylists: [],
    },
    redioItems: [
      { name: '科室', value: '0', disabled: true },
      { name: '学校', value: '1', disabled: true },
      { name: '班级', value: '2', disabled: true },
    ],
    typeRange: [],
  },
  handleChange(e) {
    this.setData({
      [`formData.${e.target.id}`]: e.detail.value
    })
  },
  
  getOrgById() {
    let that = this
    wx.getStorage({
      key: 'token',
      success: function (res) {
        console.log(res)
        that.setData({
          token: res.data
        })
        wx.getStorage({
          key: 'userInfo',
          success: function (res) {
            that.setData({
              orgid: res.data.orgid
            })
            wx.request({
              method: 'post',
              url: cgi.gradeSet.getOrg,
              data: {
                orgid: that.data.orgid
              },
              header: {
                'content-type': 'application/json', // 默认值
                'token': that.data.token
              },
              success(res) {
                console.log(res.data.data.address == null)
                that.setData({
                  school: res.data.data
                })
              }
            })
          },
        })
      },
    })
  },
  getFields() {
    let that = this
    wx.request({
      url: analysis.getTemplateFields,
      method: 'get',
      header: {
        'content-type': 'application/json', // 默认值
        'token': wx.getStorageSync('token')
      },
      success: function (res) {
        if (res.data.code == 200) {
          that.setData({
            typeRange: res.data.data
          })
          
        }
      }
    })
  },
  getFieldcnname(fieldname){
    let fieldcnname='';
    let Li = this.data.typeRange.filter(i => i.fieldname === fieldname);
    if (Li.length>0)
    {
      fieldcnname = Li[0].fieldcnname
    }
    return fieldcnname
  },
  getgroupReqs(groupReqs){
    let list=groupReqs;
    for (let i = 0; i < list.length; i++) {
      let fieldcnname = this.getFieldcnname(list[i].fieldname)
      list[i].fieldcnname = fieldcnname;
    }
    return list
  },
  getsumReqs(sumReqs) {
    let list = sumReqs;
    for (let i = 0; i < list.length; i++) {
      let sumDetailReqs = list[i].sumDetailReqs;
      for (let j = 0; j < sumDetailReqs.length;j++)
      {
        let sumDetailReqsLi = sumDetailReqs[j];
        let fieldcnname = this.getFieldcnname(sumDetailReqsLi.fieldname)
        list[i].sumDetailReqs[j].fieldcnname = fieldcnname; 
      }  
    }
    return list
  },
  searchTemplate(){
    var that = this;
    var req={
      id:that.data.id
    }
    console.log(req,'req')
    wx.showLoading({
      title: '加载中',
    })
    wx.request({
      method: 'get',
      url: analysis.getTemplateById,
      data:req,

      header: {
        'content-type': 'application/json', // 默认值
        'token': wx.getStorageSync('token')
      },
      success(res) {
        console.log('searchTemplate:', res)
        if (res.data.code == 200) {
          that.setData({
            [`formData.name`]: res.data.data.name,//模板名称
            [`formData.range`]: that.getRange(res.data.data.range_office, res.data.data.range_school, res.data.data.range_class),//应用范围
            [`formData.lists`]: that.getgroupReqs(res.data.data.groupReqs),//分组设定信息
            [`formData.summarylists`]: that.getsumReqs(res.data.data.sumReqs),//汇总设定
          })
          wx.hideLoading();
          console.log('lists', that.data.formData.lists)
          console.log('summarylists',that.data.formData.summarylists)
        }
      }
    })
  },
  getRange(val1,val2,val3)
  {
    let rangs=[]
    if (val1 == 1) {
      rangs.push("0")
    }
    if (val2 == 1) {
      rangs.push("1")
    }
    if (val3 == 1) {
      rangs.push("2")
    }
    return rangs
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that=this;
    that.setData({                      
      id: options.id,  
    })
    that.getOrgById();
  },
    
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.getFields();
    this.searchTemplate()
    
  },
})