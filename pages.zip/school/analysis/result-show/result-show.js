// pages/school/analysis/result-show/result-show.js
const config = require('../../../../constant/config.js');
const cgi = require('../../../../constant/cgi.js');
const analysis = require('../../../../constant/analysis.js');
Page({
  data: {
    token: '',
    orgid: '',
    school: '',
    orgName:null,
    timer:null,
    formData: {
      timeset:'日',
      date:'',
    },
    timesetList: [
      { name: '日', value: '日' },
    ],
    exportpath: '',
   
  },
  getOrgById() {
    let that = this
    wx.getStorage({
      key: 'token',
      success: function (res) {
        console.log(res,'res')
        that.setData({
          token: res.data
        })
        wx.getStorage({
          key: 'userInfo',
          success: function (res) {
            console.log(res, 'res1')
            that.setData({
              orgid: res.data.orgid,
              orgName: res.data.type.substring(0, 3) == "SCH" ? res.data.orgName : null
            })
            wx.request({
              method: 'post',
              url: cgi.gradeSet.getOrg,
              data: {
                orgid: that.data.orgid
              },
              header: {
                'content-type': 'application/json', // 默认值
                'token': that.data.token
              },
              success(res) {
                console.log(res.data.data.address == null)
                console.log(res,'res2')
                that.setData({
                  school: res.data.data
                })
              }
            })
          },
        })
      },
    })
  },
  isToday:function(){
    var exportDate = this.data.formData.date;
    var curDate = new Date();
    var sDate = curDate.getFullYear() + "-" + (curDate.getMonth() < 9 ? "0" : "") + (curDate.getMonth()+1) + "-"+(curDate.getDate() < 10 ? "0" : "") + curDate.getDate();
    return this.data.formData.date==sDate;
  },
  exportCheck:function(){
    var that = this;

    //查找学校提交情况和未提交班级情况
    if (that.isToday()){
      wx.request({
        method: 'POST',
        url: cgi.getQuerySchoolIsSubmitRes,
        data: {
          orgid: that.data.orgid,
        },
        header: {
          'Content-Type': 'application/json',
          'token': that.data.token
        },
        success: function (res) {
          let school = false;
          if (res.data.code == 200) {
            if (res.data.data.issubmit == '1') {
              school = true;
            }
          }
          wx.request({
            method: "post",
            url: cgi.getClassMessge,
            data: {
              orgid: that.data.orgid,
            },
            header: {
              'content-type': 'application/json', // 默认值
              'token': that.data.token
            },
            success(res) {
              var classNum = 0;
              var msg = "";
              if (!school){
                msg = "学校教职工今日问卷数据未提交，";
              }
              if (res.data.code == 200) {
                var results = res.data.data;
                for(var i=0;i<results.length;i++){
                  if(results[i].status=="0"){
                    classNum = results[i].classnum;
                  }
                }
              }
              if (classNum > 0){
                msg = msg + "有" + classNum+"个班级今日问卷数据未提交，";
              }
              if (msg!=""){
                wx.showModal({
                  title: '提示',
                  content: msg+'确定现在需要导出？',
                  success(showModalres) {
                    if (showModalres.confirm) {
                      that.export();
                    }
                  }
                });
              } else {
                that.export();
              }
            }
          })
        }
      })
    }else{
      that.export();
    }
  },
  export:function(){
    var that = this;
    var erq = {};
    if (that.data.orgName == null) {
      erq = {
        dt: that.data.formData.date,
      }
    }
    else {
      erq = {
        dt: that.data.formData.date,
        org: that.data.orgName
      }
    }
    console.log(erq, 'erq')
    wx.showLoading({
      title: '导出中...',
    })
    wx.request({
      method: 'GET',
      url: analysis.getStatisAll,
      data: erq,
      header: {
        'content-type': 'application/json', // 默认值
        'token': wx.getStorageSync('token')
      },
      success(res) {
        console.log('export:', res);
        
        if (res.data.code==200){
          if (res.data.data==null){
            var timerTem =setTimeout(function () {
              console.log('5秒后再次执行export')
              wx.hideLoading();
              that.export();
            }, 5000) //延迟时间 这里是5秒
            // 保存定时器name
            that.setData({
              timer: timerTem
            })
          }
          else {
            wx.hideLoading();
            wx.showShareMenu();
            that.setData({
              exportpath: config.urlAnalysisPrefix + res.data.data
            })
            let exportFileNameIndex = res.data.data.lastIndexOf('/');
            let exportFileName = res.data.data.substring(exportFileNameIndex + 1);
            wx.showModal({
              title: '提示',
              content: '导出文件' + exportFileName + '成功',
              confirmText: '确定',
              cancelText: '复制链接',
              confirmColor: '#2775B6',
              confirmColor: '#2775B6',
              success(showModalres) {
                if (showModalres.cancel) {
                  wx.setClipboardData({
                    data: config.urlAnalysisPrefix + res.data.data,
                    success: function (res) {
                      wx.getClipboardData({
                        success: function (res) {
                          wx.showToast({
                            icon: "none",
                            title: '复制成功',
                          })
                        }
                      })
                    }
                  })
                }
              }
            })
          }
        }
        else if (res.data.code == 400) {
          wx.hideLoading();
          wx.showModal({
            title: '提示',
            content:  res.data.message,
            confirmText: '确定',
            confirmColor: '#2775B6',
            showCancel: false,
          })
        }
        else{
          wx.hideLoading();
          wx.showModal({
            title: '提示',
            content: '导出失败:' + res.data.error,
            confirmText: '确定',
            confirmColor: '#2775B6',
            showCancel: false,
          })
        }
        
      },
      fail(res) {
        wx.showToast({
          icon: "none",
          title: '导出失败:' + res.error,
        })
       
      }
    }) 
  },
  onShareAppMessage: function (res) {
    var that = this;
    console.log('分享地址为path:', that.data.exportpath)
    var shareObj = {
      title: '统计报表',
      path: that.data.exportpath,
      imageUrl: '/images/excel_share.svg',
      success: function (res) {
        console.log('转发成功')
      },
      fail: function (res) {
        console.log('转发失败')
      },
    }
    return shareObj
  },


  handleChange(e) {
    this.setData({
      [`formData.${e.target.id}`]: e.detail.value
    })

  },
  /**
    * 生命周期函数--监听页面加载
    */
  onLoad: function (options) {
    this.getDate()
    this.getOrgById()
    wx.hideShareMenu();
  },
  /**
    * 获取日期
    */
  getDate(){
    let timestamp = Date.parse(new Date());
    let date = new Date(timestamp);
    let Y = date.getFullYear();
    let M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1);
    let D = date.getDate() < 10 ? '0' + date.getDate() : date.getDate();
    this.setData({
      [`formData.date`]: Y + '-' + M + '-' + D
    })
  },
  /**
  * 生命周期函数--监听页面显示
  */
  onShow: function () {
   
  },
  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    wx.hideLoading();
    clearInterval(this.data.timer);
  },
  // 取消
  goBack(){
    
    wx.navigateBack({
    })
  }
})