// pages/school/analysis/details/details.js
const cgi = require('../../../../constant/cgi.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    formData:'',
    popShow: false,
    token: '',
    orgid: '',
    school: ''
  
  },

  getOrgById() {
    let that = this
    wx.getStorage({
      key: 'token',
      success: function (res) {
        console.log(res)
        that.setData({
          token: res.data
        })
        wx.getStorage({
          key: 'userInfo',
          success: function (res) {
            that.setData({
              orgid: res.data.orgid
            })
            wx.request({
              method: 'post',
              url: cgi.gradeSet.getOrg,
              data: {
                orgid: that.data.orgid
              },
              header: {
                'content-type': 'application/json', // 默认值
                'token': that.data.token
              },
              success(res) {
                that.setData({
                  school: res.data.data
                })
              }
            })
          },
        })
      },
    })
  },
  // 底部弹出
  sw:function(){
    this.setData({
      popShow: !this.data.popShow
    })
    console.log(this.data.popShow)
  },


  // 添加部门
  add:function(){
    wx.showLoading({
      title: '请稍后',
    });
    var list = this.data.list
    var obj = {}
    var length = list.length
    obj.label = length+1
    obj.value = this.data.formData
    list[length] = obj
    // console.log(this.data.formData)
    this.setData({
      list:list,
      formData:''
    })
    // 请求后台
    wx.hideLoading();
    this.sw()
  },
  // 输入部门名称
  handleChange:function(e){
    this.setData({
      formData: e.detail.value
    })
  },

  // 删除部门
  del:function(e){
    wx.showLoading({
      title:'请稍后'
    })
    var val = e.currentTarget.dataset.value
    var list = this.data.list
    for (let i = 0; i < list.length; i++) {
      if (list[i].value==val) {
        list.splice(i,1)
        this.setData({
          list:list
        })
      }      
    }
    wx.hideLoading();
  },


  // 跳转
  two:function(e){
    var uid = e.currentTarget.dataset.lable
    wx.navigateTo({
      url: '/pages/school/questionnaire/info-collection/info-collection'
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.getOrgById()

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})