// pages/school/analysis/setting/setting.js
const cgi = require('../../../../constant/cgi.js');
const analysis = require('../../../../constant/analysis.js');
Page({
  data: {
    add: "<添加>",
    del: "<删除>",
    school: '',
    userid: '',
    username: '',
    edit_id:null,
    formData: {
      name: '',
      range:[],
      lists: [{
        "status": 1,
        "fieldname": "",
        "alias": "",
        "oper": "",
        "val1": "",
        "val2": "",
      },
      ],
      
      summarylists: [{
        "alias": "",
        "id": "",
        "tempid": "",
        sumDetailReqs: [{
          "status": 1,
          "fieldname": "",
          "oper": "",
          "val1": "",
          "val2": "",
        }],
      },
      ],
    },
    redioItems: [
      { name: '科室', value: '0' },
      { name: '学校', value: '1' },
      { name: '班级', value: '2' },
    ],
    typeRange: [],
    conditionsRange: [
      { name: '等于', value: '等于', displayName: '等于' },
      { name: '不等于', value: '不等于', displayName: '不等于' },
      { name: '小于', value: '小于', displayName: '小于' },
      { name: '小于或等于', value: '小于或等于', displayName: '小于或等于' },
      { name: '大于', value: '大于', displayName: '大于' },
      { name: '大于或等于', value: '大于或等于', displayName: '大于或等于' },
      { name: '包含', value: '包含', displayName: '包含' },
      { name: '不包含', value: '不包含', displayName: '不包含' },
      { name: '开始以', value: '开始以', displayName: '开始以' },
      { name: '结束以', value: '结束以', displayName: '结束以' },
      { name: '是NULL', value: '是NULL', displayName: '是NULL' },
      { name: '不是NULL', value: '不是NULL', displayName: '不是NULL' },
      { name: '介于', value: '介于', displayName: '介于' },
      { name: '非介于', value: '非介于', displayName: '非介于' },
      { name: '在列表中', value: '在列表中', displayName: '在列表中' },
      { name: '不在列表中', value: '不在列表中', displayName: '不在列表中' },
    ],
  },
  onAddsumDetailPre: function (e) {
    var nowIdx1 = e.currentTarget.dataset.idx1;//获取summarylists的索引
    var nowIdx2 = e.currentTarget.dataset.singleidx;//获取是sumDetailReqs的索引
    var lists = this.data.formData.summarylists[nowIdx1].sumDetailReqs;
    var newData = {
      "status": 1,
      "fieldname": "",
      "oper": "",
      "val1": "",
      "val2": "",
    };
    const deleted = lists.splice(nowIdx2 , 0, newData);
    console.log(lists, 'onAddsumDetailPre:lists')
    this.setData({
      [`formData.summarylists[${nowIdx1}].sumDetailReqs`]: lists,
    })
  },
  onDeletesumDetailPre(e) {
    var nowIdx1 = e.currentTarget.dataset.idx1;//获取summarylists的索引
    var nowIdx2 = e.currentTarget.dataset.singleidx;//获取是sumDetailReqs的索引
    var lists = this.data.formData.summarylists[nowIdx1].sumDetailReqs;
    const deleted = lists.splice(nowIdx2, 1);
    console.log(lists, 'onDeletesumDetailPre:lists')
    this.setData({
      [`formData.summarylists[${nowIdx1}].sumDetailReqs`]: lists,
    })
  },
  onAddsingle_summarylists: function (e) {
    var nowidx = e.currentTarget.dataset.sidx;//当前索引
    var lists = this.data.formData.summarylists[nowidx].sumDetailReqs;
    console.log(lists,'lists')
    var newData = {
      "status": 1,
      "fieldname": "",
      "oper": "",
      "val1": "",
      "val2": "",
    };
    lists.push(newData);
    this.setData({
      [`formData.summarylists[${nowidx}].sumDetailReqs`]: lists,
    })
  },
  delsingle_summarylists: function (e) {
    var nowIdx1 = e.currentTarget.dataset.sidx;//获取summarylists的索引
    var lists = this.data.formData.summarylists[nowIdx1].sumDetailReqs;
    var nowidx = lists.length-1;
    lists.splice(nowidx, 1);
    this.setData({
      [`formData.summarylists[${nowIdx1}].sumDetailReqs`]: lists,
    })
  },
  onAddPre: function (e) {
    var nowIdx1 = e.currentTarget.dataset.idx1;//索引
    var lists = this.data.formData.lists;
    var newData = {
      "status": 1,
      "fieldname": "",
      "alias": "",
      "oper": "",
      "val1": "",
      "val2": "",
    };
    const deleted = lists.splice(nowIdx1 , 0, newData);
    console.log(lists, 'onAddPre:lists')
    this.setData({
      [`formData.lists`]: lists,
    })
  },
  onAdd: function () {
    var lists = this.data.formData.lists;
    var newData = {
      "status": 1,
      "fieldname": "",
      "alias": "",
      "oper": "",
      "val1": "",
      "val2": "",
    };
    lists.push(newData);
    this.setData({
      [`formData.lists`]: lists,
    })
  },
  onDeletePre: function (e) {
    var nowIdx1 = e.currentTarget.dataset.idx1;//索引
    var lists = this.data.formData.lists;
    const deleted = lists.splice(nowIdx1, 1);
    console.log(lists, 'onDeletePre:lists')
    this.setData({
      [`formData.lists`]: lists,
    })
  },
  delList: function (e) {
    var nowidx = this.data.formData.lists.length-1;//
    var lists = this.data.formData.lists;
    
    lists.splice(nowidx, 1);
    this.setData({
      [`formData.lists`]: lists,
    })
  },
  onAddsummary: function () {
    var lists = this.data.formData.summarylists;
    var newData = {
      "alias": "",
      sumDetailReqs: [],
    };
    lists.push(newData);
    this.setData({
      [`formData.summarylists`]: lists,
    })
  },
  delsummarylists: function (e) {
    var nowidx = this.data.formData.summarylists.length-1;
    var lists = this.data.formData.summarylists;
    lists.splice(nowidx, 1);
    this.setData({
      [`formData.summarylists`]: lists,
    })
  },
  bindDataChang: function (e) {
    var typeIdx = e.currentTarget.dataset.ltype;//获取是lists还是summarylists,1-lists，2-summary
    var nowIdx1 = e.currentTarget.dataset.idx1;//获取是lists或者summarylists的索引
    var typeName = e.currentTarget.dataset.typename;//获取是数组中object名字
    if (typeIdx==1){
      if (typeName =="status"){
        this.setData({
          [`formData.lists[${nowIdx1}].${typeName}`]: (e.detail.value == "group_check" ? 1 : 0)
        })
      } else if (typeName == "fieldname") {
        this.setData({
          [`formData.lists[${nowIdx1}].${typeName}`]: this.data.typeRange[e.detail.index].fieldname
        })
      }else{
        this.setData({
          [`formData.lists[${nowIdx1}].${typeName}`]: e.detail.value
        })
      }
     
      
    }
    else{
     
      if (typeName =='alias')
      {
        this.setData({
          [`formData.summarylists[${nowIdx1}].${typeName}`]: e.detail.value
        })
      } else if (typeName == "status") {
        var nowIdx2 = e.currentTarget.dataset.singleidx;//获取是sumDetailReqs的索引
        
        this.setData({
          [`formData.summarylists[${nowIdx1}].sumDetailReqs[${nowIdx2}].${typeName}`]: (e.detail.value == "summary_check" ? 1 : 0)
        })
      } else if (typeName == "fieldname") {
        var nowIdx2 = e.currentTarget.dataset.singleidx;//获取是sumDetailReqs的索引
        this.setData({
          [`formData.summarylists[${nowIdx1}].sumDetailReqs[${nowIdx2}].${typeName}`]: this.data.typeRange[e.detail.index].fieldname
        })
      }else{
        var nowIdx2 = e.currentTarget.dataset.singleidx;//获取是sumDetailReqs的索引
        this.setData({
          [`formData.summarylists[${nowIdx1}].sumDetailReqs[${nowIdx2}].${typeName}`]: e.detail.value
        })
      }
    
    }
  },
  handleChange(e) {
    this.setData({
      [`formData.${e.target.id}`]: e.detail.value
    })
  },
  
  getOrgById() {
    let that = this
    wx.getStorage({
      key: 'token',
      success: function (res) {
        console.log(res)
        that.setData({
          token: res.data
        })
        wx.getStorage({
          key: 'userInfo',
          success: function (res) {
            that.setData({
              orgid: res.data.orgid
            })
            wx.request({
              method: 'post',
              url: cgi.gradeSet.getOrg,
              data: {
                orgid: that.data.orgid
              },
              header: {
                'content-type': 'application/json', // 默认值
                'token': that.data.token
              },
              success(res) {
                console.log(res.data.data.address == null)
                that.setData({
                  school: res.data.data
                })
              }
            })
          },
        })
      },
    })
  },

  handleFormSubmit(e) {
    const { validStatus, value: { name, password } } = e.detail
    //console.log('handleFormSubmit:' ,e.detail)
    var range_office = 0;
    var range_school = 0;
    var range_class = 0;
    //console.log(this.data.formData.range,'this.data.formData.range')
    for (var i = 0; i < this.data.formData.range.length; i++) {
      if (this.data.formData.range[i]=="0")
      {
        range_office = 1;
      }
      else if (this.data.formData.range[i] == "1") {
        range_school = 1;
      }
      else if (this.data.formData.range[i] == "2") {
        range_class = 1;
      }
    }
    var data={
      name: this.data.formData.name,//模板名称
      range_class: range_class,//应用范围班级
      range_office: range_office,//应用范围科室
      range_school: range_school,//应用范围学校
      groupReqs: this.data.formData.lists,//分组设定信息
      sumReqs: this.data.formData.summarylists,//汇总信息
      type: 1,  //模板类型
      userid: this.data.userid, //用户id 
      username: this.data.username, //用户名称
    };
    var url="";
    if (this.data.edit_id==null){
      url = analysis.addTemplate;
    }
    else{
      data.id = this.data.edit_id;
      url = analysis.updateTemplateById;
    }
    console.log("handleFormSubmit:data",data)
    console.log("handleFormSubmit:url", url)
    
    if (validStatus) {
      console.log(validStatus, 'validStatus')
      wx.showLoading({
        title: '加载中',
      })
      wx.request({
        method: 'POST',
        url: url,
        data: data,
        header: {
          'content-type': 'application/json', // 默认值
          'token': wx.getStorageSync('token')
        },
        success(res) {
          console.log('res:' , res)
          wx.hideLoading();
          if (res.data.code == 200) {
            wx.showToast({
              title: '编辑成功',
              icon: 'none',
              duration: 2000
            })
            // 返回上一页
            wx.navigateBack({
            })
          } else {
            wx.showToast({
              title: res.data.message,
              icon: 'none',
              duration: 2000
            })
          }
        }
      })
    }
  },
  getFields() {
    let that = this
    wx.request({
      url: analysis.getTemplateFields,
      method: 'get',
      header: {
        'content-type': 'application/json', // 默认值
        'token': wx.getStorageSync('token')
      },
      success: function (res) {
        //console.log(res, 'fieldname');
        if (res.data.code == 200) {
          that.setData({
            typeRange: that.changeFields(res.data.data)
          })
          
        }
      }
    })
  },
  changeFields(rangeReqs){
    let list = rangeReqs;
    for (let i = 0; i < list.length; i++) {
      list[i].value = list[i].fieldname;
      list[i].name = list[i].fieldcnname
    }
    return list
  },
  searchTemplate(){
    var that = this;
    var req={
      id:that.data.edit_id
    }
    //console.log(req,'req')
    wx.showLoading({
      title: '加载中',
    })
    wx.request({
      method: 'get',
      url: analysis.getTemplateById,
      data:req,

      header: {
        'content-type': 'application/json', // 默认值
        'token': wx.getStorageSync('token')
      },
      success(res) {
        console.log('searchTemplate:', res)
        if (res.data.code == 200) {
          that.setData({
            [`formData.name`]: res.data.data.name,//模板名称
            [`formData.range`]: that.getRange(res.data.data.range_office, res.data.data.range_school, res.data.data.range_class),//应用范围
            [`formData.lists`]: res.data.data.groupReqs,//分组设定信息
            [`formData.summarylists`]: res.data.data.sumReqs,//汇总设定
          })
          console.log('lists', that.data.formData.lists)
          console.log('summarylists',that.data.formData.summarylists)
          wx.hideLoading();
        }
      }
    })
  },
  getRange(val1,val2,val3)
  {
    let rangs=[]
    if (val1 == 1) {
      rangs.push("0")
    }
    if (val2 == 1) {
      rangs.push("1")
    }
    if (val3 == 1) {
      rangs.push("2")
    }
    return rangs
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that=this;
    that.setData({                      
      edit_id: options.id,  
    })
    that.getOrgById();
  },
    
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.getFields();
    if(this.data.edit_id!=null)
    {
      this.searchTemplate()
    }
    
  },
  // 取消
  goBack(){
    wx.navigateBack({
    })
  }
})