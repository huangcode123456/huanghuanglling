const cgi = require('../../../constant/cgi.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    token:'',
    orgid:'',
    school:''
  },
  //获取头部学校信息
  getOrgById(){
    let that=this
    wx.getStorage({
      key: 'token',
      success: function(res) {
        console.log(res)
        that.setData({
          token:res.data
        })
        wx.getStorage({
          key: 'userInfo',
          success: function (res) {
            console.log(res,"eee")
            that.setData({
              orgid: res.data.orgid
            })
            wx.request({
              method: 'POST',
              url: cgi.gradeSet.getOrg, 
              data: {
                orgid: that.data.orgid
              },
              header: {
                'content-type': 'application/json', // 默认值
                'token': that.data.token
              },
              success(res) {
                console.log(res.data.data)
                that.setData({
                  school:res.data.data
                })
              }
            })
          },
        })
      },
    })
    
    
  },
  toCenter(){
    console.log('跳转')
    wx.navigateTo({
      url: '/pages/school/myCenter/index/index',
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.getOrgById()
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },
  onShareAppMessage: function () {
    return {
      title: '教委数据统计',
      path: '/pages/index/index',
      imageUrl: this.showTrueConf ? '/images/share1.png' : '../../pages/import_img/share1.png'
    };
  }
});
