// pages/school/school-info/details/details.js

const cgi = require('../../../../constant/cgi.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    orgid:'',
    school:null,
    userInfo:null,
    editObj:null,
    editLabel:'请输入',
    dept:[],
    gra:[],
    token:"",
    formData:'',
    formDatac:'',
    deptData:'',
    formEditData:'',
    popShow:false,
    popShowc:false,
    popEditShow:false,


    // 切换选项卡属性
    activeKey: '1',
    activeKey2: 'a',
    animated: true,
  
     // 展开折叠
     selectedFlag: [],
  },      

  // 切换选项卡
  tabChange(e) {
    const key = e.currentTarget.dataset.key
    //清除弹窗清除数值
    this.setData({
      [`${key}`]: e.detail.value.key,
      popShow: false,
      popShowc: false,
      popEditShow: false,
      formData: '',
      formDatac: '',
      deptData: '',
      formEditData: '',
      editObj: null
    });

  },


  // 展开折叠选择 
  changeToggle:function(e){
  var index = e.currentTarget.dataset.index;
  if (this.data.selectedFlag[index]){
   this.data.selectedFlag[index] = false;
  }else{
   this.data.selectedFlag[index] = true;
  }
  
  this.setData({
   selectedFlag: this.data.selectedFlag
  })
  },

  // 底部弹出
  sw:function(){
    this.setData({
      popShow: !this.data.popShow
    })
  },
  swc:function(){
    this.setData({
      popShowc: !this.data.popShowc,
    })
  },

  // 获取班级位置信息
  get:function(e){
    var graClass = e.currentTarget.dataset.index
    this.setData({
      graClass: graClass
    })
    this.swc();
  },
  editOrg:function(e){
    console.log(e,"editOrg");
    let obj = e.currentTarget.dataset.index;
    let txt = "";
    if(obj.type=='GRE'){
      txt = "请修改年级名称";
    } else if (obj.type == 'CLS') {
      txt = "请修改班级名称";
    } else if (obj.type == 'DEPT') {
      txt = "请修改职能部门名称";
    }
    this.setData({
      editObj: obj,
      formEditData:obj.orgName,
      editLabel: txt,
      popEditShow: !this.data.popEditShow
    })
  },

  //修改机构
  updateOrg:function(){
    if (this.data.formEditData == "") {
      wx.showToast({
        title: '名称不能为空',
        icon: 'none'
      })
      return;
    }
    let obj = this.data.editObj;
    let that = this;
    if(obj==null){
      wx.showToast({
        title: '程序异常，请重试！',
        icon: 'none'
      });
      that.setData({
        formEditData: '',
        editObj: null,
        popEditShow: !that.data.popEditShow
      });
    }else{
      console.log(obj, "obj info");
      console.log(that.data.formEditData, "name");
      obj.orgName = that.data.formEditData;
      obj.orgAlias = that.data.formEditData;
      console.log(obj, "obj info 22");
      wx.request({
        method: 'POST',
        url: cgi.gradeSet.updateOrgById,
        data: obj,
        header: {
          'content-type': 'application/json', // 默认值
          'token': that.data.token
        },
        success(res) {
          if (res.data.code == 200) {
            wx.showToast({
              title: '修改成功',
              icon: 'none',
              duration: 2000
            })
            that.setData({
              formEditData:'',
              editObj:null,
              popEditShow: !that.data.popEditShow
            });
            if(obj.type=="GRE"){
              var list = that.data.gra
              for (var i = 0; i < list.length; i++) {
                if (list[i].orgid == obj.orgid) {
                  list.splice(i, 1,obj)
                  that.setData({
                    gra: list
                  });
                }
              }
            }else if(obj.type=="CLS"){
              var gra = that.data.gra
              for (var j = 0; j < gra.length; j++) {
                for (var i = 0; i < gra[j].subList.length; i++) {
                  if (gra[j].subList[i].orgid == obj.orgid) {
                    gra[j].subList.splice(i, 1,obj);
                    that.setData({
                      gra: gra
                    });
                    break;
                  }
                }
              }
            }else if(obj.type=="DEPT"){
              var list = that.data.dept;
              for (var i = 0; i < list.length; i++) {
                if (list[i].orgid == obj.orgid) {
                  list.splice(i, 1,obj);
                  that.setData({
                    dept: list,
                  })
                  break;
                }
              }
            }
          } else {
            wx.showToast({
              title: res.data.message,
              icon: 'none',
              duration: 2000
            });
            that.setData({
              formEditData: '',
              editObj: null,
              popEditShow: !that.data.popEditShow
            });
          }
        }
      });
    }
  },
  // 添加部门
  addDept:function(){
    if (this.data.deptData==""){
      wx.showToast({
        title: '职能部门名称不能为空',
        icon: 'none'
      })
      return;
    }
    wx.showLoading({
      title: '请稍后',
    });
    var list = this.data.dept
    var obj = {}
    var length = list.length
    obj.orgName = this.data.deptData
    obj.subNum = 0;
    obj.parentId = this.data.orgid;
    obj.type = 'DEPT';
    obj.orgAlias = obj.orgName;
    obj.status=1;
    obj.createUserId = this.data.userInfo.id;
    obj.createUserName = this.data.userInfo.userName;
    obj.modifyUserId = this.data.userInfo.id;
    obj.modifyUserName = this.data.userInfo.userName;
    let that = this;
    // 请求后台
    wx.request({
      method: 'POST',
      url: cgi.gradeSet.addOrg,
      data: obj,
      header: {
        'Content-Type': 'application/json',
        'token': that.data.token
      },
      success: function (res) {
        obj.orgid=res.data.data;
        list[length] = obj
        that.setData({
          dept: list,
          formData: ''
        })
        wx.hideLoading();
      },
      fail: function (res) {
        wx.showToast({
          title: '服务异常，请稍后重试。',
          icon: 'none'
        })
        wx.hideLoading();
      }
    });

    this.sw()
  },
  // 添加年级
  addGrade:function(){
    if (this.data.formData==""){
      wx.showToast({
        title: '年级名称不能为空',
        icon: 'none'
      })
      return;
    }
    wx.showLoading({
      title: '请稍后',
    });
    var list = this.data.gra
    var obj = {}
    var length = list.length
    obj.orgName = this.data.formData
    obj.subNum = 0;
    obj.parentId = this.data.orgid;
    obj.type = 'GRE';
    obj.orgAlias = obj.orgName;
    obj.status=1;
    obj.createUserId = this.data.userInfo.id;
    obj.createUserName = this.data.userInfo.userName;
    obj.modifyUserId = this.data.userInfo.id;
    obj.modifyUserName = this.data.userInfo.userName;
    let that = this;
    // 请求后台
    wx.request({
      method: 'POST',
      url: cgi.gradeSet.addOrg,
      data: obj,
      header: {
        'Content-Type': 'application/json',
        'token': that.data.token
      },
      success: function (res) {
        obj.orgid=res.data.data;
        list[length] = obj
        that.setData({
          gra: list,
          formData: ''
        })
        wx.hideLoading();
      },
      fail: function (res) {
        wx.showToast({
          title: '服务异常，请稍后重试。',
          icon: 'none'
        })
        wx.hideLoading();
      }
    });

    this.sw()
  },


  //新建班级
  addClass:function(){
    if (this.data.formDatac == "") {
      wx.showToast({
        title: '班级名称不能为空',
        icon: 'none'
      })
      return;
    }
    wx.showLoading({
      title: '请稍后',
    });
    var index = this.data.graClass
    // console.log(index)
    var gra = this.data.gra
    gra[index].subNum+=1;
    var obj = {}
    obj.orgName = this.data.formDatac
    obj.subNum = 0;
    obj.parentId = this.data.gra[index].orgid;
    obj.type = 'CLS';
    obj.orgAlias = obj.orgName;
    obj.status = 1;
    obj.createUserId = this.data.userInfo.id;
    obj.createUserName = this.data.userInfo.userName;
    obj.modifyUserId = this.data.userInfo.id;
    obj.modifyUserName = this.data.userInfo.userName;
    let that = this;
    // 请求后台
    wx.request({
      method: 'POST',
      url: cgi.gradeSet.addOrg,
      data: obj,
      header: {
        'Content-Type': 'application/json',
        'token': that.data.token
      },
      success: function (res) {
        obj.orgid=res.data.data;
        if (that.data.gra[index].subList == undefined) {
          var Cla = []
          Cla[0] = obj
          gra[index].subList = Cla
          that.setData({
            gra: gra
          })
        } else {
          var list = that.data.gra[index].subList;
          var length = list.length
          list[length] = obj
          gra[index].subList = list
          that.setData({
            gra: gra,
            formDatac: ''
          })
        }
        wx.hideLoading();
      },
      fail: function (res) {
        wx.showToast({
          title: '服务异常，请稍后重试。',
          icon: 'none'
        })
        wx.hideLoading();
      }
    });
    var show = this.data.selectedFlag
    show[index] = true
    this.setData({
      selectedFlag:show
    })
    wx.hideLoading();
    this.swc()
  },
  //输入职能部门
  handleChangeDept:function(e){
    this.setData({
      deptData: e.detail.value
    })
  },
  // 输入年级名称
  handleChange:function(e){
    this.setData({
      formData: e.detail.value
    })
  },
  // 输入机构名称
  handleOrgChange:function(e){
    this.setData({
      formEditData: e.detail.value
    })
  },
  handleChangec:function(e){
    this.setData({
      formDatac: e.detail.value
    })
  },

  // 删除职能部门
  delDept: function (e) {
    let that = this;
    wx.showModal({
      title: '提示',
      content: '确定删除职能部门？',
      success(resp) {
        if (resp.confirm) {
          wx.showLoading({
            title: '请稍后'
          });
          var obj = e.currentTarget.dataset.value
          
          wx.request({
            method: 'POST',
            url: cgi.gradeSet.delOrg,
            data: { 'orgid': obj.orgid },
            header: {
              'token': that.data.token
            },
            success: function (res) {
              wx.hideLoading();
              if (res.data.code == "200") {
                wx.showToast({
                  title: '删除职能部门成功',
                  icon: 'success',
                  duration: 2000
                })
                var list = that.data.dept;
                for (var i = 0; i < list.length; i++) {
                  if (list[i].orgid == obj.orgid) {
                    list.splice(i, 1)
                    that.setData({
                      dept: list
                    });
                  }
                }
              } else {
                wx.showToast({
                  title: res.data.message,
                  icon: 'none',
                  duration: 2000
                })
              }
            },
            fail: function (res) {
              wx.showToast({
                title: '服务异常，请稍后重试。',
                icon: 'none'
              })
              wx.hideLoading();
            }
          });
           
          wx.hideLoading();
        }
      }
    });
  },

  // 删除年级
  delGrade:function(e){
    let that = this;
    wx.showModal({
      title: '提示',
      content: '确定删除年级？',
      success(resp) {
        if (resp.confirm) {
          wx.showLoading({
            title: '请稍后'
          });
          var obj = e.currentTarget.dataset.value
          
          wx.request({
            method: 'POST',
            url: cgi.gradeSet.delOrg,
            data: { 'orgid': obj.orgid },
            header: {
              'token': that.data.token
            },
            success: function (res) {
              wx.hideLoading();
              if(res.data.code=="200"){
                wx.showToast({
                  title: '删除年级成功',
                  icon: 'success',
                  duration: 2000
                })
                var list = that.data.gra
                for (var i = 0; i < list.length; i++) {
                  if (list[i].orgid == obj.orgid) {
                    list.splice(i, 1)
                    that.setData({
                      gra: list
                    });
                  }
                }
              }else{
                wx.showToast({
                  title: res.data.message,
                  icon: 'none',
                  duration: 2000
                })
              }
            },
            fail: function (res) {
              wx.showToast({
                title: '服务异常，请稍后重试。',
                icon: 'none'
              })
              wx.hideLoading();
            }
          });
          wx.hideLoading();
        }
      }
    });
  },


  delClass:function(e){
    let that = this;
    wx.showModal({
      title: '提示',
      content: '确定删除班级？',
      success(resp) {
        if (resp.confirm) {
          wx.showLoading({
            title: '请稍后'
          });
          var lab = e.currentTarget.dataset.label
          
          wx.request({
            method: 'POST',
            url: cgi.gradeSet.delOrg,
            header: {
              'token': that.data.token
            },
            data: { 'orgid': lab.orgid },
            success: function (res) {
              wx.hideLoading();
              if (res.data.code == "200") {
                wx.showToast({
                  title: '删除班级成功',
                  icon: 'success',
                  duration: 2000
                })
                var gra = that.data.gra
                for (var j = 0; j < gra.length; j++) {
                  for (var i = 0; i < gra[j].subList.length; i++) {
                    if (gra[j].subList[i].orgid == lab.orgid) {
                      gra[j].subList.splice(i, 1)
                      gra[j].subNum--;
                      that.setData({
                        gra: gra
                      });
                      break;
                    }
                  }
                }
              } else {
                wx.showToast({
                  title: res.data.message,
                  icon: 'none',
                  duration: 2000
                })
              }
            },
            fail: function (res) {
              wx.showToast({
                title: '服务异常，请稍后重试。',
                icon: 'none'
              })
              wx.hideLoading();
            }
          });
          wx.hideLoading();
        } else if (resp.cancel) {
          console.log('用户点击取消')
        }
        
      }
    });
  },

  sfq:function(){
    var index = this.data.gra.length
    var selectedFlag = []
    for (let i = 0; i < index; i++) {
      if(i == 0){
        selectedFlag[i] = true
      }else{
        selectedFlag[i] = false
      }
      // console.log(selectedFlag)
      this.setData({
        selectedFlag:selectedFlag
      })
    }
  },

  // 跳转
  // two:function(e){
  //   var uid = e.currentTarget.dataset.label
  //   wx.navigateTo({
  //     url: '/pages/school/section/Gradetails/Gradetails'
  //   })
  // },
  initGrade:function(){
    let that = this;
    wx.showLoading({
      title: '请稍等...',
    })
    wx.request({
      method: 'POST',
      url: cgi.gradeSet.getOrgList,
      data: {'parentId':that.data.orgid},
      header: {
        'Content-Type': 'application/json',
        'token': that.data.token
      },
      success: function (res) {
        that.setData({
          gra: res.data.data
        })
        wx.hideLoading();
      },
      fail:function(res){
        wx.showToast({
          title: '获取数据失败，请重试。',
          icon: 'none'
        })
        wx.hideLoading();
      }
    })
  },
  initDept:function(){
    let that = this;
    wx.showLoading({
      title: '请稍等...',
    })
    wx.request({
      method: 'POST',
      url: cgi.gradeSet.getDeptList,
      data: {'parentId':that.data.orgid},
      header: {
        'Content-Type': 'application/json',
        'token': that.data.token
      },
      success: function (res) {
        that.setData({
          dept: res.data.data
        })
        wx.hideLoading();
      },
      fail:function(res){
        wx.showToast({
          title: '获取数据失败，请重试。',
          icon: 'none'
        })
        wx.hideLoading();
      }
    })
  },

  //获取头部学校信息
  getOrgById() {
    let that = this
    wx.getStorage({
      key: 'token',
      success: function (res) {
        that.setData({
          token: res.data
        })
        wx.getStorage({
          key: 'userInfo',
          success: function (res) {
            that.setData({
              orgid: res.data.orgid,
              userInfo:res.data
            })
            wx.request({
              method: 'POST',
              url: cgi.gradeSet.getOrg,
              data: {
                orgid: that.data.orgid
              },
              header: {
                'Content-Type': 'application/json',
                'token': that.data.token
              },
              header: {
                'content-type': 'application/json', // 默认值
                'token': that.data.token
              },
              success(res) {
                that.setData({
                  school: res.data.data
                })
              }
            });
            that.initGrade();
            that.initDept();
          },
        })
      },
    })


  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.getOrgById();
    this.sfq();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})