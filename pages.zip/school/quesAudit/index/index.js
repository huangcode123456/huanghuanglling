// pages/school/quesAudit/index/index.js
const cgi = require('../../../../constant/cgi.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    isSubmit:false,
    openid:'',
    orgid: '',
    orgName:'',
    today:'',
    deptList:[],
    classList:[],
    teacherNotWriteNum: '',//在职教师未填报总和
    workerNotWriteNum:'',//在职工人未填报总和


    todayIsSubmit: 0, //学校管理员今日是否提交 0未提交 1已提交

    teacherDeptId:'',
    workerDeptId:'',

    teacherQueryCount: 0,
    teacherQueryupnum: 0,
    teacherQuerynotupnum: 0,
    workerQueryCount: 0,
    workerQueryupnum: 0,
    workerQuerynotupnum: 0,
  },


  //获取部门问卷数据
  getDeptList() {
    let that = this;
    wx.request({
      method: "post",
      url: cgi.quesAudit.getAdminiList,
      data: {
        orgid: that.data.orgid,
      },
      header: {
        'content-type': 'application/json', // 默认值
        'token': wx.getStorageSync('token')
      },
      success(res) {
        console.log(res);
        // console.log(res)
        if (res.data.code == 200) {
          that.setData({
            deptList: res.data.data
          })
          console.log(that.data.deptList)

          res.data.data.map((item) => {
            if (item.org_name == "在职教师") {
              that.setData({
                teacherDeptId: item.orgid,
               
              });
              // 获取教师未填报名单
              item.records.map(record=>{
                console.log(record);
                if (record.status==1){
                  that.setData({
                    teacherNotWriteNum: record.studentnum,
                  });
                }
              })
            }
            if (item.org_name == "在职工人") {
              that.setData({
                workerDeptId: item.orgid,
              })
              // 获取在职工人未填报名单
              item.records.map(record => {
                console.log(record);
                if (record.status == 1) {
                  that.setData({
                    workerNotWriteNum: record.studentnum,

                  });
                }
              })
            }

          });
          console.log(that.data.teacherDeptId, that.data.workerDeptId);
          console.log(that.data.teacherNotWriteNum, that.data.workerNotWriteNum);

          // 查询学校管理员是否提交
          that.getQuerySchoolIsSubmitRes();
          
        } else {
          wx.showToast({
            icon: 'none',
            title: res.data.message,
          })
        }
      }
    })
  },



  // 查询学校管理员今日是否提交
  getQuerySchoolIsSubmitRes() {
    var that = this;
    wx.showLoading({
      title: '加载中...',
    })
    wx.request({
      method: 'POST',
      url: cgi.getQuerySchoolIsSubmitRes,
      data: {
        orgid: that.data.orgid,
      },
      header: {
        'Content-Type': 'application/json',
        'token': wx.getStorageSync("token") //从缓存获取token
      },
      success: function (res) {
        console.log(res)
        if (res.data.code == 200) {
          if (res.data.data.issubmit == '1') {
            that.getDeptNumRes();
          }
          that.setData({
            todayIsSubmit: res.data.data.issubmit
          })
          console.log(that.data.todayIsSubmit)
        } else {
          wx.showToast({
            icon: 'none',
            title: res.data.message,
          })
        }
        wx.hideLoading();
      }
    })
  },


  // 学校管理员提交弹窗确认
  submission() {
    var that = this;
    var notWriteNum = that.data.teacherNotWriteNum + that.data.workerNotWriteNum
    wx.showModal({
      title: '提示',
      content: notWriteNum > 0 ? '今天还有' + notWriteNum + '名教职工未更新问卷，是否确认他们今日问卷无变化？' : '确认是否提交今日教职工问卷信息？',
      success: function (res) {
        if (res.confirm) {
          console.log('确认提交');
          that.submitSchoolDept();
        }
      },
    })
  },

// 提交事件
  submitSchoolDept(){
    var that=this;
    that.setData({
      isSubmit: true
    })
    wx.request({
      method: 'POST',
      url: cgi.submitSchoolDept,
      header: {
        'Content-Type': 'application/json',
        'token': wx.getStorageSync("token") //从缓存获取token
      },
      success: function (res) {
        console.log(res)
        if (res.data.code == 200) {
          console.log(res);
          wx.showToast({
            title: '提交成功！',
            duration: 2000,
            success: function () {
              setTimeout(function () {
                that.getQuerySchoolIsSubmitRes();
              }, 2001);
            }
          })
          that.setData({
            isSubmit: false,
            todayIsSubmit: '1'
          })
        } else {
          that.setData({
            isSubmit: false
          })
          wx.showToast({
            icon: 'none',
            title: res.data.message,
          })
        }
      }
    })
  },


  // 获取班级问卷提交数据
  getClassList(){
    let that = this;
    wx.request({
      method: "post",
      url: cgi.getClassMessge,
      data: {
        orgid: that.data.orgid,
      },
      header: {
        'content-type': 'application/json', // 默认值
        'token': wx.getStorageSync('token')
      },
      success(res) {
       
        console.log(res);
        if (res.data.code == 200) {
          that.setData({
            classList: res.data.data
          })
          console.log(that.data.classList)
        } else {
          wx.showToast({
            icon: 'none',
            title: res.data.message,
          })
        }
      }
    })
  },


  // 查询学校部门复制情况统计
  getDeptNumRes(){
    this.getQueryDeptNumRes(this.data.teacherDeptId,'TEACHER'); //获取学校在职教师数据
    this.getQueryDeptNumRes(this.data.workerDeptId,'WORKER') ; //获取学校在职工人数据
  },

  getQueryDeptNumRes(deptId,type) {
    var that = this;
    wx.showLoading({
      title: '加载中...',
    })
    wx.request({
      method: 'POST',
      url: cgi.getQueryDeptNumRes,
      data: {
        dept_id: deptId,
      },
      header: {
        'Content-Type': 'application/json',
        'token': wx.getStorageSync("token") //从缓存获取token
      },
      success: function (res) {
        console.log(res,type)
        if (res.data.code == 200) {

          // teacherQueryCount: 0,
          //   teacherQueryupnum: 0,
          //     teacherQuerynotupnum: 0,
          //       workerQueryCount: 0,
          //         workerQueryupnum: 0,
          //           workerQuerynotupnum: 0,
          if(type== "TEACHER"){
            that.setData({
              teacherQueryCount: res.data.data.queryupnum + res.data.data.querynotupnum,
              teacherQueryupnum: res.data.data.queryupnum,
              teacherQuerynotupnum: res.data.data.querynotupnum,

            })
          } else if(type == "WORKER"){
            that.setData({
              workerQueryCount: res.data.data.queryupnum + res.data.data.querynotupnum,
              workerQueryupnum: res.data.data.queryupnum,
              workerQuerynotupnum: res.data.data.querynotupnum,
            })
          }
          
        } else {
          wx.showToast({
            icon: 'none',
            title: res.data.message,
          })
        }
        wx.hideLoading();
      }
    })
  },



  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    // 从缓存获取班级班级信息
    this.setData({
      orgid: wx.getStorageSync('userInfo').orgid,
      orgName: wx.getStorageSync('userInfo').orgName,
    })
    var t = new Date();
    this.setData({
      today: t.getFullYear() + '年' + (t.getMonth()+1) + '月' + t.getDate()+'日'
    });
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.getDeptList();
    this.getClassList();
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})