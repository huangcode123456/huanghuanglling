// pages/school/quesAudit/listWithStudents/listWithStudents.js
const cgi = require('../../../../constant/cgi.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    gradeName:'',
    className:'',
    class_id:'',
    list:[],
    noData: false
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log(options)
    this.setData({
      gradeName: options.gradeName,
      className: options.className,
      class_id: options.class_id
    })
  },


  //获取班级已提交学生列表
  getAdminClass() {
    let that = this;
    wx.request({
      method: "post",
      url: cgi.getClassListRes,
      data: {
        class_id: that.data.class_id,
        // status: 1
      },
      header: {
        'content-type': 'application/json', // 默认值
        'token': wx.getStorageSync('token')
      },
      success(res) {
        console.log(res)
        if (res.data.code == 200) {
          console.log(res);
          if (res.data.data && res.data.data.length > 0) {
            that.setData({
              list: res.data.data
            })
          } else {
            that.setData({
              noData: true
            })
          }
          console.log(that.data.list)
        } else {
          wx.showToast({
            icon: 'none',
            title: res.data.message,
          })
        }
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.setData({
      noData: false
    })
    this.getAdminClass();
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})