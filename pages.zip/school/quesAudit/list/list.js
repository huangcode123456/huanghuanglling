// pages/school/quesAudit/list/list.js
const cgi = require('../../../../constant/cgi.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    deptId:'',
    deptName:'',
    status:'',
    subTitle:'',
    num:0,
    userList:[],
    noData: false,
  },
  //获取老师问卷数据
  getTeacherList() {
    let that = this;
    wx.request({
      method: "post",
      url: cgi.quesAudit.getTeacherList,
      data: {
        dept_id: that.data.deptId,
        status: that.data.status
      },
      header: {
        'content-type': 'application/json', // 默认值
        'token': wx.getStorageSync('token')
      },
      success(res) {
        console.log(res, '23123')
        if (res.data.code == 200) {
          if (res.data.data.length > 0) {
            that.setData({
              userList: res.data.data
            })
          } else {
            that.setData({
              noData: true
            })
            wx.showToast({
              icon: 'none',
              title: '暂无' + that.data.subTitle,
              duration: 2000,
              success: function () {
                setTimeout(function () {
                  wx.navigateBack({
                    delta: 1
                  })
                }, 2001);
              }
            })
          }
          console.log(that.data.userList)
        } else {
          wx.showToast({
            icon: 'none',
            title: res.data.message,
          })
        }
      }
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log(options,'options')
    if (options && options.status){
      var title = "";
      if (options.status=="1"){
        title = "未填报名单";
      } else if (options.status == "2") {
        title = "已驳回名单";
      } else if (options.status == "3") {
        title = "已通过名单";
      }
      this.setData({
        deptId: options.deptId,
        deptName: options.deptName,
        status: options.status,
        subTitle:title,
        num: options.num
      })
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.getTeacherList();
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})