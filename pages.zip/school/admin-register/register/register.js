// pages/school/admin-register/register/register.js
const cgi = require('../../../../constant/cgi.js');
Page({
  data: {
    zhuce:true,
    formData: {
      token: '',
      openid: '',
      orgid: '123',
      password: '123456',
      name: '',
      passwordConfirm:'123456',
      type: '管理员',
      idcard: '',
      age: '',
      origin: '',
      address: '',
      sex: '',
      phone:''
    },
    rules: {
      phone:[
        { type: 'required', message: '手机号不能为空' },
        { type: 'customPhone', message: '手机号格式不正确' }
      ],
      name: [
        { type: 'required', message: '姓名不能为空' }
      ],
      // password: [
      //   { type: 'required', message: '密码不能为空' },
      //   { type: 'customPwd', message: '密码长度为6-12位' },
      // ],
      // passwordConfirm: [
      //   { type: 'required', message: '确认密码不能为空' },
      //   { type: 'passwordConfirm', message: '两次密码不一致' }
      // ],
      gender: [{ type: 'required', message: '请选择性别' }],
      Type: [
        { type: 'required', message: '管理员类型不能为空' }
      ],
      sex: [
        { type: 'required', message: '性别不能为空' }
      ],
      idcard: [
        { type: 'required', message: '身份证不能为空' },
        { type: 'customIdcard', message: '身份证格式不正确' }
      ],
      age: [
        { type: 'required', message: '年龄不能为空' },
        { type: 'customAge', message: '请输入正确的年龄' },
      ],
      // origin: [
      //   { type: 'required', message: '籍贯编码不能为空' }
      // ],
      address: [
        { type: 'required', message: '详细地址不能为空' }
      ],

    },
    validateType: {
      customIdcard(value, formData) {
        return /^[1-9]\d{7}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}$|^[1-9]\d{5}[1-9]\d{3}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}([0-9]|X)$/.test(value)
      },
      customPhone(value, formData) {
        return /^1[3456789]\d{9}$/.test(value)
      },
      customPwd(value, formData) {
        return value.length >= 6 && value.length <= 12
      }, 
      customAge(value, formData) {
        return /^(?:[1-9][0-9]?|1[01][0-9]|120)$/.test(value)
      },
      // passwordConfirm(value, formData) {
      //   return value == formData.password
      // },
    },
    genderRange: [
      { name: '男', value: 'M', displayName: '男' },
      { name: '女', value: 'F', displayName: '女' }
    ],
    texts: "学校管理员注册"
  },
  onLoad: function (options) {
    this.setData({
      [`formData.token`]:options.token,
      [`formData.orgid`]:options.orgid,
      [`formData.openid`]:options.openid
    })
  },
  // 输入
  handleChange(e) {
    console.log(e)
    this.setData({
      [`formData.${e.target.id}`]: e.detail.value.replace(/\s/g, '')
    })
  },
  idcardChange(e) {
    let idcard = e.detail.value;
    let sex = this.data.formData.sex;
    let age = this.data.formData.age;
    if (this.data.validateType.customIdcard(idcard)) {
      if (parseInt(idcard.substr(16, 1)) % 2 == 1) {
        sex = 'M';
      } else {
        sex = 'F';
      }
      var curDate = new Date();
      age = curDate.getFullYear() - parseInt(idcard.substr(6, 4));
    }
    this.setData({
      'formData.idcard': idcard,
      'formData.sex': sex,
      'formData.age': age
    })
  },
  // 登录
  handleFormSubmit(e) {
    let that=this;
    console.log(this.data.formData)
    if (e.detail.validStatus){
      if (that.data.zhuce){
        that.setData({
          zhuce:false
        })
        wx.request({
          method: 'post',
          url: cgi.adminRegist, //仅为示例，并非真实的接口地址
          data: {
            // createTime: new Date(),//当前时间
            openid: this.data.formData.openid,//openid
            orgid: this.data.formData.orgid,//机构id
            phone: this.data.formData.phone,//电话号码
            userPwd: this.data.formData.password,//密码
            type: 'SCH',//管理员
            userName: this.data.formData.name,//姓名
            sex: this.data.formData.sex,//性别
            idcard: this.data.formData.idcard,//身份证号码
            age: this.data.formData.age,//年龄
            origin: this.data.formData.origin,//籍贯
            address: this.data.formData.address//详细地址
            // sex:this.data.formData.sex,//性别
            // idcard: this.data.formData.idcard,//身份证号码
            // age: this.data.formData.age,//年龄
            // origin: this.data.formData.origin,//籍贯
            // address: this.data.formData.address//详细地址
          },
          header: {
            'content-type': 'application/json', // 默认值
            'token': this.data.formData.token
          },
          success(res) {
            that.setData({
              zhuce:true
            })
            wx.setStorage({
              key: 'schRole',
              data: 'SCH',
            })
            console.log(res.data)
            wx.showToast({
              icon: 'none',
              title: '注册成功',
            })
            wx.redirectTo({
              url: '/pages/school/admin-register/status/status?status=' + 1,
            })
          }
        })
      }else{
        wx.showToast({
          icon:'none',
          title: '请勿重复点击',
        })
      }
      
    }
    
    // const { validStatus, value: { name, password, passwordConfirm, Type, sex, idcard, age, origin, address} } = e.detail
    // console.log(e.detail)
  //   console.log(this.data.formData.password & this.data.formData.name & this.data.formData.passwordConfirm & this.data.formData.idcard & this.data.formData.age & this.data.formData.origin)
  //   if ((this.data.formData.password & this.data.formData.name & this.data.formData.passwordConfirm & this.data.formData.idcard & this.data.formData.age & this.data.formData.origin)!==0) {
  //     console.log(this.data.formData.sex)
  //     if(this.data.formData.address!==''){
  //       if(this.data.formData.sex=='H'){
  //       wx.hideToast();
  //       console.log('注册成功，，跳转至个人资料编辑页面...')
  //         wx.redirectTo({
  //           url: '/pages/school/myCenter/index/index',
  //       })
  //       }if(this.data.formData.sex=='F'){
  //         wx.hideToast();
  //         console.log('注册成功，，跳转至个人资料编辑页面...')
  //           wx.redirectTo({
  //             url: '/pages/school/myCenter/index/index',
  //         })
  //       }if(this.data.formData.sex==''){
  //         wx.showToast({
  //           title: '请补全信息',
  //           icon: 'fail'
  //         })
  //       }
  //     }else{
  //       wx.showToast({
  //         title: '请补全信息',
  //         icon: 'fail'
  //       })
  //     }
  //   }else{
  //     wx.showToast({
  //       title: '请补全信息',
  //       icon: 'fail'
  //     })
  //   }
  },

})
