// pages/school/admin-register/status/status.js
const cgi = require('../../../../constant/cgi.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    userInfo: null,
    openid: '',
    orgid:'',
    status: 0 // 状态 -1停用，0审核不通过，1待审核，2审核通过
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    if (options&&options.status) {
      this.setData({
        status: options.status,
        orgid: options.orgid,
        openid: options.openid
      });
    }
    let that = this;
    let openid = wx.getStorageSync("openid");
    console.log("缓存 中的openID" + openid)
    if(!openid){
      console.log("缓存 中没有openID")
      wx.login({
        success(res) {
          const code = res.code;
          console.log(code, "code");
          wx.request({
            url: cgi.loginTask.code2openid,
            data: { "code": code },
            success(resp) {
              console.log(resp, "openid");
              wx.setStorage({
                key: 'openid',
                data: resp.data.data.openid
              });
              that.setData({
                openid: resp.data.data.openid
              });

              that.refresh();
            }
          });
        }
      });
    }else{
      console.log("缓存 中有openID")
      that.setData({
        openid: openid
      });
      that.refresh();
    }
  },

  // 模拟刷新状态 -通过
  refresh() {
    console.log('刷新审核状态...')
    let that = this;
    console.log(that.data.userInfo, "userinfo");
    console.log(that.data.openid, "openid");
    wx.request({
      method: 'POST',
      url: cgi.loginTask.openidlogin,
      data: {
        openid: that.data.openid,
        type: 'SCH'
      },
      header: {
        'Content-Type': 'application/json'
      },
      success: function (res) {
        wx.setStorage({
          key: 'schRole',
          data: 'SCH',
        });
        console.log(res, "ss");
        that.setData({
          status: res.data.data.status,
          userInfo:res.data.data.userInfo
        });
        wx.removeStorage({
          key: 'userInfo',
          success: function(resp) {
            wx.setStorage({
              key: 'userInfo',
              data: res.data.data.userInfo
            })
          },
        })
      }
    });
  },

  // 审核通过跳转登录
  goToLogin() {
    wx.reLaunch({
      url: '/pages/school/admin-login/index',
    })
  },

  // 审核未通过，重新填写注册
  goToRegister() {
    let that = this;
    wx.request({
      method: 'POST',
      url: cgi.loginTask.delNopassUser,
      data: {
        userId: that.data.userInfo.id
      },
      header: {
        'Content-Type': 'application/json'
      },
      success: function (res) {
        if(res.data.code==200){
          wx.removeStorageSync("userInfo");
          let orgid = that.data.orgid;
          if(!orgid){
            orgid = that.data.userInfo.orgid;
          }
          console.log('/pages/school/admin-register/register/register?orgid=' + orgid + '&openid=' + that.data.openid,'二次注册链接');
          wx.redirectTo({
            url: '/pages/school/admin-register/register/register?orgid=' + orgid + '&openid=' + that.data.openid,
          })
        }
      }
    });
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})