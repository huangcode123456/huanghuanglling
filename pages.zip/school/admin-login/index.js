var appInst =  getApp();
const cgi = require('../../../constant/cgi.js');
Page({
  data: {
    //判断小程序的API，回调，参数，组件等是否在当前版本可用。
    canIUse: wx.canIUse('button.open-type.getUserInfo'),
    isHide: true,
    wxid: true,
    openid: '',

    formData: {
      password: '',
      name: '',
    },
    rules: {
      name: [
        { type: 'required', message: '账号不能为空' }
      ],
      password: [
        { type: 'required', message: '密码不能为空' }
      ]
    },
    texts: "学校管理员登录"
  },

  // 输入
  handleChange(e) {
    this.setData({
      [`formData.${e.target.id}`]: e.detail.value.replace(/\s/g, '')
    })
  },
  
  // 登录
  handleFormSubmit(e) {
    const { validStatus, value: { name, password } } = e.detail
    console.log(e.detail)

    if (validStatus) {
      wx.showLoading({
        title: '请稍等...',
      })
      wx.request({
        method: 'POST',
        url: cgi.loginTask.loginUser, 
        data: {
          account: this.data.formData.name,
          userPwd: this.data.formData.password
        },
        header: {
          'Content-Type': 'application/json'
        },
        success: function(res) {
          console.log(res,"login")
          // 登录成功跳转完成学校首页
          // console.log(res.data.status)
          if (res.data.code==200&&res.data.data.status==2) {
            wx.showToast({
              title: '登录成功',
              icon: 'success'
            })

            var token = res.data.data.token
            wx.setStorage({
              key:'token',
              data:token
            });
            wx.setStorage({
              key:'userInfo',
              data: res.data.data.userInfo
            });

            wx.hideLoading();
            if (res.data.data.infoCompleteStatus==1) {
              wx.reLaunch({
                url: '/pages/school/index/index',
              })
            }else{
              var url = "/pages/school/myCenter/profileEdit/profileEdit"
              var user = res.data.data.userInfo
              var id = user.id
              var account = user.account
              var orgid = user.orgid
              wx.setStorage(
                {
                  key:'userid',
                  data:id
                },
              )
              wx.setStorage(
                {
                  key:'orgid',
                  data:orgid
                },
              )
              wx.setStorage(
                {
                  key:'account',
                  data:account
                },
              )
              console.log(res.data.data.infoCompleteStatus,"res.data.data.infoCompleteStatus")
              if (res.data.data.infoCompleteStatus==0) {
                var firstLogin = 1
                wx.reLaunch({
                  url: '/pages/school/myCenter/profileEdit/profileEdit?firstLogin='+firstLogin
                })
              }else{
                wx.reLaunch({
                  url: url+'?orgid='+orgid,
                })
              }
            }
          }else{
            wx.showToast({
              title:'登录失败，请重新登录',
              icon: 'none'
            });
          }
         
        }
      })
    }
  },
  onLoad: function (options) {
    console.log(options,"options")
    // wx.clearStorageSync("useid");
    let that = this;
    wx.login({
      success (res) {
        const code = res.code;
        console.log(code,"code");
        wx.request({
          url: cgi.loginTask.code2openid,
          data: { "code": code},
          success(res) {
            console.log(res,"openid");
            wx.setStorage({
              key: 'openid',
              data: res.data.data.openid
            });
            that.setData({
              openid: res.data.data.openid
            });

            if (!options || !options.src || options.src != "logout") {
              that.openidlogin();
            }
          }
        })
      }
    })
  },
  // 自动登录
  openidlogin(){
    console.log('openid')
    let that = this;
    var openid = ''
    console.log({
      openid: that.data.openid,
      type: wx.getStorageSync('schRole')
    },'params')
    wx.request({
      method: 'POST',
      url: cgi.loginTask.openidlogin, 
      data: {
        openid: that.data.openid,
        type:wx.getStorageSync('schRole')
      },
      header: {
        'Content-Type': 'application/json'
      },
      success: function(res) {
        // 登录成功跳转完成学校首页
        console.log(res,"sch info")
        if (res.data.code==200&&res.data.data.status==2) {
          
          wx.showToast({
            title: '登录成功',
            icon: 'success'
          });

          var token = res.data.data.token
          wx.setStorage({
            key: 'token',
            data: token
          });
          wx.setStorage({
            key: 'userInfo',
            data: res.data.data.userInfo
          });
          console.log('登录成功...');
          wx.hideLoading();
          if (res.data.data.infoCompleteStatus==1) {
            wx.reLaunch({
              url: '/pages/school/index/index',
            })
          }else{
            var url = "/pages/school/myCenter/profileEdit/profileEdit"
            var user = res.data.data.userInfo
            // var id = user.id
            // var openid = user.openid
            var account = user.account
            // var user_name = user.userName
            // // var user_pws = 
            // var phone = user.phone
            // var type = user.type
            // var sex = user.sex
            // var idcard = user.idcard
            // var remark = user.remark
            // var create_time = user.create_time
            // var age = user.age
            // var origin = user.origin
            // var address = user.address
            // var link = user.link
            // var linkphone = user.linkphone
            var orgid = user.orgid
            // var grade_id = 
            // var class_id = 
            wx.setStorage(
              {
                key:'orgid',
                data:orgid
              },
            )
            wx.setStorage(
              {
                key:'account',
                data:account
              },
            )
            if (res.data.data.infoCompleteStatus==0) {
              var firstLogin = 1
              wx.reLaunch({
                url: '/pages/school/myCenter/profileEdit/profileEdit?'+'orgid='+orgid+'&firstLogin='+firstLogin
              })
            }
            wx.reLaunch({
              url: url+'?orgid='+orgid,
            })
          }
        } else if (res.data.data.status != 2) {
          wx.setStorage({
            key: 'userInfo',
            data: res.data.data.userInfo
          });
          wx.reLaunch({
            url: '/pages/school/admin-register/status/status?status=' + res.data.data.status + '&orgid=' + res.data.data.userInfo.orgid + '&openid=' + res.data.data.userInfo.openid,
          })
        }else{
          wx.showToast({
            title:'欢迎访问教委数据采集系统',
            icon: 'none'
          })
        }
       
      }
    })
  }
})
