// pages/school/audit/list_details/details.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    fruitTypeList: [
      {
        "fruitTypeId": 1,
        "typeName": "老师姓名"
      },
      {
        "fruitTypeId": 2,
        "typeName": "老师姓名"
      },
      {
        "fruitTypeId": 3,
        "typeName": "老师姓名"
      },
      {
        "fruitTypeId": 4,
        "typeName": "老师姓名"
      },
      {
        "fruitTypeId": 5,
        "typeName": "老师姓名"
      }, {
        "fruitTypeId": 6,
        "typeName": "老师姓名"
      },
      {
        "fruitTypeId": 7,
        "typeName": "老师姓名"
      },
      {
        "fruitTypeId": 8,
        "typeName": "老师姓名"
      }
    ],
    fruitList: [
      {
        "name": "性别",
        "list": [
          {
            "pkId": 1,
            "price": "5.8",
            "typeName": "否"
          },
          {
            "pkId": 2,
            "price": "2.08",
            "typeName": "香蕉"
          },
          {
            "pkId": 3,
            "price": "6.00",
            "typeName": "橙子"
          },
          {
            "pkId": 4,
            "price": "8.40",
            "typeName": "山竹"
          },
          {
            "pkId": 5,
            "price": "15",
            "typeName": "荔枝"
          },
          {
            "pkId": 6,
            "price": "5.8",
            "typeName": "芒果"
          },
          {
            "pkId": 7,
            "price": "2.10",
            "typeName": "西瓜"
          },
          {
            "pkId": 8,
            "price": "6.00",
            "typeName": "草莓"
          }
        ]
      },
      {
        "name": "状态",
        "list": [
        {
          "pkId": 1,
          "price": "5.40",
          "typeName": "苹果"
        },
        {
          "pkId": 2,
          "price": "2.20",
          "typeName": "香蕉"
        },
        {
          "pkId": 3,
          "price": "缺货",
          "typeName": "橙子"
        },
        {
          "pkId": 4,
          "price": "9.00",
          "typeName": "山竹"
        },
        {
          "pkId": 5,
          "price": "14.00",
          "typeName": "荔枝"
        },
        {
          "pkId": 6,
          "price": "5.50",
          "typeName": "芒果"
        },
        {
          "pkId": 7,
          "price": "1.89",
          "typeName": "西瓜"
        },
        {
          "pkId": 8,
          "price": "6.35",
          "typeName": "草莓"
        }
      ]
    },
    {
      "name": "体温",
      "list": [{
        "pkId": 1,
        "price": "6.10",
        "typeName": "苹果"
      },
      {
        "pkId": 2,
        "price": "2.30",
        "typeName": "香蕉"
      },

      {
        "pkId": 3,
        "price": "缺货",
        "typeName": "橙子"
      },
      {
        "pkId": 4,
        "price": "9.00",
        "typeName": "山竹"
      },
      {
        "pkId": 5,
        "price": "14.30",
        "typeName": "荔枝"
      },
      {
        "pkId": 6,
        "price": "5.65",
        "typeName": "芒果"
      },
      {
        "pkId": 7,
        "price": "2.08",
        "typeName": "西瓜"
      },
      {
        "pkId": 8,
        "price": "6.60",
        "typeName": "草莓"
      }
    ]
    },
    {
      "name": "备注",
      "list": [{
        "pkId": 1,
        "price": "4.80",
        "typeName": "苹果"
      },
      {
        "pkId": 2,
        "price": "1.98",
        "typeName": "香蕉"
      },

      {
        "pkId": 3,
        "price": "5.20",
        "typeName": "橙子"
      },
      {
        "pkId": 4,
        "price": "8.25",
        "typeName": "山竹"
      },
      {
        "pkId": 5,
        "price": "缺货",
        "typeName": "荔枝"
      },
      {
        "pkId": 6,
        "price": "5.8",
        "typeName": "芒果"
      },
      {
        "pkId": 7,
        "price": "2.28",
        "typeName": "西瓜"
      },
      {
        "pkId": 8,
        "price": "否",
        "typeName": "草莓"
      }
      ]
    }
    ],
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log(options.orgName)
    this.setData({
      orgName: options.orgName
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})