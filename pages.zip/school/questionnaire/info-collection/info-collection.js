// pages/school/questionnaire/info-collection/info-collection.js
const config = require('../../../../constant/config.js');
const cgi = require('../../../../constant/cgi.js');
Page({
  data: {
    nodctj:true,
    userInfo:{},
    arrow_icon: ['arrow-down', 'arrow-down'],
    show: [false, false],
    token: '',
    orgid: '',
    usertype:'',
    school: '',
    className:'',
    gradeName:'',
    age:'',
    sex:'',
    userName: '',
    userNumber: '',
    // first:1,//1是第一次，0不是第一次
    status:null,
    xuanzhong:"",//单选框
    formData: {
      bj_plan:'否',
      today_date_bj:'',
      today_dd_bj:'',
      bj_jtfs:'0',
      bj_jtxx:'',
      jcsf:'请选择',
      ljri:'',
      bjcr_isShow:false,

      postcode:'',
      checkboxd:'否',
      schoolname: '',
      stuid: '',
      name:'',
      agetmp:'',
      age:'',
      checkboxA:'否',
      date: '年-月-日',
      adress:'',
      contactname:'',
      tel:'',
      region: ['省','市', '区/县'],
      transport:0,
      transportinfo:'',
      radioA: '否',
      re_transport: 0,
      re_transportinfo: '',
      return_date: '年-月-日',
      
      days:0,
      checkboxB:'否',
      contact_location:'',
      contact_date: '年-月-日',
      contact_type:'',
      contact_name:'',
      city:'',
      be_transportinfo:'',

      radioB: '否',
      radioC: '否',
      department:'初三2班',
      plan:'在京',
      temperature:'',
      symptom:[],
      diagnose:'',
      choose:'否',
      checkcondition:[],
      today_date:'年-月-日',
      today_destinationtype: '境内',
      today_destinationregion: ['省', '市', '区/县'],
      today_destination: '',
      // today_return_date: '年-月-日',
      today_re_transport:0,
      today_transportinfo:'',
      today_radioB:'否',
      unwell:'否',
      checkcondition1:[],
      checkcondition2: [],
      live_value: [],
      nationality:'中国籍',
      country:'',
      destinationtype:'境内',
      destination:'',
      destinationregion: ['省', '市', '区/县'],
      today_re_destinationtype: '境内',
      today_re_destinationregion: ['省', '市', '区/县'],
      today_re_destination: '',
    },
 
    livecheckItems: [
      { name: 'live', value: '住校' },
    ],

    stayItems: [
      { name: '否', value: '否' },
      { name: '是', value: '是' },
    ],
    jtfs: ['请选择', '地铁', '公交', '出租车', '自行车', '步行','其他'],
    transportRange: ['请选择','飞机', '火车', '自驾', '长途汽车', '其它交通工具'],
    contacttypeRange: [
      { name: '聚会', value: 'a', displayName: '聚会' },
      { name: '学习交流', value: 'b', displayName: '学习交流' },
      { name: '乘坐交通', value: 'c', displayName: '乘坐交通' },
      { name: '其他', value: 'd', displayName: '其他' },
      { name: '无接触', value: 'e', displayName: '无接触' },
    ],
    check2Items: [
      { name: '发热', value: '发热' },
      { name: '干咳', value: '干咳' },
    ],
    check3Items: [
      { name: '呼吸道或消化道不适', value: '呼吸道或消化道不适' },
    ],
    check4Items: [
      { name: '其他', value: '其他' },
    ],
    redioItems1: [
      { name: '在京', value: '在京' },
      { name: '不在京', value: '不在京' },
      { name: '出京', value: '出京' },
      { name: '返京', value: '返京' },
    ],
    redioItems_bj:[
      { name: '否', value: '否' },
      { name: '是', value: '是'},
    ],
    redioItems2: [
      { name: '是', value: '1' },
      { name: '否', value: '0' },
    ],
    nationalityItems: [
      { name: '中国籍', value: '中国籍' },
      { name: '外国籍', value: '外国籍' },
    ],
    destinationtypeItems: [
      { name: '境内', value: '境内' },
      { name: '境外', value: '境外' },
    ],
  },
  // getOrgById() {
  //   let that = this
  //   wx.getStorage({
  //     key: 'token',
  //     success: function (res) {
  //       console.log(res)
  //       that.setData({
  //         token: res.data
  //       })
  //       wx.getStorage({
  //         key: 'userInfo',
  //         success: function (res) {
  //           console.log('res.data:' , res.data)
  //           that.setData({
  //             orgid: res.data.orgid,
  //             usertype: (res.data.type == 'CLS' || res.data.type == 'RPT')?'学生':'教职工',
  //             className: res.data.className == null ? '未知' : res.data.className,
  //             sex: res.data.sex == 'M' ? '男' : '女',
  //             userName:res.data.userName,
  //             userNumber: res.data.userNumber == '' ? '未知' : res.data.userNumber,
              
  //             [`formData.schoolname`]: res.data.orgName == '' ? '未知' : res.data.orgName
  //           })
  //           wx.request({
  //             method: 'post',
  //             url: cgi.gradeSet.getOrg,
  //             data: {
  //               orgid: that.data.orgid
  //             },
  //             header: {
  //               'content-type': 'application/json', // 默认值
  //               //'token': that.data.token
  //               'token': wx.getStorageSync('token')
                
  //             },
  //             success(res) {
  //               console.log('res.data.data',res.data.data)
  //               console.log(res.data.data.address == null)
  //               that.setData({
  //                 school: res.data.data
  //               })
  //             }
  //           })
  //         },
  //       })
  //     },
  //   })
  // },
  handleTap(e){//切换隐藏
    console.log(e)
    let inx=e.currentTarget.dataset.inx
    let show=this.data.show;
    let arrow_icon = this.data.arrow_icon
    console.log(arrow_icon)
    arrow_icon[inx] = 'arrow-up',
    console.log(arrow_icon)
    if(show[inx]==false){
      
      show[inx]=true
      this.setData({
        show,
        arrow_icon
      })
    }else{
      arrow_icon[inx] = 'arrow-down',
      show[inx] = false
      this.setData({
        show,
        arrow_icon
      })
    }
  },
  //获取缓存信息
  getStorage(){
    let that=this
    wx.getStorage({
      key: 'userInfo',
      success: function(res) {
        console.log(res,"user info")
        that.setData({
          [`formData.schoolname`]:res.data.orgName,
          className: res.data.className,
          gradeName: res.data.gradeName,
          userName: res.data.userName,
          sex: res.data.sex == 'M' ? '男' : res.data.sex == 'F' ? '女' : '',
          userNumber:res.data.userNumber,
          [`formData.age`]: (res.data.age == null || res.data.age =='null') ? '' : res.data.age,
        })
      },
    })
  },
  //lx:查询当天是否填写问卷
  queryTodayQuestionary(){
    wx.showLoading({
      title: '加载中',
    })
    let that=this;
    wx.getStorage({
      key: 'userInfo',
      success: function (res) {
        that.setData({
          userInfo: res.data,
        });
      }
    });
    wx.request({
      method:'post',
      url: cgi.queryTodayQuestionary, //仅为示例，并非真实的接口地址
      data: {
        
      },
      header: {
        'content-type': 'application/json', // 默认值
        'token': wx.getStorageSync('token')
      },
      success(res) {
        console.log(res.data,"2222")
        // console.log(res.data.data.record.informationRegister.split('#'))
        wx.hideLoading()
        
        if (res.data.data.record == null && res.data.data.todaySubmitStatus== 0){
          that.getStorage()
          that.setData({
            status: 1
          })
        } else if (res.data.data.record != null && res.data.data.todaySubmitStatus == 0){       
          that.setData({
            status: 1
          })
          console.log('此人当天没有提交记录，以前有')
          //今日身体状态回写
          if (res.data.data.record.todayPhysicalConditions.indexOf("#")) {
            let arr = [];
            let arr1 = [];
            let arr2 = [];
            let str = ''
            for (let i = 0; i < res.data.data.record.todayPhysicalConditions.split('#').length; i++) {
              let a = res.data.data.record.todayPhysicalConditions.split('#')[i]
              console.log(res.data.data.record.todayPhysicalConditions.split('#')[i])
              if (a == '干咳') {
                arr.push('干咳')
              } else if (a == '发热') {
                arr.push('发热')
              } else if (a == '呼吸道或消化道不适') {
                arr1.push('呼吸道或消化道不适')
              } else if (a == '其他') {
                arr2.push('其他')
              } else {
                str = a
              }
            }
            console.log(str)
            that.setData({
              [`formData.checkcondition`]: arr,
              [`formData.checkcondition1`]: arr1,
              [`formData.checkcondition2`]: arr2,
              [`formData.symptom`]: str
            })
          } else {
            if (res.data.data.record.todayPhysicalConditions == '发热') {
              that.setData({
                [`formData.checkcondition`]: ['发热']
              })
            } else if (res.data.data.record.todayPhysicalConditions == '干咳') {
              that.setData({
                [`formData.checkcondition`]: ['干咳']
              })
            } else if (res.data.data.record.todayPhysicalConditions == '呼吸道或消化道不适') {
              that.setData({
                [`formData.checkcondition1`]: ['呼吸道或消化道不适']
              })
            }
          }
          let show = [false,false];
          let arrow_icon = ['arrow-down','arrow-down']

          let transportRange = that.data.transportRange;
          let index1 = 0
          let index2 = 0
          let index3 = 0
          for (let i = 0; i < transportRange.length; i++) {
            console.log(transportRange[i])
            console.log(res.data.data.record.visitorComeWay)
            if (transportRange[i] == res.data.data.record.visitorComeWay) {
              console.log(i)
              index1 = i
            }
            if (transportRange[i] == res.data.data.record.todayGoBackWay) {
              index2 = i
            }
            if (transportRange[i] == res.data.data.record.goBackWay){
              index3=i
            }
          }

          //新增
          let jtfs = that.data.jtfs;
          let index4=0;
          for (let i = 0; i < jtfs.length;i++){
            if (jtfs[i] == res.data.data.record.todayGoOutInsideCityWay){
              index4=i
            }
          }
          console.log(res.data.data, "my question data")
          var receivedHubeiProvince = res.data.data.record.receivedHubeiProvince;
          // console.log(receivedHubeiProvince.split("#")[0], "my question data")
          console.log(receivedHubeiProvince,'///////////**********')
          if (receivedHubeiProvince && receivedHubeiProvince.split("#")[0] == '北京市') {
            that.setData({
              [`formData.bjcr_isShow`]: true
            })
          }
          that.setData({
            //新增 ：今日是否在京出行
            [`formData.bj_plan`]: res.data.data.record.todayGoOutInsideCityStatus == '' ? '否' : res.data.data.record.todayGoOutInsideCityStatus,
            [`formData.today_date_bj`]: res.data.data.record.todayGoOutInsideCityTime,
            [`formData.today_dd_bj`]: res.data.data.record.todayGoOutInsideCityDestination,
            [`formData.bj_jtfs`]:index4,
            [`formData.bj_jtxx`]: res.data.data.record.todayGoOutInsideCityTrafficInformation,
            [`formData.jcsf`]: res.data.data.record.receivedHubeiStatus == '是' ? res.data.data.record.receivedHubeiProvince != null ? res.data.data.record.receivedHubeiProvince.split('#') : '请选择' : '请选择',
            [`formData.ljri`]: res.data.data.record.visitorComeTime != '' ? res.data.data.record.visitorComeTime != null ? res.data.data.record.visitorComeTime.slice(0, -9) : '' : '',

            //假期出行活动
            [`formData.checkboxA`]: res.data.data.record.goOutStatus,
            [`formData.date`]: res.data.data.record.goOutTime == null ? '请选择' : res.data.data.record.goOutTime.slice(0, -9),
            [`formData.destinationtype`]: res.data.data.record.goOutCountry != '境内' ? res.data.data.record.goOutCountry != '' ? '境外' : '境内' : res.data.data.record.goOutCountry,
            [`formData.destinationregion`]: res.data.data.record.goOutCountry == '境内' ? res.data.data.record.goOutDestination.split('#') : '请选择',
            [`formData.destination`]: res.data.data.record.goOutCountry != '境内' ? res.data.data.record.goOutCountry : '',
            [`formData.radioA`]: res.data.data.record.goBackStatus == '' ? '否' : res.data.data.record.goBackStatus,
            [`formData.return_date`]: res.data.data.record.goBackTime == null ? '请选择' : res.data.data.record.goBackTime.slice(0, -9),
            [`formData.re_transport`]: index3,
            [`formData.transportinfo`]: res.data.data.record.goBackTrafficInformation,
            [`formData.radioB`]: res.data.data.record.beenToHubeiStatus == '' ? '否' : res.data.data.record.beenToHubeiStatus,

            //是否接待过来自湖北或返京。。。。。。。。
            [`formData.checkboxB`]: res.data.data.record.receivedHubeiStatus,
            [`formData.contact_date`]: res.data.data.record.receivedHubeiTime == null ? '' : res.data.data.record.receivedHubeiTime.slice(0, -9),
            [`formData.contact_location`]: res.data.data.record.visitorReceivePlace,
            [`formData.contact_name`]: res.data.data.record.visitorName,
            [`formData.city`]: res.data.data.record.visitorComeFrom,
            [`formData.transport`]: index1,//被接待人来京方式
            [`formData.be_transportinfo`]: res.data.data.record.visitorComeTrafficInformation,

            //今日出行信息
            //出京
            [`formData.plan`]: res.data.data.record.todayGoOutPlan,
            [`formData.today_date`]: res.data.data.record.todayGoOutTime == null ? '' : res.data.data.record.todayGoOutTime.slice(0, -9),
            [`formData.today_destinationtype`]: res.data.data.record.todayGoOutCountry != '境内' ? res.data.data.record.todayGoOutCountry != '' ? '境外' : '境内' : res.data.data.record.todayGoOutCountry,
            [`formData.today_destinationregion`]: res.data.data.record.todayGoOutCountry == '境内' ? res.data.data.record.todayGoOutDestination.split('#') : '',
            [`formData.today_destination`]: res.data.data.record.todayGoOutCountry != '境内' ? res.data.data.record.todayGoOutCountry : '',

            //返京
            // [`formData.today_return_date`]: res.data.data.record.todayGoBackTime == null ? '年-月-日' : res.data.data.record.todayGoBackTime.slice(0,-9),
            [`formData.today_re_transport`]: index2,
            [`formData.today_re_destinationtype`]: res.data.data.record.todayGoBackCountry != '境内' ? res.data.data.record.todayGoBackCountry != '' ? '境外' : '境内' : res.data.data.record.todayGoBackCountry,
            [`formData.today_re_destinationregion`]: res.data.data.record.todayGoBackCountry == '境内' ? res.data.data.record.todayGoBackDestination.split('#') : '',
            [`formData.today_re_destination`]: res.data.data.record.todayGoBackCountry != '境内' ? res.data.data.record.todayGoBackCountry : '',
            [`formData.today_transportinfo`]: res.data.data.record.todayGoBackTrafficInformation,
            [`formData.today_radioB`]: res.data.data.record.beenToHubeiStatus,

            //是否身体不适
            [`formData.unwell`]: res.data.data.record.todayFeelNotGood,
            [`formData.temperature`]: res.data.data.record.todayTemperature,
            [`formData.choose`]: res.data.data.record.seeDoctorStatus,
            [`formData.diagnose`]: res.data.data.record.seeDoctorStatus == '是' ? res.data.data.record.medicingResult : '',
            show,
            arrow_icon,
            // [`formData.schoolname`]: res.data.data.record.informantSchool,
            // className: res.data.data.record.informantClass,
            // userName: res.data.data.record.informantName,
            // sex: res.data.data.record.informantSex,
            // userNumber: res.data.data.record.studentNumber,
            // [`formData.age`]: res.data.data.record.informantAge == null ? '' : res.data.data.record.informantAge,
            [`formData.adress`]: res.data.data.record.informantAddress,
            [`formData.contactname`]: res.data.data.record.informantGuardian,
            [`formData.tel`]: res.data.data.record.informantGuardianPhone,
            // xuanzhong: res.data.data.record.informantBoarder == '住校' ? true : false,       
            [`formData.checkboxd`]: res.data.data.record.informantBoarder,
            [`formData.country`]: res.data.data.record.informantNation != '中国籍'?res.data.data.record.informantNation:'',
            [`formData.nationality`]: res.data.data.record.informantNation!='中国籍'?'外国籍':'中国籍',
            [`formData.region`]: res.data.data.record.informantNation == '中国籍' ? res.data.data.record.informationRegister.split('#') : ['省', '市', '区/县']
          })
          that.getStorage();//性别年龄数据还是保证从缓存中取
        } else if (res.data.data.record != null && res.data.data.todaySubmitStatus == 1){
          if (res.data.data.record.todayPhysicalConditions.indexOf("#")) {
            let arr=[];
            let arr1=[];
            let arr2=[];
            let str=''
            for (let i = 0; i < res.data.data.record.todayPhysicalConditions.split('#').length; i++) {
              let a = res.data.data.record.todayPhysicalConditions.split('#')[i]
              console.log(res.data.data.record.todayPhysicalConditions.split('#')[i])
              if(a=='干咳'){
                arr.push('干咳')
              }else if(a=='发热'){
                arr.push('发热')
              }else if(a=='呼吸道或消化道不适'){
                arr1.push('呼吸道或消化道不适')
              }else if(a=='其他'){
                arr2.push('其他')
              }else{
                str=a
              }
            }
            console.log(str)
            that.setData({
              [`formData.checkcondition`]:arr,
              [`formData.checkcondition1`]:arr1,
              [`formData.checkcondition2`]:arr2,
              [`formData.symptom`]:str
            })
          }else{
            if (res.data.data.record.todayPhysicalConditions=='发热'){
              that.setData({
                [`formData.checkcondition`]:['发热']
              })
            } else if (res.data.data.record.todayPhysicalConditions == '干咳'){
              that.setData({
                [`formData.checkcondition`]: ['干咳']
              })
            } else if (res.data.data.record.todayPhysicalConditions == '呼吸道或消化道不适') {
              that.setData({
                [`formData.checkcondition1`]: ['呼吸道或消化道不适']
              })
            }
          }


          console.log('此人当天有提交记录')
          let show = [false, false];
          let arrow_icon = ['arrow-down', 'arrow-down']

          let transportRange = that.data.transportRange;
          let index1 = 0
          let index2 = 0
          let index3 = 0
          for (let i = 0; i < transportRange.length; i++) {
            console.log(transportRange[i])
            console.log(res.data.data.record.visitorComeWay)
            if (transportRange[i] == res.data.data.record.visitorComeWay) {
              console.log(i)
              index1 = i
            }
            if (transportRange[i] == res.data.data.record.todayGoBackWay) {
              index2 = i
            }
            if (transportRange[i] == res.data.data.record.goBackWay) {
              index3 = i
            }
          }

          //新增
          let jtfs = that.data.jtfs;
          let index4 = 0;
          for (let i = 0; i < jtfs.length; i++) {
            if (jtfs[i] == res.data.data.record.todayGoOutInsideCityWay) {
              index4 = i
            }
          }
          console.log(res.data.data,"my question data")
          var receivedHubeiProvince = res.data.data.record.receivedHubeiProvince;
          console.log(receivedHubeiProvince.split("#")[0],"my question data")
          if (receivedHubeiProvince && receivedHubeiProvince.split("#")[0]=='北京市'){
            that.setData({
              [`formData.bjcr_isShow`]:true
            })
          }
          that.setData({
            //新增 ：今日是否在京出行
            [`formData.bj_plan`]: res.data.data.record.todayGoOutInsideCityStatus == '' ? '否' : res.data.data.record.todayGoOutInsideCityStatus,
            [`formData.today_date_bj`]: res.data.data.record.todayGoOutInsideCityTime,
            [`formData.today_dd_bj`]: res.data.data.record.todayGoOutInsideCityDestination,
            [`formData.bj_jtfs`]: index4,
            [`formData.bj_jtxx`]: res.data.data.record.todayGoOutInsideCityTrafficInformation,
            [`formData.jcsf`]: res.data.data.record.receivedHubeiStatus == '是' ? res.data.data.record.receivedHubeiProvince != null?res.data.data.record.receivedHubeiProvince.split('#') : '请选择':'请选择',
            [`formData.ljri`]: res.data.data.record.visitorComeTime != '' ? res.data.data.record.visitorComeTime != null ?res.data.data.record.visitorComeTime.slice(0, -9) : '':'',

            //假期出行活动
            [`formData.checkboxA`]: res.data.data.record.goOutStatus,
            [`formData.date`]: res.data.data.record.goOutTime == null ? '请选择' : res.data.data.record.goOutTime.slice(0, -9),
            [`formData.destinationtype`]: res.data.data.record.goOutCountry != '境内' ? res.data.data.record.goOutCountry != '' ? '境外' : '境内' : res.data.data.record.goOutCountry,
            [`formData.destinationregion`]: res.data.data.record.goOutCountry == '境内' ? res.data.data.record.goOutDestination.split('#') : '请选择',
            [`formData.destination`]: res.data.data.record.goOutCountry != '境内' ? res.data.data.record.goOutCountry : '',
            [`formData.radioA`]: res.data.data.record.goBackStatus == '' ? '否' : res.data.data.record.goBackStatus,
            [`formData.return_date`]: res.data.data.record.goBackTime == null ? '请选择' : res.data.data.record.goBackTime.slice(0, -9),
            [`formData.re_transport`]: index3,
            [`formData.transportinfo`]: res.data.data.record.goBackTrafficInformation,
            [`formData.radioB`]: res.data.data.record.beenToHubeiStatus == '' ? '否' : res.data.data.record.beenToHubeiStatus,

            //是否接待过来自湖北或返京。。。。。。。。
            [`formData.checkboxB`]: res.data.data.record.receivedHubeiStatus,
            [`formData.contact_date`]: res.data.data.record.receivedHubeiTime == null ? '' : res.data.data.record.receivedHubeiTime.slice(0, -9),
            [`formData.contact_location`]: res.data.data.record.visitorReceivePlace,
            [`formData.contact_name`]: res.data.data.record.visitorName,
            [`formData.city`]: res.data.data.record.visitorComeFrom,
            [`formData.transport`]: index1,//被接待人来京方式
            [`formData.be_transportinfo`]: res.data.data.record.visitorComeTrafficInformation,

            //今日出行信息
            //出京
            [`formData.plan`]: res.data.data.record.todayGoOutPlan,
            [`formData.today_date`]: res.data.data.record.todayGoOutTime == null ? '' : res.data.data.record.todayGoOutTime.slice(0, -9),
            [`formData.today_destinationtype`]: res.data.data.record.todayGoOutCountry != '境内' ? res.data.data.record.todayGoOutCountry != '' ? '境外' : '境内' : res.data.data.record.todayGoOutCountry,
            [`formData.today_destinationregion`]: res.data.data.record.todayGoOutCountry == '境内' ? res.data.data.record.todayGoOutDestination.split('#') : '',
            [`formData.today_destination`]: res.data.data.record.todayGoOutCountry != '境内' ? res.data.data.record.todayGoOutCountry : '',

            //返京
            // [`formData.today_return_date`]: res.data.data.record.todayGoBackTime == null ? '年-月-日' : res.data.data.record.todayGoBackTime.slice(0, -9),
            [`formData.today_re_transport`]: index2,
            [`formData.today_re_destinationtype`]: res.data.data.record.todayGoBackCountry != '境内' ? res.data.data.record.todayGoBackCountry != '' ? '境外' : '境内' : res.data.data.record.todayGoBackCountry,
            [`formData.today_re_destinationregion`]: res.data.data.record.todayGoBackCountry == '境内' ? res.data.data.record.todayGoBackDestination.split('#') : '',
            [`formData.today_re_destination`]: res.data.data.record.todayGoBackCountry != '境内' ? res.data.data.record.todayGoBackCountry : '',
            [`formData.today_transportinfo`]: res.data.data.record.todayGoBackTrafficInformation,
            [`formData.today_radioB`]: res.data.data.record.beenToHubeiStatus,

            //是否身体不适
            [`formData.unwell`]: res.data.data.record.todayFeelNotGood,
            [`formData.temperature`]: res.data.data.record.todayTemperature,
            [`formData.choose`]: res.data.data.record.seeDoctorStatus,
            [`formData.diagnose`]: res.data.data.record.seeDoctorStatus == '是' ? res.data.data.record.medicingResult : '',
            show,
            arrow_icon,
            id: res.data.data.record.id,
            // [`formData.schoolname`]: res.data.data.record.informantSchool,
            // className: res.data.data.record.informantClass,
            // userName: res.data.data.record.informantName,
            // sex: res.data.data.record.informantSex,
            // userNumber: res.data.data.record.studentNumber,
            // [`formData.age`]: res.data.data.record.informantAge == null ? '' : res.data.data.record.informantAge,
            [`formData.adress`]: res.data.data.record.informantAddress,
            [`formData.contactname`]: res.data.data.record.informantGuardian,
            [`formData.tel`]: res.data.data.record.informantGuardianPhone,
            //xuanzhong: res.data.data.record.informantBoarder == '住校' ? true : false,
            [`formData.checkboxd`]: res.data.data.record.informantBoarder,
            [`formData.country`]: res.data.data.record.informantNation != '中国籍' ? res.data.data.record.informantNation : '',
            [`formData.nationality`]: res.data.data.record.informantNation != '中国籍' ? '外国籍' : '中国籍',
            [`formData.region`]: res.data.data.record.informantNation == '中国籍' ? res.data.data.record.informationRegister.split('#') : ['省', '市', '区/县']
          })
          that.getStorage();//性别年龄数据还是保证从缓存中取
          if (res.data.data.record.status==1){
            wx.showModal({
              title: '提示',
              content: '您今天已提交问卷，目前还未审核，是否需要修改？',
              success(res) {
                if (res.confirm) {
                  // that.setData({
                  //   status:1
                  // })
                  console.log(that.data.status)
                  console.log('用户点击确定')
                } else if (res.cancel) {
                  wx.navigateBack({
                    delta: 1
                  })
                }
              }
            }) 
          } else if (res.data.data.record.status == 2){
            console.log(res,"res res ")
            if (res.data.data.record.canUpdateStatus=="1"){
              wx.showModal({
                title: '提示',
                content: '问卷已经通过审核，1天只有1次修改机会。是否确认继续修改？',
                success(res) {
                  if (res.confirm) {
                    console.log('用户点击确定')

                  } else if (res.cancel) {
                    console.log('用户点击取消')
                    wx.navigateBack({
                      delta: 1
                    })
                  }
                }
              })
            }else{
              wx.showModal({
                title: '提示',
                content: '你的问卷已审核通过两次，今天不能继续修改。',
                showCancel: false,
                success(res) {
                  if (res.confirm) {
                    console.log('用户点击确定')
                    wx.navigateBack({
                      delta: 1
                    })
                  } else if (res.cancel) {
                    console.log('用户点击取消')
                  }
                }
              })
            }
          } else if (res.data.data.record.status == 0){
            that.setData({
              // status:1,
              approveInfo: res.data.data.record.approveInfo
            })
            console.log(that.data.approveInfo)
            wx.showModal({
              title: '提示',
              content: '您的问卷已被驳回,请修改后重新提交',
              showCancel: false,
              success(res) {
                if (res.confirm) {
                  console.log('用户点击确定')
                  wx.showModal({
                    title: '审核说明',
                    content: that.data.approveInfo == null ? '驳回' : that.data.approveInfo,
                    showCancel: false,
                    success(res) {
                      if (res.confirm) {
                        console.log('用户点击确定')
                      } else if (res.cancel) {
                        console.log('用户点击取消')
                      }
                    }
                  })
                } else if (res.cancel) {
                  console.log('用户点击取消')
                }
              }
            })
          }
        }
      }
    })
  },

  onLoad: function (options) {
    // 生命周期函数--监听页面加载
    // this.getStorage()
    this.queryTodayQuestionary()
    // this.getOrgById();
    // this.searchQuestionary();
    // this.getQuestionaryStatus();
  },
 
  onChangeShowState  (e) {
    
    var that = this;
    that.setData({
      showView: (!that.data.showView),
      [`formData.${e.target.id}`]: e.detail.value,
    })
  },
  onChangeShowgoState(e) {
    var that = this;
    that.setData({
      go_showView: (!that.data.go_showView),
      [`formData.${e.target.id}`]: e.detail.value,
    })
  },
  checkboxd(e){
    var that = this;
    console.log(e)
    that.setData({
      // show14View: (!that.data.show14View),
      [`formData.${e.target.id}`]: e.detail.value,
    })
  },
  onChangeShow14State (e) {
    var that = this;
    that.setData({
      show14View: (!that.data.show14View),
      [`formData.${e.target.id}`]: e.detail.value,
    })
  },
  onChangeShowReturnState (e) {
    console.log(e)
    var that = this;
    that.setData({
      re_showView: (!that.data.re_showView),
      [`formData.${e.target.id}`]: e.detail.value,
    })
  },
  handleChange(e) {
    if(e.currentTarget.id=="region"){
      this.setData({
        [`formData.postcode`]:e.detail.postcode
      })
      console.log(this.data.formData.postcode)
    }
    console.log(e)
    if(e.currentTarget.id=='jcsf'){
      if(e.detail.value[0]=='北京市'){
        console.log('是北京市')
        this.setData({
          [`formData.bjcr_isShow`]: true
        })
        console.log(this.data.formData.bjcr_isShow)
      } else if (e.detail.value[0] !== '北京市'){
        console.log('不是北京市')
        this.setData({
          [`formData.bjcr_isShow`]: false
        })
      }
    }
    
    if (e.currentTarget.id =="checkcondition2"){
      if(e.detail.value.length==0){
        this.setData({
          [`formData.symptom`]:''
        })
      }
    }

    if (e.detail.value=='外国籍'){
      this.setData({
        [`formData.region`]: ['省', '市', '区/县']
      })
    } else if (e.detail.value == '中国籍'){
      this.setData({
        [`formData.country`]: ''
      })
    }

    if (e.currentTarget.id == "destinationtype"){
      if (e.detail.value == '境内') {
        this.setData({
          [`formData.destination`]: '',
        })
      } else if (e.detail.value == '境外') {
        this.setData({
          [`formData.destinationregion`]: ['省', '市', '区/县'],
        })
      }
    } else if (e.currentTarget.id == "today_re_destinationtype"){
      if (e.detail.value == '境内') {
        this.setData({
          [`formData.today_destination`]: '',
        })
      } else if (e.detail.value == '境外') {
        this.setData({
          [`formData.today_destinationregion`]: ['省', '市', '区/县']
        })
      }
    }
    // if(e.detail.value=='境内'){
    //   this.setData({
    //     [`formData.destination`]:'',
    //     [`formData.today_destination`]:'',
    //   })
    // } else if (e.detail.value == '境外'){
    //   this.setData({
    //     [`formData.destinationregion`]: ['省', '市', '区/县'],
    //     [`formData.today_destinationregion`]: ['省', '市', '区/县']
    //   })
    // }
    console.log(e)
    this.setData({
      [`formData.${e.target.id}`]: e.detail.value
    })

    if (e.currentTarget.id == 'temperature') {
      if (e.detail.value.length>1&&e.detail.value<33){
        this.setData({
          [`formData.temperature`]:33
        })
      } else if (e.detail.value.length > 1 &&e.detail.value >45){
        this.setData({
          [`formData.temperature`]: 45
        })
      }else{
        this.setData({
          [`formData.temperature`]: e.detail.value
        })
      }
    }
  },
  
  trans_gettransportway(way) {
    var index=0 ;
    if (way == '飞机') {
      index = 1;
    }
    else if (way == '火车') {
      index = 2;
    }
    else if (way == '自驾') {
      index = 3;
    }
    else if (way == '长途汽车') {
      index = 4;
    }
    else if (way == '其他') {
      index = 5;
    }
    return index;

  },
  // searchQuestionary() {
  //   var that=this;
  //   wx.request({
  //     method: 'get',
  //     url: config.urlPrefix + '/client/questionary/searchQuestionary',

  //     header: {
  //       'content-type': 'application/json', // 默认值
  //       'token': wx.getStorageSync('token')
  //     },
  //     success(res) {
  //       console. log('searchQuestionary:', res.data)
  //       if (res.data.code == 200) {
  //         if (res.data.data == null) {
  //           console.log('第一次访问')
  //           // that.first=1;
  //           that.setData({
  //             first:1
  //           })
  //         }
  //         else {
  //           that.setData({
  //             first:0,
  //             [`formData.radioB`]: res.data.data.beenToHubeiStatus == null ? "否" : res.data.data.beenToHubeiStatus,//假期出京-返京-是否到过或经停过湖北地区
  //             [`formData.region[1]`]: res.data.data.informantCity,//市
  //             [`formData.region[0]`]: res.data.data.informantProvince,//省
  //             [`formData.region[2]`]: res.data.data.informantRegion,//区/县
  //             [`formData.live_value[0]`]: res.data.data.informantBoarder == '住校' ? 'live' : '',//是否住校
  //             [`formData.adress`]: res.data.data.informantAddress,//在京详细居住地址
  //             [`formData.contactname`]: res.data.data.informantGuardian,//监护人/紧急联系人
  //             [`formData.tel`]: res.data.data.informantGuardianPhone,//联系电话 / 紧急联系人电话
  //             [`formData.destinationregion`]: that.trans_region(res.data.data.goOutDestination),//出京目的地-境内
              
  //             [`formData.checkboxA`]: res.data.data.goOutStatus == null ? "否" : res.data.data.goOutStatus,//假期是否出京
  //             [`formData.date`]: (res.data.data.goOutTime != null && res.data.data.goOutTime.length>11)?res.data.data.goOutTime.substring(0, res.data.data.goOutTime.length - 9):'',//出京时间

  //             [`formData.radioA`]: res.data.data.goBackStatus == null ? "否" : res.data.data.goBackStatus,//是否返京
  //             [`formData.return_date`]: (res.data.data.goBackTime != null && res.data.data.goBackTime.length>11)?res.data.data.goBackTime.substring(0, res.data.data.goBackTime.length-9):'',//返京时间
  //             [`formData.transportinfo`]: res.data.data.goBackTrafficInformation,//返京乘坐交通信息
  //             [`formData.re_transport`]: that.trans_gettransportway(res.data.data.goBackWay),//返京方式
  //             [`formData.destinationregion`]: that.trans_region(res.data.data.goOutDestination),//返京乘坐交通信息
  //             [`formData.diagnose`]: res.data.data.medicingResult,//医院诊断结果
  //             [`formData.checkboxB`]: res.data.data.receivedHubeiStatus == null ? "否" : res.data.data.receivedHubeiStatus,//是否接待过来自湖北或返京经过湖北的来京人员
  //             [`formData.contact_date`]: (res.data.data.receivedHubeiTime != null && res.data.data.receivedHubeiTime.length > 11) ? res.data.data.receivedHubeiTime.substring(0, res.data.data.receivedHubeiTime.length - 9) : '',//接待日期
  //             [`formData.choose`]: res.data.data.seeDoctorStatus == null ? "否" : res.data.data.seeDoctorStatus,//是否就医
  //             [`formData.unwell`]: res.data.data.todayFeelNotGood == null ? "否" : res.data.data.todayFeelNotGood,//今日是否身体不适
  //             [`formData.today_return_date`]: (res.data.data.todayGoBackTime != null && res.data.data.todayGoBackTime.length > 11) ? res.data.data.todayGoBackTime.substring(0, res.data.data.todayGoBackTime.length - 9) : '',//今日返京时间
  //             [`formData.today_transportinfo`]: res.data.data.todayGoBackTrafficInformation,//今日返京乘坐交通信息
  //             [`formData.today_re_transport`]: that.trans_gettransportway(res.data.data.todayGoBackWay),//今日返京方式
  //             [`formData.today_destinationregion`]: that.trans_region(res.data.data.todayGoOutDestination),//今日出京目的地-境内
  //             [`formData.plan`]: res.data.data.todayGoOutPlan,//今日出行计划
  //             [`formData.today_date`]: (res.data.data.todayGoOutTime != null && res.data.data.todayGoOutTime.length > 11) ? res.data.data.todayGoOutTime.substring(0, res.data.data.todayGoOutTime.length - 9) : '',//今日出京时间
  //             [`formData.checkcondition`]: that.trans_todayPhysicalConditions(res.data.data.todayPhysicalConditions,'0'),//今日身体状况, 多个
  //             [`formData.checkcondition1`]: that.trans_todayPhysicalConditions(res.data.data.todayPhysicalConditions,'1'),//今日身体状况, 多个
  //             [`formData.checkcondition2`]: that.trans_todayPhysicalConditions(res.data.data.todayPhysicalConditions,'2'),//今日身体状况, 多个
  //             [`formData.symptom`]:that.trans_todayPhysicalConditions(res.data.data.todayPhysicalConditions, '3'),//其他症状
  //             [`formData.temperature`]: res.data.data.todayTemperature,//今日今日体温
  //             [`formData.city`]: res.data.data.visitorComeFrom,//被接待人来自湖北哪个地区
  //             [`formData.be_transportinfo`]: res.data.data.visitorComeTrafficInformation,//被接待人来京乘坐交通信息
  //             [`formData.transport`]: that.trans_gettransportway(res.data.data.visitorComeWay),//今日返京方式
  //             [`formData.contact_name`]: res.data.data.visitorName,//被接待人姓名
  //             [`formData.contact_location`]: res.data.data.visitorReceivePlace,//在北京接待地点
  //             [`formData.country`]: res.data.data.informantNation == '中国籍' ? '中国籍' : res.data.data.informantNation,//国籍
  //             [`formData.nationality`]: res.data.data.informantNation == '中国籍' ? '中国籍' : '外国籍',//国籍

  //             [`formData.destination`]: res.data.data.goOutCountry == '境内' ? '境内' : res.data.data.goOutCountry,//假期出京国内还是境外
  //             [`formData.destinationtype`]: res.data.data.goOutCountry == '境内' ? '境内' : '境外',//假期出京国内还是境外

  //             [`formData.today_destination`]: res.data.data.todayGoOutCountry ==  '境内' ? '境内' :res.data.data.todayGoOutCountry,//今日出京国内还是境外
  //             [`formData.today_destinationtype`]: res.data.data.todayGoOutCountry == '境内' ? '境内' : '境外',//今日出京国内还是境外
  //             [`formData.today_re_destination`]: res.data.data.todayGoBackCountry  == '境内' ? '境内'  : res.data.data.todayGoBackCountry,//今日出京国内还是境外
  //             [`formData.today_re_destinationtype`]: res.data.data.todayGoBackCountry == '境内' ? '境内' : '境外',//今日出京国内还是境外
  //             [`formData.today_re_destinationregion`]: that.trans_region(res.data.data.todayGoBackDestination),//今日返京目的地
  //           })
            //   [`formData.today_re_destination`]: res.data.data.todayGoBackCountry  == '境内' ? '境内'  : res.data.data.todayGoBackCountry,//今日出京国内还是境外
            //   [`formData.today_re_destinationtype`]: res.data.data.todayGoBackCountry == '境内' ? '境内' : '境外',//今日出京国内还是境外
            //   [`formData.today_re_destinationregion`]: that.trans_region(res.data.data.todayGoBackDestination),//今日返京目的地

            //   [`formData.age`]: res.data.data.informantAge,//填报人年龄
            // })
  //         }

  //       } else {
  //         wx.showToast({
  //           title: res.data.message,
  //           icon: 'none',
  //           duration: 2000
  //         })
  //       }
  //     }
  //   })
  // },
  // getQuestionaryStatus(){
  //   var that = this;
  //   wx.request({
  //     method: 'get',
  //     url: config.urlPrefix + '/client/questionary/getQuestionaryStatus',

  //     header: {
  //       'content-type': 'application/json', // 默认值
  //       'token': wx.getStorageSync('token')
  //     },
  //     success(res) {
  //       console.log('getQuestionaryStatus:',res.data)
  //       //message = res.data.message;
  //       //status = res.data.code;
  //       if (res.data.code == 1) {
          
  //         wx.showModal({
  //           title: '提示',
  //           content: '未审核，是否更新',
  //           cancelText:'否',
  //           confirmText:'是',
  //           success(infores) {
  //             if (infores.confirm) {
  //               //that.searchQuestionary();
  //               that.setData({
  //                 status: res.data.code,
  //               })
  //             } else if (infores.cancel) {
  //               wx.navigateBack({

  //               })
  //             }
  //           }
  //         })
  //       }
  //       else if (res.data.code == 2){
  //         wx.showModal({
  //           title: '提示',
  //           content: '已审核,' + res.data.message+',是否更新',
  //           cancelText: '否',
  //           confirmText: '是',
  //           success(infores) {
  //             if (infores.confirm) {
  //               //that.searchQuestionary();
  //               that.setData({
  //                 status: res.data.code,
  //               })
  //             } else if (infores.cancel) {
  //               wx.navigateBack({

  //               })
  //             }
  //           }
  //         })
  //       }
  //       else if (res.data.code == -1){
  //         wx.showModal({
  //           title: '提示',
  //           content: '已驳回,' + res.data.message + ',请更新',
  //           confirmText: '确定',
  //           showCancel: false,
  //           success(infores) {
  //             if (infores.confirm) {
  //               //that.searchQuestionary();
  //               that.setData({
  //                 status: res.data.code,
  //               })
  //             } 
  //           }
  //         })
  //       }
       
  //     }
  //   })
  // },
  trans_region(strDestionation){
    var list = [];
    if (strDestionation=='')
    {
      list = ['省', '市', '区/县']
    }
    else{
      while (strDestionation.indexOf('#') >= 0) {
        var index = strDestionation.indexOf('#');
        var str = strDestionation.substring(0, index);
        strDestionation = strDestionation.substring(index + 1);
        list.push(str)
      }
      list.push(strDestionation)
    }
    
    return list
  },
  trans_todayPhysicalConditions(todayPhysicalConditions,idx){
    let checkcondition=[];
    let checkcondition1=[];
    let checkcondition2=[];
    let symptom='';
    while (todayPhysicalConditions.indexOf('#')>=0)
    {
      var index = todayPhysicalConditions.indexOf('#');
      var str = todayPhysicalConditions.substring(0,index);
      todayPhysicalConditions = todayPhysicalConditions.substring(index+1);
      if (str == '发热' || str == '干咳')
      {
        checkcondition.push(str);
      }
      else if (str == '呼吸道或消化道不适')
      {
        checkcondition1.push(str);
      }
      else if (str == '其他'){
        checkcondition2.push(str);
      }
      else{
        symptom=str;
      }
    }
    if (todayPhysicalConditions == '发热' || todayPhysicalConditions == '干咳') {
      checkcondition.push(todayPhysicalConditions);
    }
    else if (todayPhysicalConditions == '呼吸道或消化道不适') {
      checkcondition1.push(todayPhysicalConditions);
    }
    else if (todayPhysicalConditions == '其他'){
      checkcondition2.push(todayPhysicalConditions);
    }
    else {
      symptom += todayPhysicalConditions;
    }
    if(idx=="0")
    {
      return checkcondition
    }
    else if (idx == "1") {
      return checkcondition1
    }
    else if (idx == "2") {
      return checkcondition2
    }
    else if (idx == "3")  {
      return symptom
    }

  },
  handleFormSubmit(e) {
    let agree1 = true; let agree2 = true; let agree3 = true;
    let agree4 = true; let agree5 = true; let agree6 = true;
    let agree7 = true; let agree8 = true; let agree9 = true;
    let agree10 = true; let agree11 = true; let agree12 = true
    //基本信息判断
    if (this.data.formData.nationality == '中国籍') {
      //console.log(this.data.formData.region == '省', '市','区/县')
      if (this.data.formData.region[0] == '省' || this.data.formData.region=='请选择') {
        wx.showToast({
          icon: 'none',
          title: '户口所在地不能为空',
          duration: 2000,
        })
        agree1=false
      }else{
        agree1=true
      }
    }
    if (this.data.formData.nationality == '外国籍') {
      if (this.data.formData.country == '') {
        wx.showToast({
          icon: 'none',
          title: '国籍不能为空',
          duration: 2000,
        })
        agree2=false
      }else{
        agree2=true
      }
    }
    if (this.data.formData.age==''){
      wx.showToast({
        icon:'none',
        title: '年龄不能为空',
        duration: 2000,
      })
      agree3 = false
    } else if (this.data.formData.adress==''){
      wx.showToast({
        icon: 'none',
        title: '详细居住地址不能为空',
        duration: 2000,
      })
      agree3 = false
    } else if (this.data.formData.contactname==''){
      wx.showToast({
        icon: 'none',
        title: '紧急联系人不能为空',
        duration: 2000,
      })
      agree3 = false
    } else if (this.data.formData.tel==''){
      wx.showToast({
        icon: 'none',
        title: '紧急联系人电话不能为空',
        duration: 2000,
      })
      agree3 = false
    } else{
      agree3 = true;
    }

    //假期出行活动判断
    if (this.data.formData.checkboxA=='是'){
      if (this.data.formData.date == '年-月-日' || this.data.formData.date=='请选择'){
        wx.showToast({
          icon: 'none',
          title: '出京时间不能为空',
          duration: 2000,
        })
        agree4 = false
      } else if (this.data.formData.destinationtype=='境内'){
        if (this.data.formData.destinationregion[0] == '省' || this.data.formData.destinationregion=='请选择'){
          wx.showToast({
            icon: 'none',
            title: '出京目的地不能为空',
            duration: 2000,
          })
          agree4 = false
        }else{
          agree4 = true
        }
      } else if (this.data.formData.destinationtype == '境外'){
        if (this.data.formData.destination==''){
          wx.showToast({
            icon: 'none',
            title: '出京目的地不能为空',
            duration: 2000,
          })
          agree4 = false
        }else{
          agree4 = true
        }
      }else{
        agree4 = true
      }
    }
    if (this.data.formData.checkboxA == '是'){
      if (this.data.formData.radioA=='是'){
        if (this.data.formData.return_date == '年-月-日' || this.data.formData.return_date=='请选择'){
          wx.showToast({
            icon: 'none',
            title: '返京时间不能为空',
            duration: 2000,
          })
          agree5=false
        }else if (this.data.formData.re_transport==0){
          wx.showToast({
            icon: 'none',
            title: '返京方式不能为空',
            duration: 2000,
          })
          agree5 = false
        } else if (this.data.formData.transportinfo==''){
          wx.showToast({
            icon: 'none',
            title: '返京乘坐交通信息不能为空',
            duration: 2000,
          })
          agree5 = false
        }else{
          agree5 = true
        }
      }
    }

    
    //今日状态
    if (this.data.formData.checkboxB=='是'){
      if (this.data.formData.contact_date == '年-月-日' || this.data.formData.contact_date==''){
        wx.showToast({
          icon: 'none',
          title: '接待或接触日期不能为空',
          duration: 2000,
        })
        agree6 = false
      } else if (this.data.formData.contact_location==''){
        wx.showToast({
          icon: 'none',
          title: '接待或接触地点不能为空',
          duration: 2000,
        })
        agree6 = false
      } else if (this.data.formData.contact_name==''){
        wx.showToast({
          icon: 'none',
          title: '被接待或接触人姓名不能为空',
          duration: 2000,
        })
        agree6 = false
      } else if (this.data.formData.city==''){
        wx.showToast({
          icon: 'none',
          title: '被接待或接触人来自湖北哪个区不能为空',
          duration: 2000,
        })
        agree6 = false
      } 
      // else if (this.data.formData.transport==0){
      //   wx.showToast({
      //     icon: 'none',
      //     title: '被接待人来京方式不能为空',
      //     duration: 2000,
      //   })
      //   agree6 = false
      // } 
      else if (this.data.formData.jcsf=='请选择'){
        wx.showToast({
          icon: 'none',
          title: '接触省份不能为空',
          duration: 2000,
        })
        agree6 = false
      }
      // else if (this.data.formData.be_transportinfo==''){
      //   wx.showToast({
      //     icon: 'none',
      //     title: '被接待人来京乘坐交通信息不能为空',
      //     duration: 2000,
      //   })
      //   agree6 = false
      // }
      else{
        agree6 = true
      }
    }

    if (this.data.formData.checkboxB == '是'){
      if (this.data.formData.jcsf[0]=='北京市'){
        if (this.data.formData.transport==0){
          wx.showToast({
            icon: 'none',
            title: '被接待人来京方式不能为空',
            duration: 2000,
          })
          agree12 = false
        }else if (this.data.formData.be_transportinfo==''){
          wx.showToast({
            icon: 'none',
            title: '被接待人来京乘坐交通信息不能为空',
            duration: 2000,
          })
          agree12 = false
        }else{
          agree12 = true
        }
      }
    }

    if (this.data.formData.plan=='出京'){
      console.log(this.data.formData.today_date,'2222')
      if (this.data.formData.today_date == '年-月-日' || this.data.formData.today_date ==''){
        wx.showToast({
          icon: 'none',
          title: '出京时间不能为空',
          duration: 2000,
        })
        agree7 = false
      } else if (this.data.formData.today_destinationtype=='境内'){
        if (this.data.formData.today_destinationregion[0] == '省' || this.data.formData.today_destinationregion == '请选择' || this.data.formData.today_destinationregion ==''){
          wx.showToast({
            icon: 'none',
            title: '出京目的地不能为空',
            duration: 2000,
          })
          agree7 =false
        }else{
          agree7 = true
        }
      } else if (this.data.formData.today_destinationtype == '境外'){
        if (this.data.formData.today_destination==''){
          wx.showToast({
            icon: 'none',
            title: '出京目的地不能为空',
            duration: 2000,
          })
          agree7 = false
        }else{
          agree7 = true
        }
      }else{
        agree7 = true
      }
    }

    if (this.data.formData.plan == '返京'){
      // if (this.data.formData.today_return_date=='年-月-日'){
      //   wx.showToast({
      //     icon: 'none',
      //     title: '返京时间不能为空',
      //     duration: 2000,
      //   })
      //   agree8 = false
      // } else 
      if (this.data.formData.today_re_transport==0){
        wx.showToast({
          icon: 'none',
          title: '返京方式不能为空',
          duration: 2000,
        })
        agree8 = false
      } else if (this.data.formData.today_transportinfo==''){
        wx.showToast({
          icon: 'none',
          title: '今日返京乘坐交通信息不能为空',
          duration: 2000,
        })
        agree8 = false
      } else if (this.data.formData.today_re_destinationtype=='境内'){
        if (this.data.formData.today_re_destinationregion[0] == '省' || this.data.formData.today_re_destinationregion=='请选择'){
          wx.showToast({
            icon: 'none',
            title: '返京地点不能为空',
            duration: 2000,
          })
          agree8 = false
        }else{
          agree8 = true
        }
      } else if (this.data.formData.today_re_destinationtype == '境外'){
        if (this.data.formData.today_re_destination==''){
          wx.showToast({
            icon: 'none',
            title: '返京地点不能为空',
            duration: 2000,
          })
          agree8 = false
        }else{
          agree8 = true
        }
      }else{
        agree8 = true
      }
    }

    if (this.data.formData.unwell=='是'){
      if(this.data.formData.temperature < 33 || this.data.formData.temperature>45){
        wx.showToast({
          icon: 'none',
          title: '体温数据有误，请重新输入',
          duration: 2000,
        })
        agree9 = false
      }else if (this.data.formData.temperature == '' || this.data.formData.temperature==null){
        wx.showToast({
          icon: 'none',
          title: '今日体温不能为空',
          duration: 2000,
        })
        agree9 = false
      }else if (this.data.formData.checkcondition.length == 0 && this.data.formData.checkcondition1.length == 0 && this.data.formData.checkcondition2.length == 0){
        wx.showToast({
          icon: 'none',
          title: '今日身体状态不能为空',
          duration: 2000,
        })
        agree9 = false
      } else if (this.data.formData.checkcondition2.length == 1){
        if (this.data.formData.symptom==''){
          wx.showToast({
            icon: 'none',
            title: '其他症状不能为空',
            duration: 2000,
          })
          agree9 = false
        }else{
          agree9 = true
        }
      }else{
        agree9 = true
      }
    }

    if (this.data.formData.unwell == '是'){
      if (this.data.formData.choose=='是'){
        if (this.data.formData.diagnose==''){
          wx.showToast({
            icon: 'none',
            title: '医院诊断结果不能为空',
            duration: 2000,
          })
          agree10=false
        }else{
          agree10 = true
        }
      }
    }

    if (this.data.formData.bj_plan=='是'){
      if (this.data.formData.today_date_bj==''){
        wx.showToast({
          icon: 'none',
          title: '在京出行时间不能为空',
          duration: 2000,
        })
        agree11 = false
      } else if (this.data.formData.today_dd_bj==''){
        wx.showToast({
          icon: 'none',
          title: '在京出行地点不能为空',
          duration: 2000,
        })
        agree11 = false
      } else if (this.data.formData.bj_jtfs==0){
        wx.showToast({
          icon: 'none',
          title: '在京出行交通方式不能为空',
          duration: 2000,
        })
        agree11 = false
      // } else if (this.data.formData.bj_jtxx==''){//在京出行交通信息可以为空
      //   wx.showToast({
      //     icon: 'none',
      //     title: '在京出行交通信息不能为空',
      //     duration: 2000,
      //   })
      //   agree11 = false
      }
    }
    // console.log(agree)

    const { validStatus, value: { name } } = e.detail
	var todayPhysicalConditions='';
	for(var i=0;i<this.data.formData.checkcondition.length;i++)
	{
		if(this.data.formData.checkcondition[i]!='')
		{
			todayPhysicalConditions+=this.data.formData.checkcondition[i]+'#';
		}
	}
	if(this.data.formData.checkcondition1.length>0)
	{
		todayPhysicalConditions+=this.data.formData.checkcondition1[0]+'#';
	}
	if(this.data.formData.checkcondition2.length>0)
	{
		todayPhysicalConditions+=this.data.formData.checkcondition2[0]+'#';
	}
    if (todayPhysicalConditions.length>0)
    {
      todayPhysicalConditions = todayPhysicalConditions.substring(0, todayPhysicalConditions.length - 1);
    }
    if (this.data.formData.symptom != '' && this.data.formData.symptom !=null)
    {
      todayPhysicalConditions += '#' + this.data.formData.symptom;
    }

    console.log(todayPhysicalConditions)
    var transportway='';
    //console.log('this.data.formData.region:' , this.data.formData.region)
    console.log(e)
    if (validStatus) {
      var submitData = {
        informantCityCode: this.data.formData.postcode,
        beenToHubeiStatus: this.data.formData.checkboxA == '是' ? this.data.formData.radioA == '是' ? this.data.formData.radioB:'':'',
        //this.data.formData.plan == '返京' ? this.data.formData.today_radioB : '',
        //this.data.formData.radioB,//假期出京-返京-是否到过或经停过湖北地区
        goBackStatus: this.data.formData.checkboxA == '是' ? this.data.formData.radioA : '',//是否返京
        goBackTime: this.data.formData.checkboxA == '是' ? this.data.formData.radioA == '是' ? (this.data.formData.return_date + " 00:00:00") : '' : '',
        //(this.data.formData.return_date == '年-月-日' || this.data.formData.return_date == '') ? '' : (this.data.formData.return_date + " 00:00:00"),//返京时间
        goBackTrafficInformation: this.data.formData.checkboxA == '是' ? this.data.formData.radioA == '是' ? this.data.formData.transportinfo : '' : '',
        //this.data.formData.transportinfo,//返京乘坐交通信息
        goBackWay: this.data.formData.radioA=='是'?this.data.formData.re_transport == 0 ? '' : this.data.transportRange[this.data.formData.re_transport]:'',//返京方式
        goOutDestination: this.data.formData.checkboxA == '是' ? this.data.formData.destinationtype == '境内' ? (this.data.formData.destinationregion[0] + '#' + this.data.formData.destinationregion[1] + '#' + this.data.formData.destinationregion[2]) : '' : '',
        //this.data.formData.destinationregion[0] == '省' ? '' : (this.data.formData.destinationregion[0] + '#' + this.data.formData.destinationregion[1] + '#' + this.data.formData.destinationregion[2]),//出京目的地-境内
        goOutStatus: this.data.formData.checkboxA,//假期是否出京
        goOutTime: this.data.formData.checkboxA == '是' ? (this.data.formData.date + " 00:00:00") : '',
        //(this.data.formData.date == '年-月-日' || this.data.formData.date == '') ? '' : (this.data.formData.date + " 00:00:00"),//出京时间
        informantBoarder: this.data.formData.checkboxd,//是否住校
        informantAddress: this.data.formData.adress,//在京详细居住地址
        informantAge: this.data.formData.age,//填报人年龄
        informationRegister: this.data.formData.region[0] == '省' ? '' : (this.data.formData.region[0] + '#' + this.data.formData.region[1] + '#' + this.data.formData.region[2]),//户口所在地
        informantCity: this.data.formData.region[1],//市
        informantProvince: this.data.formData.region[0],//省
        informantRegion: this.data.formData.region[2],//区/县
        informantIdentity: this.data.usertype,//身份
        informantGuardian: this.data.formData.contactname,//监护人/紧急联系人
        informantGuardianPhone: this.data.formData.tel,//联系电话/紧急联系人电话
        informantName: this.data.userName,//填报人姓名
        informantSex: this.data.sex,//填报人性别
        medicingResult: this.data.formData.unwell == '是' ? this.data.formData.choose == '是' ? this.data.formData.diagnose : '' : '',//医院诊断结果
        receivedHubeiStatus: this.data.formData.checkboxB,//是否接待过来自湖北或返京经过湖北的来京人员
        receivedHubeiTime: this.data.formData.checkboxB == '是' ? (this.data.formData.contact_date + " 00:00:00") : '',
        //(this.data.formData.contact_date == '年-月-日' || this.data.formData.contact_date == '') ? '' : (this.data.formData.contact_date + " 00:00:00"),//接待日期
        seeDoctorStatus: this.data.formData.unwell == '是' ? this.data.formData.choose : '',//是否就医
        studentNumber: this.data.userNumber,//学号
        todayFeelNotGood: this.data.formData.unwell,//今日是否身体不适
        // todayGoBackTime: this.data.formData.plan == '返京' ? (this.data.formData.today_return_date + " 00:00:00") : '',
        //(this.data.formData.today_return_date == '年-月-日' || this.data.formData.today_return_date == '') ? '' : (this.data.formData.today_return_date + " 00:00:00"),//今日返京时间
        todayGoBackTrafficInformation: this.data.formData.plan == '返京' ? this.data.formData.today_transportinfo : '',//今日返京乘坐交通信息
        todayGoBackWay: this.data.formData.plan == '返京' ? this.data.transportRange[this.data.formData.today_re_transport] : '',
        //this.data.formData.today_re_transport == 0 ? '' : this.data.transportRange[this.data.formData.today_re_transport],//今日返京方式
        todayGoOutDestination: this.data.formData.plan == '出京' ? this.data.formData.today_destinationtype == '境内' ? (this.data.formData.today_destinationregion[0] + '#' + this.data.formData.today_destinationregion[1] + '#' + this.data.formData.today_destinationregion[2]):'':'',
        //this.data.formData.today_destinationregion[0] == '省' ? '' : (this.data.formData.today_destinationregion[0] + '#' + this.data.formData.today_destinationregion[1] + '#' + this.data.formData.today_destinationregion[2]),//今日出京目的地-境内
        todayGoOutPlan: this.data.formData.plan,//今日出行计划
        todayGoOutTime: this.data.formData.plan == '出京' ? (this.data.formData.today_date + " 00:00:00"):'',
        //(this.data.formData.today_date == '年-月-日' || this.data.formData.today_date == '') ? '' : (this.data.formData.today_date + " 00:00:00"),//今日出京时间
        todayPhysicalConditions: this.data.formData.unwell == '是' ? todayPhysicalConditions : '',//今日身体状况, 多个
        todayTemperature: this.data.formData.unwell == '是' ? this.data.formData.temperature : '',//今日体温
        visitorComeFrom: this.data.formData.checkboxB == '是' ? this.data.formData.city : '',//被接待人来自湖北哪个地区
        //visitorComeTrafficInformation: this.data.formData.checkboxB == '是' ? this.data.formData.be_transportinfo : '',//被接待人来京乘坐交通信息
        //visitorComeWay: this.data.formData.checkboxB == '是' ? this.data.transportRange[this.data.formData.transport] : '',//被接待人来京方式
        visitorName: this.data.formData.checkboxB == '是' ? this.data.formData.contact_name : '',//被接待人姓名
        visitorReceivePlace: this.data.formData.checkboxB == '是' ? this.data.formData.contact_location : '',//在北京接待地点

        ////新增字段
        informantNation: this.data.formData.nationality == '外国籍' ? this.data.formData.country : '中国籍', //国籍

        goOutCountry: this.data.formData.checkboxA=='是'?this.data.formData.destinationtype == '境内' ? '境内' : this.data.formData.destination:'',//假期出京国内还是境外
        todayGoOutCountry: this.data.formData.plan == '出京'?this.data.formData.today_destinationtype == '境内' ? '境内' : this.data.formData.today_destination:'',//今日出京国内还是境外
        todayGoBackCountry: this.data.formData.plan == '返京' ? this.data.formData.today_re_destinationtype == '境内' ? '境内' : this.data.formData.today_re_destination : '',
        //this.data.formData.today_re_destinationtype == '境内' ? '境内' : this.data.formData.today_re_destination,//今日返京国内还是境外
        todayGoBackDestination: this.data.formData.plan == '返京' ? this.data.formData.today_re_destinationtype == '境内' ? (this.data.formData.today_re_destinationregion[0] + '#' + this.data.formData.today_re_destinationregion[1] + '#' + this.data.formData.today_re_destinationregion[2]) : '' : '',
        //this.data.formData.today_re_destinationregion[0] == '省' ? '' : (this.data.formData.today_re_destinationregion[0] + '#' + this.data.formData.today_re_destinationregion[1] + '#' + this.data.formData.today_re_destinationregion[2]),//今日返京目的地
        //informantOrganize: '公办',//组织机构
        informantSchool: this.data.formData.schoolname,//学校
        informantClass: (this.data.gradeName ? '' : this.data.gradeName)+this.data.className,//班级


        //新增字段
        todayGoOutInsideCityStatus: this.data.formData.plan=='在京'?this.data.formData.bj_plan:'',//今日是否在京出行
        todayGoOutInsideCityTime: this.data.formData.plan == '在京'?this.data.formData.bj_plan == '是' ? this.data.formData.today_date_bj:'':'',//在京出行时间
        todayGoOutInsideCityDestination: this.data.formData.plan == '在京'?this.data.formData.bj_plan == '是' ? this.data.formData.today_dd_bj:'':'',//在京出行地点
        todayGoOutInsideCityWay: this.data.formData.plan == '在京'?this.data.formData.bj_plan == '是' ? this.data.jtfs[this.data.formData.bj_jtfs]:'':'',//在京出行交通方式
        todayGoOutInsideCityTrafficInformation: this.data.formData.plan == '在京'?this.data.formData.bj_plan == '是' ? this.data.formData.bj_jtxx:'':'',//在京出行交通信息

        receivedHubeiProvince: this.data.formData.checkboxB=='是'?
          (this.data.formData.jcsf[0] + '#' + this.data.formData.jcsf[1] + '#' + this.data.formData.jcsf[2]):'',//接触省份

        visitorComeTime: this.data.formData.checkboxB == '是' ? this.data.formData.bjcr_isShow == true ? (this.data.formData.ljri + " 00:00:00"):'':'',
        visitorComeWay: this.data.formData.checkboxB == '是' ? this.data.formData.bjcr_isShow == true ? this.data.transportRange[this.data.formData.transport]:'':'',
        visitorComeTrafficInformation: this.data.formData.checkboxB == '是' ? this.data.formData.bjcr_isShow == true ? this.data.formData.be_transportinfo:'':''
      };
      if (this.data.status == null){
        submitData.id = this.data.id;
      }
      console.log(this.data.id)
      var url='';
      var title='';
      console.log(this.data.status,"this.data.status")
      if (this.data.status==null)
      {
        url = config.urlPrefix + '/client/questionary/updateQuestionary';
        title = '修改成功';
      }
      else{
        url = config.urlPrefix + '/client/questionary/clientSubmit';
        title = '提交成功';
      }
      console.log('url', url)
      console.log('submitData',submitData)

      
      if (agree1 && agree2 && agree3 && agree4 && agree5 && agree6 && agree7 && agree8 && agree9 && agree10 && agree11 && agree12){
        let that=this
        if (that.data.nodctj){
          that.setData({
            nodctj: false
          })
          wx.request({
            method: 'post',
            url: url,

            data: submitData,
            header: {
              'content-type': 'application/json', // 默认值
              'token': wx.getStorageSync('token')
            },
            success(res) {
              that.setData({
                nodctj: true
              })
              console.log('res.data.code:' + res.data.code)
              if (res.data.code == 200) {
                wx.showToast({
                  title: '修改成功',
                  icon: 'none',
                  duration: 2000
                })
                // 返回上一页
                wx.navigateBack({

                })
              } else {
                wx.showToast({
                  title: res.data.message,
                  //title: '提交失败',
                  icon: 'none',
                  duration: 2000
                })
              }

              // wx.navigateTo({
              //   url: '/pages/school/school-info/details/details',
              // })
            }
          })
        }
      }
      
    }

    console.log(submitData)


  },
  handleChangemap(e) { //g-region组件
    console.log(e)
    this.setData({
      [`formData.${e.target.id}`]: e.detail.value.map(item => item.name)
    })
  },

  // 取消
  goBack(){
    wx.navigateBack({
    })
  }
})