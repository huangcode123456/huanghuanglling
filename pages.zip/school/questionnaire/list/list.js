// pages/school/questionnaire/list/list.js
const cgi=require('../../../../constant/cgi.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    isShow:true,
    formData:'',
    userInfo:''
  },
  goTo(){
    wx.navigateTo({
      url: '/pages/school/questionnaire/info-collection/info-collection',
    })
  },
  handleTap(e){
    // if()
    let url=''
    console.log(e.currentTarget.dataset.id)
    if (this.data.userInfo.type == 'CLS' || this.data.userInfo.type == 'RPT') {
      url = '/pages/public/questionnaire/questionnaire?id=' + e.currentTarget.dataset.id+'&type='+'S'+'&readonly='+1
    }else{
      url = '/pages/public/questionnaire/questionnaire?id=' + e.currentTarget.dataset.id+'&type='+'T'+'&readonly='+1
    }
    wx.navigateTo({
      url,
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let that=this;
    wx.getStorage({
      key: 'userInfo',
      success: function(res) {
        console.log(res.data)
        that.setData({
          userInfo:res.data
        })
        let str=''
        if (res.data.type == 'CLS' || res.data.type =='RPT'){
          str={
            class_id: res.data.classId,
            user_number:res.data.userNumber
          }
        }else{
          str={
            userid:res.data.id
          }
        }
        wx.request({
          method: 'post',
          url: cgi.getQuestionaryHistory, //仅为示例，并非真实的接口地址
          data: str,
          header: {
            'content-type': 'application/json',// 默认值
            'token': wx.getStorageSync('token')
          },
          success(res) {
            if(res.data.data.length==0){
              that.setData({
                isShow:false
              })
            }
            console.log(res.data)
            that.setData({
              formData:res.data.data
            })
          }
        })
      },
    })
    
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})