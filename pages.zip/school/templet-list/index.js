// pages/school/templet-list/index.js
const cgi = require('../../../constant/cgi.js');
const analysis = require('../../../constant/analysis.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    formData: {
      page: '1',//页码默认为1
    },
    token: '',
    orgid: '',
    school: '',
    listData: [],
    //页码+name+dropdown箭头，name最长可显示3位数字或两个汉字一位数字，多出部分以...代替
    pages: [
      { name: '1', value: '1', displayName: '1' },
      { name: '2', value: '2', displayName: '2' },
      { name: '3', value: '3', displayName: '3' },
      { name: '4', value: '4', displayName: '4' },
      { name: '5', value: '5', displayName: '5' }
    ],
  },
  add1() {
    wx.navigateTo({
      url: '/pages/school/analysis/detail-setting/index',
    })
  },
  add2() {
    wx.navigateTo({
      url: '/pages/school/analysis/setting/setting',
    })
  },
  getOrgById() {
    let that = this
    wx.getStorage({
      key: 'token',
      success: function (res) {
        console.log(res)
        that.setData({
          token: res.data
        })
        wx.getStorage({
          key: 'userInfo',
          success: function (res) {
            that.setData({
              orgid: res.data.orgid
            })
            wx.request({
              method: 'post',
              url: cgi.gradeSet.getOrg,
              data: {
                orgid: that.data.orgid
              },
              header: {
                'content-type': 'application/json', // 默认值
                'token': that.data.token
              },
              success(res) {
                console.log(res.data.data.address == null)
                that.setData({
                  school: res.data.data
                })
              }
            })
          },
        })
      },
    })
  },
  handleChange(e) {
    this.setData({
      [`formData.${e.target.id}`]: e.detail.value,
    })
    //this.data.formData.templateindex=-1;

    this.getList()

  },
  // 获取统计分析列表
  getList() {
    var that = this;
    console.log('token', wx.getStorageSync('token'))
    var erq = {
      //page: that.data.formData.page,
      page:1,
      pagesize: 100,
    }
    wx.request({
      method: 'GET',
      url: analysis.getAllTemplateList,
      data: erq,
      header: {
        'content-type': 'application/json', // 默认值
        'token': wx.getStorageSync('token')
      },
      success(res) {
        console.log(res.data.data)
        if (res.code = 200) {
          that.setData({
            listData: res.data.data[0],
          })

        } else {
          wx.showToast({
            icon: "none",
            title: res.message,
          })
        }
      }
    })
  }, 
  showTemplate(e) {
    var nowidx = e.currentTarget.dataset.listidx;//当前索引
    console.log('nowidx:' + nowidx)
    var lists = this.data.listData;
    var templateid = lists[nowidx].id;
    var url = '';
    if (lists[nowidx].type === 1) {
      url = "/pages/school/analysis/sum-show/sum-show?id=" + templateid
    }
    else {
      url = "/pages/school/analysis/detail-show/detail-show?id=" + templateid
    }
    console.log(url, 'url')
    wx.navigateTo({
      url: url
    });
  },
  editTemplate(e) {
    var nowidx = e.currentTarget.dataset.listidx;//当前索引
    console.log('nowidx:' + nowidx)
    var lists = this.data.listData;
    var templateid = lists[nowidx].id;
    var url = '';
    if (lists[nowidx].type === 1) {
      url = "/pages/school/analysis/setting/setting?id=" + templateid
    }
    else {
      url = "/pages/school/analysis/detail-setting/index?id=" + templateid
    }
    console.log(url, 'url')
    wx.navigateTo({
      url: url
    });
  },
  delTemplate(e) {
    var nowidx = e.currentTarget.dataset.listidx;//当前索引
    console.log('nowidx:' + nowidx)
    var lists = this.data.listData;
    var templateid = lists[nowidx].id;
    var erq = {
      id: lists[nowidx].id,
    }
    console.log(erq,'erq')
    wx.request({
      method: 'DELETE',
      url: analysis.deleteTemplateById,
      data: erq,
      header: {
        'content-type': 'application/json', // 默认值
        'token': wx.getStorageSync('token')
      },
      success(res) {
        console.log(res)
        if (res.data.code = 200) {
          
          wx.showToast({
            icon: "none",
            title: "删除成功",
          })
          //this.getList();
          /*that.setData({
            listData: res.data,
          })*/
        } else {
          wx.showToast({
            icon: "none",
            title: res.message,
          })
        }
      }
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.getOrgById()
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.getList()
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})