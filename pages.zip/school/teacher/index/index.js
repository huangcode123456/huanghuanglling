// pages/school/teacher/index/index.js
var app = getApp();
const cgi = require('../../../../constant/cgi.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    orgName:'',
    orgid:'',
    list:[],
    noData:false,
    verifyTotal:0,
    show:false
  },
  
  //获取头部学校信息
  getOrgById() {
    let that = this
    wx.getStorage({
      key: 'token',
      success: function (res) {
        console.log(res)
        wx.getStorage({
          key: 'userInfo',
          success: function (res) {
            console.log(res, "eee")
            that.setData({
              id: res.data.id
            })
            wx.request({
              method: 'POST',
              url: cgi.gradeSet.getOrg,
              data: {
                orgid: that.data.orgid
              },
              header: {
                'content-type': 'application/json', // 默认值
                'token': that.data.token
              },
              success(res) {
                console.log(res.data.data)
              }
            })
          },
        })
      },
    })
  },

  // //根据openid判断是否为管理员
  getTeacherMessgeById() {
    var th = this
    wx.getStorage({
      key: 'userInfo',
      success: function (res) {
        console.log(res.data.id)
        th.setData({
          userid: res.data.id
        })
        wx.getStorage({
          key: 'token',
          success: function (res) {
            // app.globalData.token = res.data
            console.log(res.data)
            console.log('--------------获取管理员信息')
            wx.request({
              method: 'POST',
              url: cgi.adminSet.getTeacher,
              data: {
                'pageNumber': 1,
                'pageSize': 9,
                'startRow': 0,
                'type': 'SCM'
              },
              header: {
                'Content-Type': 'application/json',
                'token': res.data
              },
              success: function (res) {
                console.log(res)
                for(var i = 0;i<res.data.data.records.length;i++){
                  if(res.data.data.records[i].userid==th.data.userid){
                    th.setData({
                      show:true
                    })
                  }
                }
                console.log(th.data.userid, '用户id')
                console.log(th.data.id, '机构id')
              }
            })
          }
        })
      },
    })
  },

  // 邀请教师跳转
  goToInvite() {
    wx.navigateTo({
      url: '/pages/school/teacher/invite/invite?orgName='+this.data.orgName,
    })
  },


  // 获取部门带教师总数 DEPT
  getDeptListWithNum(){
    var that=this;
    var erq={
      orgid: that.data.orgid,
      type:'DEPT'
    }
    // console.log(erq);
    console.log(wx.getStorageSync('token'),'******************token')
    wx.request({
      method: 'POST',
      url: cgi.getOrganizationType,
      data: erq,
      header: {
        'content-type': 'application/json', // 默认值
        // 'token': app.globalData.token
        'token': wx.getStorageSync('token')
      },
      success(res) {
        console.log(res)
        if(res.code=200){
          if (res.data.data.records  && res.data.data.records.length>0){
            console.log(res.data.data.records)
            that.setData({
              list: res.data.data.records,
              noData: false
            })
          }else{
            that.setData({
              noData:true
            })
          }     
          
        }else{
          wx.showToast({
            icon:"none",
            title: res.message,
          })
        }
      }
    })
  },

  // 获取待审核名单总数
  getVerifyTotal(){
    var that = this;
    var erq = {
      orgid: that.data.orgid,
      type:1
    }
    // console.log(erq);

    wx.request({
      method: 'POST',
      url: cgi.teacher.getNoPassTeacher,
      data: erq,
      header: {
        'content-type': 'application/json', // 默认值
        'token': wx.getStorageSync('token')
      },
      success(res) {
        // console.log(res);
        if (res.code = 200) {
          that.setData({
            verifyTotal:res.data.data.teachernum
          })
          console.log(that.data.verifyTotal)

        } else {
          wx.showToast({
            icon: "none",
            title: res.message,
          })
        }
      }
    })

  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      orgName:options.orgName,
      orgid: wx.getStorageSync('userInfo').orgid // 从缓存获取学校orgid
    })
    console.log(this.data.orgid,'***************orgid');
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.getTeacherMessgeById();
    this.getOrgById();
    this.getVerifyTotal();
    this.getDeptListWithNum();
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})