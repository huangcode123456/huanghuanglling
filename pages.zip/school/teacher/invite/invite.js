// pages/school/teacher/invite/invite.js
Page({
  data: {
    title: "邀请学校教师",
    text: "点击下方按钮分享给微信好友",
    openid:'',
    token:'',
    orgid:'',
    userName:'',
    orgName:''
  },
  onLoad: function (options) {
    console.log(options)
    this.setData({
      orgName:options.orgName
    })
    let that=this;
    wx.getStorage({
      key: 'openid',
      success: function(res) {
        console.log(res.data)
        that.setData({
          openid:res.data
        })
      },
    })
    wx.getStorage({
      key: 'token',
      success: function (res) {
        console.log(res.data)
        that.setData({
          token: res.data
        })
      },
    })
    wx.getStorage({
      key: 'userInfo',
      success: function (res) {
        console.log(res.data.orgid)
        that.setData({
          orgid: res.data.orgid,
          userName:res.data.userName
        })
      },
    })
  },
  // 分享设置相关
  onShareAppMessage: function () {
    return {
      title: '邀请你成为'+this.data.orgName+'教师',
      path: '/pages/class/teacher-register/landing/landing?token=' + this.data.token + '&orgid=' + this.data.orgid + '&userName=' + this.data.userName+'&orgName=' +this.data.orgName// 路径，传递参数到指定页面。
    }
  }


})