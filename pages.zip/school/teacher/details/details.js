// pages/school/admin/details/details.js
var app = getApp();
const cgi = require('../../../../constant/cgi.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    userid:'',
    info:{},
    readonly:1,
    id:''
  },



  // 审核管理员 0-拒绝 ; 2-通过
  updateUserType(event) {
    var that = this;
    var type = event.currentTarget.dataset.type
    var req = {
      userid: that.data.id,
    }
    if (type == "agree") { //同意
      req.status = 2;
    } else if (type == "refuse") { //拒绝
      req.status = 0;
    }
    wx.showModal({
      title: '提示',
      content: type == "agree" ? '确定同意吗？' : '确定拒绝吗？',
      success: function (res) {
        if (res.confirm) {
          console.log(req);

          wx.request({
            method: 'POST',
            url: cgi.adminSet.shadmin,
            data: req,
            header: {
              'content-type': 'application/json', // 默认值
              'token': wx.getStorageSync('token')
            },

            success(res) {
              console.log(res)
              if (res.data.code == 200) {
                wx.showToast({
                  title: '操作成功',
                  success() {
                    // 返回上一页
                    wx.navigateBack({
                      delta: 1
                    })
                    // wx.navigateTo({
                    //   url: '/pages/school/admin/list/list',
                    // })
                  }
                })

              } else {
                wx.showToast({
                  title: res.message,
                  icon: "none"
                })
              }
            }
          })
        }
      },
    })
  },
  
  // 删除
  del() {
    var that = this;
    var req = {
      operateType: 'deleteMasTeacher',
      targetUserId: that.data.userid
      
    }
    wx.showModal({
      title: '提示',
      content: '确定删除教师吗？',
      success: function (res) {
        if (res.confirm) {
          console.log(req);

          wx.request({
            method: 'POST',
            url: cgi.userOperate,
            data: req,
            header: {
              'content-type': 'application/json', // 默认值
              'token': wx.getStorageSync('token')
            },
            success(res) {
              console.log(res)
              if (res.data.code == 200) {
                wx.showToast({
                  title: '操作成功',
                  success() {
                    // 返回上一页
                    wx.navigateBack({
                      delta: 1
                    })
                  }
                })

              } else {
                wx.showToast({
                  title: res.message,
                  icon: "none"
                })
              }
            }
          })
        }
      },
    })

  },

  // // 审核管理员通过
  // goToInvitepass(){
  //   var than = this
  //   // var id = app.globalData.id
  //   wx.showModal({
  //     title: '提示',
  //     content: '是否确认通过',
  //     success(res) {
  //       if (res.confirm) {
  //         console.log(res.confirm)
  //         console.log('用户点击确定')
  //         wx.getStorage({
  //           key: 'token',
  //           success: function (res) {
  //             // console.log(id)
  //             console.log(than.data.userid1)
  //             console.log(res.data)
  //             wx.request({
  //               method: 'POST',
  //               url: cgi.adminSet.shadmin,
  //               data: {
  //                 userid: than.data.userid1,
  //                 status: '2'
  //               },
  //               header: {
  //                 'content-type': 'application/json', // 默认值
  //                 'token': res.data
  //               },
  //               success(res) {
  //                 console.log(res)
  //                 if (res.data.code == 200) {
  //                   wx.showToast({
  //                     title: '审核通过',
  //                     success() {
  //                       // 返回上一页
  //                       wx.navigateBack({
  //                         delta: 1
  //                       })
  //                       // wx.navigateTo({
  //                       //   url: '/pages/school/admin/list/list',
  //                       // })
  //                     }
  //                   })

  //                 } else {
  //                   wx.showToast({
  //                     title: '审核未通过',
  //                     icon: "none",
  //                   })
  //                   // 返回上一页
  //                 }
  //               }
  //             })
  //           },
  //         })
  //       } else if (res.cancel) {
  //         console.log('用户点击取消')
  //       }
  //     }
  //   })
    
    
  // },
  // // 审核管理员拒绝
  // goToInvite() {
  //   var than = this
  //   // var id = app.globalData.id
  //   wx.getStorage({
  //     key: 'token',
  //     success: function (res) {
  //       // console.log(id)
  //       console.log(res.data)
  //       console.log(than.data.userid1)
  //       wx.showModal({
  //         title: '提示',
  //         content: '是否拒绝',
  //         success: function(res) {
  //           if(res.confirm){
  //             wx.request({
  //               method: 'POST',
  //               url: cgi.adminSet.shadmin,
  //               data: {
  //                 userid: than.data.userid1,
  //                 status: '0'
  //               },
  //               header: {
  //                 'content-type': 'application/json', // 默认值
  //                 'token': res.data
  //               },
  //               success(res) {
  //                 console.log(res)
  //                 if (res.data.code == 200) {
  //                   wx.showToast({
  //                     title: '审核拒绝',
  //                     icon: 'none',
  //                     success() {
  //                       // 返回上一页
  //                       wx.navigateBack({
  //                         delta: 1
  //                       })
  //                       // wx.navigateTo({
  //                       //   url: '/pages/school/teacher/verifyList/verifyList',
  //                       // })
  //                     }
  //                   })

  //                 } else {
  //                   wx.showToast({
  //                     title: '审核未通过',
  //                     icon: "none"
  //                   })
  //                 }
  //               }
  //             })
  //           }else{
  //             console.log('用户点击取消')
  //           }
  //         },
  //       })
  //     },
  //   })
    
  // },
  
  getOrgById() {
    let that = this
    wx.getStorage({
      key: 'token',
      success: function (res) {
        console.log(res)
        that.setData({
          token: res.data
        })
        wx.getStorage({
          key: 'userInfo',
          success: function (res) {
            console.log(res, "eee")
            app.globalData.uid = res.data.id
            console.log(app.globalData.uid+'&&&&&&&&&&')
            that.setData({
              orgid: res.data.orgid
            })
            wx.request({ //获取机构数据
              method: 'POST',
              url: cgi.gradeSet.getOrg,
              data: {
                orgid: that.data.orgid
              },
              header: {
                'content-type': 'application/json', // 默认值
                'token': that.data.token
              },
              success(res) {
                console.log(res.data.data)
                app.globalData.id = res.data.data.modifyUserId //机构总管理员id
                console.log(app.globalData.id+'&&&&&&&&&&&&&&&')
                that.setData({
                  school: res.data.data
                })
                console.log(app.globalData.uid + '&&&&&&&&&&')
                console.log(app.globalData.id + '&&&&&&&&&&&&&&&')
                if (app.globalData.uid !== app.globalData.id) {
                  that.setData({
                    hide: true
                  })
                  console.log(that.data.hide)
                }
                console.log(that.data.school)
              }
            })
          },
        })
      },
    })
  },

  getTeacherMessgeById() {
    var th = this
    wx.getStorage({
      key: 'userInfo',
      success: function (res) {
        console.log(res.data.id)
        th.setData({
          userid: res.data.id
        })
        wx.getStorage({
          key: 'token',
          success: function (res) {
            app.globalData.token = res.data
            console.log('--------------获取管理员信息')
            wx.request({
              method: 'POST',
              url: cgi.adminSet.getTeacher,
              data: {
                'pageNumber': 1,
                'pageSize': 9,
                'startRow': 0,
                'type': 'SCM'
              },
              header: {
                'Content-Type': 'application/json',
                'token': res.data
              },
              success: function (res) {
                console.log(res)
                for (let i = 0; i < res.data.data.records.length; i++) {
                  if (res.data.data.records[i].type == "SCHM") {
                    console.log(res.data.data.records[i].userid)
                    console.log(th.data.userid)
                    if (res.data.data.records[i].userid == th.data.userid) {
                      th.setData({
                        show: true
                      })
                    }
                  }
                }
              }
            })
          }
        })
      },
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log(options)
    this.setData({
      index:options.index,
      readonly:options.readonly,
      userid: options.userid,
      id:options.userid
    })
    // console.log(app.globalData.uid + '%%%%%%%' + app.globalData.id)
    
   
  },

  // 获取教师详情
  getInfo() {
    var that = this;
    var condition = {
      userid: that.data.userid
    }
    wx.request({
      method: 'POST',
      url: cgi.getTeacherMessgeById,
      data: condition,
      header: {
        'content-type': 'application/json', // 默认值
        'token': wx.getStorageSync('token')
      },
      success(res) {
        // console.log(res)
        if (res.code = 200) {
          that.setData({
            info:res.data.data
          })
          console.log(that.data.info)
        } else {
          wx.showToast({
            icon: "none",
            title: '查询失败，请重试！',
          })
        }
      }
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.getInfo();
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})