// pages/school/school-info/details/details.js
const cgi = require('../../../../constant/cgi.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    token: '',
    orgid: '',
    school: ''
  },

  goToIndex(){
    wx.reLaunch({
      url: '/pages/school/index/index',
    })
  },
  // 修改学校信息跳转
  goToEdit(){
    wx.navigateTo({
      url: '/pages/school/school-info/edit/edit',
    })
  },
  // getOrgById() {
  //   let that = this
  //   wx.getStorage({
  //     key: 'token',
  //     success: function (res) {
  //       console.log(res)
  //       that.setData({
  //         token: res.data
  //       })
  //       wx.getStorage({
  //         key: 'userInfo',
  //         success: function (res) {
  //           that.setData({
  //             orgid: res.data.orgid
  //           })
  //           wx.request({
  //             method: 'post',
  //             url: cgi.gradeSet.getOrg,
  //             data: {
  //               orgid: that.data.orgid
  //             },
  //             header: {
  //               'content-type': 'application/json', // 默认值
  //               'token': that.data.token
  //             },
  //             success(res) {
  //               console.log(res.data.data.address==null)
  //               that.setData({
  //                 school: res.data.data
  //               })
  //             }
  //           })
  //         },
  //       })
  //     },
  //   })
  // },
  // 获取学校信息
  getSchoolInfo(){
    var that=this;
    wx.request({
      method: 'post',
      url: cgi.gradeSet.getOrg,
      data: {
        orgid: wx.getStorageSync('userInfo').orgid
      },
      header: {
        'content-type': 'application/json', // 默认值
        'token': wx.getStorageSync('token')
      },
      success(res) {
        console.log(res)
        that.setData({
          school: res.data.data
        })
      }
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.getSchoolInfo()
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})