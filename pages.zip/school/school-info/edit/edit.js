// pages/school/school-info/edit/edit.js
const cgi = require('../../../../constant/cgi.js');
Page({
  data: {
    userid: '',//用户id
    userName: '',//用户id
    orgid: '',
    schoolInfo: null,
    click:true,
    formData: {
      orgName: '',//学校名称
      orgAlias: '',//学校简称
      orgProp: '',//办学性质
      kind: '',//办学类别
      orgCode: '',//学校代码
      phone: '',//办公电话
      areaName: '',//所属街道
      station: '',//驻地类型
      address: ''//详细地址
    },
    rules: {
      orgProp: [{ type: 'required', message: '请选择办学性质' }],
      kind: [{ type: 'required', message: '请选择办学类型' }],
      orgCode: [{ type: 'required', message: '该字段必填' }],
      phone: [
        { type: 'required', message: '该字段必填' },
        { type: 'customPhoen', message: '请输入正确的固话' }
      ],
      areaName: [{ type: 'required', message: '该字段必填' }],
      station: [{ type: 'required', message: '请选择驻地城乡类型' }],
      address: [{ type: 'required', message: '该字段必填' }],

    },
    validateType: {
      customPhoen(value, formData) {
        return /^([0-9]{3,4}-)?[0-9]{7,8}$/.test(value)
      }
    },
    orgPropRange: [
      { name: '公办', value: 'G'},
      { name: '民办', value: 'M' },
      { name: '未审批', value: 'W' },
    ],
    kindRangeG: [
      { name: '幼儿园', value: '幼儿园' },
      { name: '学校附属幼儿园', value: '学校附属幼儿园' },
      { name: '事业单位办园', value: '事业单位办园' },
      { name: '企业办园', value: '企业办园' },
      { name: '集体办园', value: '集体办园' },
      { name: '部队办园', value: '部队办园' },
      { name: '完全小学', value: '完全小学' },
      { name: '初级中学', value: '初级中学' },
      { name: '九年一贯制', value: '九年一贯制' },
      { name: '十二年一贯制', value: '十二年一贯制' },
      { name: '完全中学', value: '完全中学' },
      { name: '特殊教育学校', value: '特殊教育学校' },
      { name: '中等技术学校', value: '中等技术学校' },
      { name: '职业高中学校', value: '职业高中学校' },
      { name: '驻昌高校', value: '驻昌高校' }
    ],
    kindRangeM: [
      { name: '社区办园点', value: '社区办园点' },
      { name: '幼儿园', value: '幼儿园' },
      { name: '完全小学', value: '完全小学' },
      { name: '初级中学', value: '初级中学' },
      { name: '九年一贯制', value: '九年一贯制' },
      { name: '十二年一贯制', value: '十二年一贯制' },
      { name: '完全中学', value: '完全中学' },
      { name: '特殊教育学校', value: '特殊教育学校' },
      { name: '中等技术学校', value: '中等技术学校' },
      { name: '职业高中学校', value: '职业高中学校' },
      { name: '驻昌高校', value: '驻昌高校' },
      { name: '培训机构', value: '培训机构' }
    ],
    kindRangeW: [
      { name: '幼儿园', value: '幼儿园' },
      { name: '完全小学', value: '完全小学' },
      { name: '初级中学', value: '初级中学' },
      { name: '九年一贯制', value: '九年一贯制' },
      { name: '十二年一贯制', value: '十二年一贯制' },
      { name: '完全中学', value: '完全中学' },
      { name: '特殊教育学校', value: '特殊教育学校' },
      { name: '中等技术学校', value: '中等技术学校' },
      { name: '职业高中学校', value: '职业高中学校' },
      { name: '驻昌高校', value: '驻昌高校' },
      { name: '培训机构', value: '培训机构' }
    ],
    kindRange: [],
    stationRange: [
      { name: '主城区', value: '主城区' },
      { name: '城乡结合区', value: '城乡结合区' },
      { name: '镇中心区', value: '镇中心区' },
      { name: '镇乡结合区', value: '镇乡结合区' },
      { name: '村庄', value: '村庄' },
    ]
  },
  handleChange(e) {
    this.setData({
      [`formData.${e.target.id}`]: e.detail.value
    })
  },
  handlePropChange(e){
    var orgProp = e.detail.value;
    var range = [];
    if (orgProp=='G'){
      range = this.data.kindRangeG;
    } else if (orgProp=='M'){
      range = this.data.kindRangeM;
    } else if (orgProp=='W'){
      range = this.data.kindRangeW;
    }
    this.setData({
      kindRange: range,
      [`formData.orgProp`]: orgProp,
      [`formData.kind`]: ''
    });
  },

  handleFormSubmit(e) {
    const { validStatus, value: { orgName } } = e.detail
    console.log(e.detail)
    let that = this;
    if (validStatus && that.data.click) {
      
      wx.showLoading({
        title: '正在保存中...',
      })
      that.setData({
        click:false,
      })
      let obj = that.data.schoolInfo;

      obj.orgName = that.data.formData.orgName;//学校名称
      obj.orgAlias = that.data.formData.orgAlias;//机构简称
      obj.orgProp = that.data.formData.orgProp;//办学性质
      obj.kind = that.data.formData.kind; //办学类别
      obj.orgCode = that.data.formData.orgCode;//学校代码
      obj.phone = that.data.formData.phone;//办公电话
      obj.areaName = that.data.formData.areaName;//所属镇街
      obj.station = that.data.formData.station;//驻地类型
      obj.address = that.data.formData.address;//详细地址
      obj.modifyUserId = wx.getStorageSync('userInfo').id;//用户id
      obj.modifyUserName = wx.getStorageSync('userInfo').userName;//用户id
      console.log(obj);
      wx.request({
        method: 'post',
        url: cgi.gradeSet.updateOrgById,
        data: obj,
        header: {
          'content-type': 'application/json', // 默认值
          'token': wx.getStorageSync('token')
        },
        success(res) {
          that.setData({
            click: true,
          })
         wx.hideLoading();
          console.log(res)
          if (res.data.code == 200) {
            wx.showToast({
              title: '修改成功',
              icon: 'none',
              duration: 500
            })
            // 返回上一页
            setTimeout(function () {
              wx.navigateBack({
                delta: 1
              })
            }, 500)

          } else {
            wx.showToast({
              title: res.data.message,
              icon: 'none',
              duration: 2000
            })
          }
        }
      })
    }


  },
  // 获取学校信息
  getSchoolInfo() {
    var that = this;
    wx.request({
      method: 'post',
      url: cgi.gradeSet.getOrg,
      data: {
        orgid: wx.getStorageSync('userInfo').orgid
      },
      header: {
        'content-type': 'application/json', // 默认值
        'token': wx.getStorageSync('token')
      },
      success(res) {
        console.log(res)
        var orgProp = res.data.data.orgProp;
        var range = [];
        if (orgProp == 'G') {
          range = that.data.kindRangeG;
        } else if (orgProp == 'M') {
          range = that.data.kindRangeM;
        } else if (orgProp == 'W') {
          range = that.data.kindRangeW;
        }
        that.setData({
          kindRange: range,
          formData: res.data.data,
          schoolInfo: res.data.data
        })
        // console.log(that.data.formData.orgProp)
      }
    })
  },


  // 取消
  goBack() {
    wx.navigateBack({
    })
  },

  onLoad: function (options) {

  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.getSchoolInfo()
  }
})
