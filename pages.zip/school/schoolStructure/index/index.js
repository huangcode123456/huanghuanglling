// pages/school/schoolStructure/index/index.js
const cgi = require('../../../../constant/cgi.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    schoolName:'',
    deptList:[],
    deptNoData: false,
    arrow: [],
    // 'arrow-up', 'arrow-down', 'arrow-down','arrow-down'
    isShow:[],
    // true, false, false, false
    clsList:[
      // { 
      //   grade: '一年级', 
      //   classes: [
      //     {
      //       classs:'一班',
      //       num:10
      //     },
      //     {
      //       classs: '二班',
      //       num: 20
      //     }
      //   ] 
      // },
    ],
    clsNoData:false
  },
  //根据机构id获取年级班级
  getTeacherListByParentId(){
    let that=this;
    wx.getStorage({
      key: 'userInfo',
      success: function(res) {
        console.log(res.data)
        that.setData({
          userInfo:res.data
        })
        wx.request({
          method: 'post',
          url: cgi.getTeacherListByParentId, //仅为示例，并非真实的接口地址
          data: {
            parentId: res.data.orgid
          },
          header: {
            'content-type': 'application/json', // 默认值,
            'token':wx.getStorageSync('token')
          },
          success(res) {
            console.log(res.data.data.records)
            let arrow=[];
            let isShow=[];
            for (let i = 0; i < res.data.data.records.length;i++){
              // if(i=0){
              //   arrow.push('arrow-up')
              //   isShow.push(true)
              // }else{
                arrow.push('arrow-down')
                isShow.push(false)
              // }
            }
            arrow[0] ='arrow-up'
            isShow[0]=true;
            that.setData({
              arrow,
              isShow
            })
            if (res.code = 200) {
              if (res.data.data.records && res.data.data.records.length > 0) {
                console.log(res.data.data.records)
                that.setData({
                  clsList: res.data.data.records,
                  clsNoData: false
                })
              } else {
                that.setData({
                  clsNoData: true
                })
              }

            } else {
              wx.showToast({
                icon: "none",
                title: res.message,
              })
            }

            // console.log(res.data.data.records)
            // that.setData({
            //   clsList:res.data.data.records
            // })
          }
        })
      },
    })
  },
  showClick(e){
    console.log(e)
    let index = e.currentTarget.dataset.index;
    console.log(index)
    let arrow=this.data.arrow;
    let isShow=this.data.isShow;
    console.log(arrow,isShow)
    if (isShow[index]==true){
      isShow[index] = false;
      arrow[index] ='arrow-down'
    } else if (isShow[index] == false){
      isShow[index] = true;
      arrow[index] = 'arrow-up'
    }
    this.setData({
      arrow,
      isShow
    })
    console.log(arrow,isShow)
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    
    // 从菜单参数获取学校名称
    this.setData({
      schoolName: options.schoolName
    })
    // this.setData({
    //   deptNoData: false,
    //   clsNoData: false
    // })
    this.getDeptListWithNum();
    this.getTeacherListByParentId()
  },


  // 获取部门带教师总数 DEPT
  getDeptListWithNum() {
    var that = this;
    var erq = {
      orgid: wx.getStorageSync('userInfo').orgid, //从缓存获取当前学校id
      type: 'DEPT'
    }
    wx.request({
      method: 'POST',
      url: cgi.getOrganizationType,
      data: erq,
      header: {
        'content-type': 'application/json', // 默认值
        'token': wx.getStorageSync('token')
      },
      success(res) {
        console.log(res)
        if (res.code = 200) {
          if (res.data.data.records && res.data.data.records.length > 0) {
            console.log(res.data.data.records)
            that.setData({
              deptList: res.data.data.records,
              deptNoData: false
            })
          } else {
            that.setData({
              deptNoData: true
            })
          }

        } else {
          wx.showToast({
            icon: "none",
            title: res.message,
          })
        }
      }
    })
  },


  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
   
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})