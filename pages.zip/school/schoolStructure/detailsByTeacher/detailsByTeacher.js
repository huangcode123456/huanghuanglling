// pages/school/schoolStructure/detailsByTeacher/detailsByTeacher.js
const cgi = require('../../../../constant/cgi.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    schoolName: '',
    orgName: '',
    userid: '',
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log(options);
    this.setData({
      schoolName: options.schoolName,
      orgName: options.orgName,
      userid: options.userid
    })
  },

  // 获取教职工详情
  getInfo() {
    var that = this;
    var condition = {
      userid: that.data.userid
    }
    wx.request({
      method: 'POST',
      url: cgi.getTeacherMessgeById,
      data: condition,
      header: {
        'content-type': 'application/json', // 默认值
        'token': wx.getStorageSync('token')
      },
      success(res) {
        // console.log(res)
        if (res.code = 200) {
          that.setData({
            info: res.data.data
          })
          console.log(that.data.info)
        } else {
          wx.showToast({
            icon: "none",
            title: '查询失败，请重试！',
          })
        }
      }
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.getInfo();
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})