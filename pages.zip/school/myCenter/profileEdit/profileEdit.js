// pages/school/myCenter/profileEdit/profileEdit.js
const cgi = require('../../../../constant/cgi.js');
Page({
  data: {
    userInfo:null,
    firstLogin:false,
    formData: {
      userName: '',
      sex: '',
      age:'',
      phone: '',
      idcard: '',
      address: '',
      deptName: '',
      origin:""
    },
    // selectDeptRange: [],
    rules: {
      userName: [{ type: 'required', message: '请填写姓名' }],
      // sex: [{ type: 'required', message: '请选择性别' }],
      age: [
        { type: 'required', message: '请填写年龄' },
        { type: 'customAge', message: '请填写正确的年龄' }
      ],
      // origin: [{ type: 'required', message: '请填写籍贯' }],
      phone: [
        { type: 'required', message: '请填写手机号码' },
        { type: 'customPhone', message: '请填写正确的手机号码' },
      ],
      address: [{ type: 'required', message: '请填写居住地址' }],
      // idcard: [
      //   { type: 'required', message: '请填写身份证号码' },
      //   { type: 'customIdcard', message: '请填写正确的身份证号码' },
      // ],
    },
    validateType: {
      customIdcard(value, formData) {
        return /^[1-9]\d{7}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}$|^[1-9]\d{5}[1-9]\d{3}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}([0-9]|X)$/.test(value)
      },
      customPhone(value, formData) {
        return /^1[3456789]\d{9}$/.test(value)
      },
      customPwd(value, formData) {
        return value.length >= 6 && value.length <= 12
      },
      customAge(value, formData) {
        return /^(?:[1-9][0-9]?|1[01][0-9]|120)$/.test(value)
      },
    },
    genderRange: [
      { name: '男', value: 'M', displayName: '男' },
      { name: '女', value: 'F', displayName: '女' }
    ],
    
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log(options,"edit_optiions")
    //用户首次登录
    if (options.firstLogin==1){
      this.setData({
        firstLogin:true
      });
      wx.setNavigationBarTitle({
        title: '完善个人资料'
      })
    }
    let that = this;
    wx.getStorage({
      key: 'userInfo',
      success: function(res) {
        console.log(res,"userres")
        that.setData({
          formData: res.data,
          userInfo:res.data
        });
        // that.getDeptList();
      },
    })
  },

  //获取职能部门
  getDeptList() {
    let that = this;
    wx.request({
      method: "post",
      url: cgi.gradeSet.getDeptList,
      data: {
        parentId: that.data.userInfo.orgid,
      },
      header: {
        'content-type': 'application/json', // 默认值
        'token': that.data.token
      },
      success(res) {
        let znbm = []
        for (let i = 0; i < res.data.data.length; i++) {
          let str = {};
          str.name = res.data.data[i].orgName;
          str.value = res.data.data[i].orgid;
          str.displayName = res.data.data[i].orgName;
          znbm.push(str)
        }
        that.setData({
          selectDeptRange: znbm,
          'formData.deptName': that.data.userInfo.deptId
        })
      }
    })
  },
  idCardChange(e) {
    console.log(e,"eee")
    let idcard = e.detail.value;
    let sex = this.data.formData.sex;
    let age = this.data.formData.age;
    if (this.data.validateType.customIdcard(idcard)){
      // if(!sex){
        if(parseInt(idcard.substr(16,1))%2==1){
          sex = 'M';
        }else{
          sex = 'F';
        }
      // }
      // if(!age){
        var curDate = new Date();
        console.log(parseInt(idcard.substr(6, 4)),"birthyear");
        age = curDate.getFullYear()-parseInt(idcard.substr(6,4));
      // }
    }
    this.setData({
      'formData.idcard': idcard,
      'formData.sex': sex,
      'formData.age': age
    })
    console.log(this.data.formData.sex,"sex")
    console.log(this.data.formData.age,"age")
  },
  handleChange(e) {
    this.setData({
      [`formData.${e.target.id}`]: e.detail.value
    })
  },

  handleFormSubmit(e) {
    
    const { validStatus, value: { name, password } } = e.detail
    console.log(e.detail);

    if (validStatus){
      // 判断保存后的跳转页面
      let obj = {};
      obj.userName = this.data.formData.userName;
      obj.sex = this.data.formData.sex;
      obj.phone = this.data.formData.phone;
      obj.idcard = this.data.formData.idcard;
      obj.address = this.data.formData.address;
      obj.age = this.data.formData.age;
      // obj.origin = this.data.formData.origin;
      // obj.deptId = this.data.formData.deptName;
      try {
        obj.openid = wx.getStorageSync('openid');
      } catch (e) {
      }
      let that = this;
      let urlInfo = cgi.myCenter.updateUser;
      if (that.data.firstLogin){
        urlInfo = cgi.myCenter.editUser
      }
      wx.request({
        method:'POST',
        url: urlInfo,
        header: {
          'token': wx.getStorageSync('token')
        },
        data: obj,
        success(res) {
          console.log(res);
          if(res.data.code==200){
            //更新userInfo缓存 
            let user = that.data.userInfo;
            user.phone = obj.phone;
            user.userName = obj.userName;
            user.sex = obj.sex;
            user.idcard = obj.idcard;
            user.address = obj.address;
            user.age = obj.age;
            // user.origin = obj.origin;
            // user.deptId = obj.deptId;
            // let deptRange = that.data.selectDeptRange;
            // for (var i = 0; i < deptRange.length; i++) {
            //   if (deptRange[i].value == user.deptId) {
            //     user.deptName = deptRange[i].name;
            //     break;
            //   }
            // }
            wx.removeStorageSync("userInfo");
            wx.setStorage({
              key: 'userInfo',
              data: user,
              success(res) {
                console.log(res)
                if (that.data.firstLogin) {
                  console.log('保存后跳转至首页...');

                  wx.reLaunch({
                    url: '/pages/school/index/index',
                  })
                } else {
                  console.log('保存后返回个人中心');
                  wx.navigateBack({
                    delta: 1,
                  })

                  // wx.redirectTo({
                  //   url: '/pages/school/myCenter/index/index',
                  // })
                }
              }
            });
          }else{
            wx.showToast({
              icon:'none',
              title: res.data.message,
            })
          }
          
        }
      })
      
    }
    
  },

  // // 取消
  // goBack() {
  //   wx.navigateBack({
  //   })
  // }
})