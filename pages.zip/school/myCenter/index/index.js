// pages/school/myCenter/index/index.js
var appInst = getApp();
const cgi = require('../../../../constant/cgi.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    userInfo:null
  },
  handlePrimaryTap() {
    console.log('重置密码')
  },
  handleSecondTap() {
    console.log('修改信息')
    wx.navigateTo({
      url: '/pages/school/myCenter/profileEdit/profileEdit',
    })
  },
  tcdl() {
    console.log('----------退出登录----------------')
    let that = this;
    wx.showModal({
      title: '提示',
      content: '确定退出？',
      success(res) {
        if (res.confirm) {
          console.log('用户点击确定')
          wx.getStorage({
            key: 'token',
            success: function(token) {
              console.log(token.data)
              wx.request({
                method: 'POST',
                url: cgi.loginTask.logoutUser,
                header: {
                  'Content-Type': 'application/json',
                  'token': token.data
                },
                success: function (res) {
                  console.log(res,"logout success")
                  if (res.data.code==200) {
                    wx.clearStorage();
                    wx.showToast({
                      title: '退出成功',
                    })
                    
                    console.log('已经退出');
                    let type = that.data.userInfo.type;
                    console.log(type,"my type")
                    if (type=="SCHM"||type=="SCH"){
                      wx.reLaunch({
                        url: '/pages/school/admin-login/index?src=logout',
                      })
                    }else if(type=="MAS"||type=="DEY"||type=="THR"){
                      wx.reLaunch({
                        url: '/pages/class/login/login?src=logout',
                      })
                    }else if(type=="CLS"||type=="RPT"){
                      wx.reLaunch({
                        url: '/pages/student/login/index?src=logout',
                      })
                    }else{
                      wx.reLaunch({
                        url: '/pages/index/index?src=logout',
                      })
                    }
                  }else{
                    wx.showToast({
                      title:'退出失败'
                    })
                  }
                }
              })
            }
          })
          
        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })
  },
  goToIndex:function(){
    wx.reLaunch({
      url: '/pages/school/index/index',
    })
  },
  initUserInfo:function(){
    let that = this;
    wx.getStorage({
      key: 'userInfo',
      success: function(res) {
        console.log(res,"userinfo")
        that.setData({
          userInfo:res.data
        })
      },
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    // this.initUserInfo();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.initUserInfo();
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})